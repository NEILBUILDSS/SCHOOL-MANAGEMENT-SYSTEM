const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const TIME_RE = /^(?:[01]\d|2[0-3]):[0-5]\d$/;

function clean(value, max = 200) {
  return String(value ?? '').trim().replace(/[\u0000-\u001f\u007f]/g, '').slice(0, max);
}

function required(value, label, max = 200) {
  const v = clean(value, max);
  if (!v) throw httpError(400, `${label} is required.`);
  return v;
}

function validateEmail(value) {
  const email = required(value, 'Email', 254).toLowerCase();
  if (!EMAIL_RE.test(email)) throw httpError(400, 'Enter a valid email address.');
  return email;
}

function validatePassword(value) {
  const password = String(value ?? '');
  if (password.length < 8) throw httpError(400, 'Password must be at least 8 characters long.');
  if (password.length > 128) throw httpError(400, 'Password is too long.');
  return password;
}

function validateTime(value, label) {
  const time = required(value, label, 5);
  if (!TIME_RE.test(time)) throw httpError(400, `${label} must use 24-hour HH:MM format.`);
  return time;
}

function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

function escapeRegex(value) {
  return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

module.exports = { clean, required, validateEmail, validatePassword, validateTime, httpError, escapeRegex };
