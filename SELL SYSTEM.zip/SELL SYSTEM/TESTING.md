# Testing Report — Southern Canillo College School Scheduling

**Test date:** October 22, 2026  
**Environment:** Windows 11, Node.js 24.21.0, MongoDB local service at `127.0.0.1:27017`, Chromium browser  
**Application URL:** `http://localhost:3002`  
**Database:** `sell_system_scheduling`

---

## 1. Automated tests

Command:

```powershell
npm test
```

Result: **37 passed, 0 failed, 0 skipped**

| Suite | Checks | Result |
|---|---:|---|
| `tests/roomAvailability.unit.test.js` | 16 | Passed |
| `tests/roomAvailability.integration.test.js` | 6 | Passed |
| `tests/roomAvailability.api.test.js` | 13 | Passed |
| `tests/studentId.test.js` | 1 | Passed |
| `tests/registration.test.js` | 1 | Passed |

The suites use throwaway MongoDB databases (`college_scheduling_room_test_opencode`, `college_scheduling_api_test_opencode`, `college_scheduling_studentid_test_opencode` and `college_scheduling_registration_test_opencode`) that are dropped after the run, so the project database is not modified.

### What the automated tests prove

- An empty room accepts a valid time window.
- A free slot is allowed; an overlapping slot is rejected.
- Back-to-back classes do not conflict.
- Availability is scoped to the correct school year / semester.
- The 8-hour daily room limit is enforced; over-limit data is reported.
- Updating a schedule never conflicts with itself.
- Overlapping schedules are rejected per day; other days remain usable.
- Two concurrent attempts cannot double-book the same room and time.
- An overlapping class in the same course/year/section is rejected as a section conflict, while an adjacent period and a different year level remain valid.
- The class list is hard-capped at 10 active enrollments: 10 real enrollments save, and the 11th is rejected with a clear message.
- The instructor class-record API returns those same 10 enrolled students, saves attendance/assignments/activities, and rejects a stray final-grade field.
- The plot-a-class availability response prefers a consecutive period over an earlier gap while keeping the valid-start list chronological.
- Public registration accepts an account type (Student or Instructor) plus only Username, Password and Confirm Password, creates the matching account, and stores a bcrypt hash rather than the plain-text password.
- A duplicate username is rejected case-insensitively, and concurrent attempts with the same username create exactly one account.
- Password confirmation is enforced on the server, and a public request for an Admin role is rejected without creating a user.
- The newly registered Student can sign in through the existing login endpoint, while Admin and Instructor endpoints remain blocked.
- The newly registered Instructor can sign in, sees the Instructor portal, and cannot access Student-only endpoints.
- Public Student registration generates the next unique `YYYY-####` Student ID on the server and saves it; a manual ID sent by the client is ignored.
- Public Instructor registration generates the next unique `INS-###` Instructor ID and links the Instructor profile.
- A pre-existing Student ID is skipped rather than overwritten, and the generated ID is returned from both the Student profile and Admin student APIs.
- Six simultaneous registrations receive six different IDs, and an Admin-created student record also receives an automatic ID when none is supplied.
- The HTTP API returns the same rules through:
  - room list availability,
  - conflict pre-flight checks,
  - schedule creation and update,
  - room availability after a room fills to the daily limit.
- The plot-a-class availability response:
  - offers only start times that clear the section and instructor timetable,
  - uses 60-minute MWF and 90-minute TTh sessions for the test subject,
  - rejects the exact and overlapping instructor slots,
  - returns only rooms that fit the planned section capacity,
  - reports a too-small room as `capacity` blocked with its seat count,
  - includes room equipment data for the expandable room cards.

Manual syntax verification was also run with `node --check` over all 67 project JavaScript files: **0 syntax errors**.

---

## 2. Manual end-to-end checks

All checks below were performed through the running UI in Chromium. Where an action changes data, the result was re-read from the server/UI after saving.

### Authentication and accounts

| Check | Result |
|---|---|
| Admin login and logout | Passed |
| Instructor login and logout | Passed |
| Student login and logout | Passed |
| Public account registration | Passed — sign-in link opens a form with Student/Instructor account-type cards plus only Username, Password and Confirm password |
| Automatic Student ID | Passed — registration form has no Student ID field; the automatic-generation note is shown, and the end-to-end test confirms the saved ID on the student profile and admin records |
| Automatic Instructor ID | Passed — Instructor registration generates the next `INS-###` ID and links the Instructor profile |
| Registration validation and login | Passed — mismatched passwords are blocked in the form; the end-to-end test verifies the bcrypt hash, signs in the new Student and Instructor, and confirms Admin accounts are rejected |
| Duplicate username registration | Passed — blocked with “That username is already in use.” |
| Role-based navigation | Passed — each role sees only its portal |
| Unauthenticated `/dashboard` access | Passed — redirected to sign in |

### Admin portal

| Check | Result |
|---|---|
| Dashboard KPIs, today status, charts, recent activity | Passed |
| Activity log with 21+ entries and category filter | Passed |
| Global search for a student and an instructor | Passed — result opened the correct record |
| Quick action button | Passed — opens Schedules & Rooms |
| Notification bell (Admin) | Passed — opens Activity Log |
| Student directory | Passed - no Add or Edit controls; rows, names and view remain |
| Student row opens detailed profile | Passed - mouse click and Enter key; profile shows identity, statuses and class schedule only |
| Edit student UI | Removed - student records are view-only |
| Student detail: information and class schedule | Passed — enrollment summary, weekly timetable and history removed |
| Instructor directory | Passed - no Add or Edit controls; rows, names and view remain |
| Instructor row opens detailed profile | Passed - mouse click; profile includes load, rooms, conflicts and assigned subjects/sections |
| Edit instructor UI | Removed - instructor records are view-only |
| Instructor detail: teaching load and assigned classes | Passed — weekly timetable removed |
| Create subject | Passed — duplicate subject code correctly rejected first |
| Edit subject and persist | Passed |
| Subject detail modal | Passed |
| Edit course | Passed — description field added |
| Add-course modal opens with fields and cancels cleanly | Passed |
| Course rows open a detailed course profile | Passed — row click and Enter/Space; shows program details and summary counts |
| Course profile summary counts | Passed — subjects, active enrolled students and assigned instructors update from live records |
| Room directory, search/filter controls | Passed |
| Create room (`ROOM-031 — Innovation Lab`) | Passed |
| Edit room and persist | Passed — empty building fallback fixed |
| Room detail: photo, details and room schedule | Passed — upload controls moved into Edit room; room schedule table restored |
| Room detail: Timetable modal | Passed — top button opens the weekly timetable without leaving the page |
| Room photo upload | Modal structure verified with current preview and file picker; upload not exercised to preserve demo room artwork |
| Prospectus: add a subject to a year/term | Passed |
| Prospectus: remove a placement | Passed |
| Prospectus: guard when every subject is already placed | Passed — clear toast |
| School Years: edit term dates and persist | Passed |
| Add-school-year modal opens with fields and cancels cleanly | Passed |
| Plot a class: term, course, year level, section, subject, instructor and day pattern | Passed — dependent sections/subjects and year filtering updated correctly |
| Plot a class: automatic valid start times | Passed — MWF showed 60-minute slots; the section’s 7:30 class removed the overlapping starts |
| Plot a class: consecutive period preference | Passed — the first period consecutive with the section’s existing class was marked and auto-selected, ahead of an earlier free gap; valid starts stayed chronological |
| Plot a class: room cards load for the suggested start | Passed — 30 available rooms and 10 planned seats appeared without pressing a separate availability button |
| Plot a class: instructor conflict filtering | Passed — selecting Daniel Cruz removed 7:30 and 8:00; 8:30 became the first valid start |
| Plot a class: automatic room cards | Passed — 31 valid rooms for an open 8:30 slot; no availability button required |
| Room card expansion and details | Passed — room type, capacity, building, equipment and full class time shown |
| Plot a class: changed selections clear stale results | Passed — changing year from 1 to 2 cleared the selected start and room cards before loading new sections |
| Plot a class with live room availability | Passed — successful assignment returned one success toast and refreshed valid starts |
| Room conflict prevention | Passed — booked room is not offered for an overlapping time |
| Backend revalidation on assignment failure | Passed — temporarily reducing a room to 5 seats produced one error toast and no schedule row |
| Duplicate submission prevention | Passed — double-clicking Confirm produced exactly one schedule and one success toast |
| Timetable refresh after assignment | Passed — the new class appeared immediately after switching to Weekly timetable |
| Edit assignment (no-op save) | Passed — “Assignment updated.” |
| Remove a temporary class | Passed — “Class removed from the timetable.” |
| Enrollment list page | Passed |
| Enroll a student from the student record | Passed — Ana Reyes enrolled in IT101 |
| Settings save | Passed |
| Profile page | Passed |
| Change password / change contact | Not exercised through the UI; the same profile endpoints are used by the instructor profile, which loaded correctly |

### Instructor portal

| Check | Result |
|---|---|
| Dashboard removed; portal opens on My Schedule | Passed — no Dashboard navigation item |
| My Subjects navigation removed | Passed — direct `#/subjects` redirects to My Schedule |
| Assigned-subject table on My Schedule | Passed — subject code and name, section with year, day, time, room and class-list count |
| Subject row opens class details | Passed — clicking the row opened the correct class page |
| Class List tab | Passed — only Maria Santos and Ana Reyes, both official active enrollments; 2 of 10 slots shown |
| Class Record tab | Passed — only Attendance, Assignments and Activities columns; no grade column |
| Save class records (attendance, assignments, activities) | Passed — values persisted after reload |
| My Students list and search | Passed |
| My Schedule assigned-subject table | Passed |
| Weekly timetable and print removed from My Schedule | Passed — the page shows only the assigned-subject table |
| Profile page | Passed |

### Student portal

| Check | Result |
|---|---|
| Dashboard removed; portal opens on My Schedule | Passed — no Dashboard navigation item |
| Student sidebar | Passed — light “Main Menu” panel ordered Enrollment, Prospectus, My Subjects, My Schedule, Profile, Logout; active item highlighted |
| Enrollment page and one-section-per-subject selection | Passed |
| Available section shows the 10-student limit | Passed — section card showed “10 seats” |
| Immediate enrollment after server validation | Passed — no approval queue |
| Drop subject | Passed — history retained as Dropped |
| Re-enroll after drop | Passed |
| My Subjects | Passed |
| My Schedule | Passed — table with Subject, Section, Day, Time, Room and Instructor columns; clicking a row opens class details |
| Prospectus grouped by year and term | Passed |
| Student portal shows only the student’s own data | Passed |

### Responsive and visual checks

| Check | Result |
|---|---|
| Desktop sidebar at ~912 CSS px | Passed |
| Sidebar on short windows (≤820 px height) | Passed — compact navigation keeps all Admin items visible |
| Mobile hamburger breakpoint (≤900 px) | Implemented; not exercised in this test session |
| Local fonts, no external CDN requests | Passed |
| CSP with inline timetable/chart positioning | Passed after allowing inline style attributes |

---

## 3. Defects found and fixed during testing

1. **Instructor class subtitle showed `undefined`** — the page read a top-level `section` field while the API returns `schedule.section`. Fixed.
2. **Room timetable blocks showed the room ObjectId instead of the room code** — room-detail sessions now receive `room.roomCode` before normalization.
3. **Room subtitle started with a stray separator** — empty building is now omitted.
4. **Editing seeded rooms failed with “Building is required”** — the seed leaves building empty. The PATCH route now falls back to the existing value or `Main Building`; the create route already defaulted it.
5. **Short-window sidebar hid navigation** — added compact navigation styles for viewports ≤820 px high and made the sidebar nav scrollable.
6. **Missing CSS for list/activity rows and timetable borders** — added.
7. **Admin/Instructor/Student route collisions** — role-aware dispatchers ensure each role lands on the correct page.
8. **Non-Admin notification bell led to an Admin-only activity page** — the bell is now hidden outside the Admin portal.
9. **Grammar polish** — singular/plural labels for students, subjects, sections and sessions.
10. **Reset script left orphan class records/offerings** — reset now deletes both collections.

---

## 4. Current demo data in this installation

Created intentionally while testing. The base seed itself contains no fictional people.

| Item | Value |
|---|---|
| Admin | `admin` / `Admin@12345` |
| Student | `maria.santos` / `Student@12345` — enrolled in IT101 |
| Student | `ana.reyes` / `Student@12345` — registered publicly, enrolled in IT101 |
| Instructor | `daniel.cruz` / `Teacher@12345` |
| Active schedule | IT101, Open Section Year 1, MWF 7:30–8:30, ROOM-001, Daniel Cruz |
| Enrollment | Maria Santos → IT101 (Active); Ana Reyes → IT101 (Active) |
| Class record | Maria Santos — attendance 5, assignments 92, activities 88 |
| Added room | ROOM-031 — Innovation Lab |
| Added subject | IT201 — Data Structures and Algorithms (catalog only, not in a prospectus) |

To remove all people, enrollments, schedules, class records and offerings while keeping Admin/courses/subjects/rooms:

```powershell
npm run reset-data
```

Type `RESET` at the prompt. The script then reseeds base academic data.

---

## 5. Known limitations

### Functional scope

- **Class records are not a grade book.** They store attendance/assignment/activity counts; there is no weighted grade, GPA or transcript computation.
- **No payment, assessment, Registrar or Dean features.** These were intentionally removed.
- **One program per student.** The student’s prospectus is derived from that program.
- **Time is local wall-clock time.** `HH:MM` strings are stored without time-zone conversion.
- **Fixed day patterns.** Only MWF, TTH, F, SATURDAY and SUNDAY are supported, on a 30-minute grid.
- **Printing only.** Print buttons open the browser print dialog; there is no PDF/CSV export or email delivery.
- **In-app notifications only.** The bell opens the activity log; there are no email or SMS notifications.
- **No bulk import/export** for students, subjects or schedules.
- **Single active term.** Enrollment and offering logic are tied to the current term; there is no concurrent multi-term enrollment.
- **No student self-service password reset.** An Admin can set a new password from the student/instructor edit form.

### Deployment / architecture

- **Single-process scheduling lock.** Concurrency protection uses an in-process lock plus a recheck. Running multiple Node instances against one database would require a shared lock or transactions.
- **Local MongoDB assumed.** The documented setup uses `127.0.0.1:27017`; production needs a managed database, backups, TLS and restricted credentials.
- **Local file storage for room photos.** Uploads go to `public/uploads/rooms`; there is no object storage or CDN.
- **No multi-campus support.** Buildings, rooms and terms are global.

### Browser/device coverage

- Tested on Windows 11 with Chromium at desktop width and a short window.
- The mobile hamburger layout is implemented but was not part of this acceptance run.
- Modern browsers with JavaScript enabled are required; the app is an SPA and does not render content without JavaScript.

### Seed/evaluation notes

- The database currently contains the evaluation accounts and demo records listed in section 4.
- Demo passwords must be changed or the accounts deactivated before production use.
- The base seed is idempotent, but the full reset is destructive and intentionally keeps courses, subjects, rooms and Admin accounts.

---

## 6. How to repeat the core checks

1. Start MongoDB and run `npm start`.
2. Open `http://localhost:3002` and sign in as Admin.
3. Create or edit a student/instructor, open Schedules & Rooms, choose a term/course/section/subject and day pattern. The screen marks a consecutive start time when one exists, selects it, and loads the available rooms; confirm one room to plot.
4. Try plotting the same room and time again — the room must not be available. An overlapping class in the same section must be reported as a section conflict.
5. Sign in as the demo instructor, open My Schedule, click a subject, open Class Record, save attendance/assignments/activities, reload and confirm the values persist.
6. Sign in as the demo student, open Enrollment, choose a section and confirm immediate enrollment; then open My Subjects to drop/re-enroll.
7. Run `npm test` — all 28 checks must pass.

---

## 7. Final status

| Area | Status |
|---|---|
| Exactly three portals (Admin, Instructor, Student) | Complete |
| Scheduling, room availability, offerings, conflict prevention | Complete and tested |
| Immediate enrollment | Complete and tested |
| Removed Registrar/Dean/payment/assessment features | Complete |
| UI implementation and responsive layout | Complete for desktop; mobile breakpoint implemented |
| Automatic Student and Instructor ID generation, uniqueness and portal display | Complete and tested |
| Credential-only Student/Instructor registration, role choice, unique usernames and hashed passwords | Complete and tested |
| Automated test suite | 37/37 passed |
| Documentation | `README.md` + this report |
| Blocking defects | None known |
