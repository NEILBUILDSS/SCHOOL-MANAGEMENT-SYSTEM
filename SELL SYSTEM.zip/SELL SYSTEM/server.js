require('dotenv').config();
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const { rateLimit } = require('express-rate-limit');
const connectDB = require('./config/db');
const { seedBaseData, seedDemoUsers } = require('./services/seedService');
const { notFound, errorHandler } = require('./middleware/errors');
const { requireAuth, requireRole } = require('./middleware/auth');

const app = express();
const PORT = Number(process.env.PORT) || 3002;
const mongoUrl = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/sell_system_scheduling';
const secret = process.env.SESSION_SECRET;
if (!secret || secret.length < 32) {
  console.error('SESSION_SECRET must be set in .env and contain at least 32 characters.');
  process.exit(1);
}

app.set('trust proxy', process.env.NODE_ENV === 'production' ? 1 : 0);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      fontSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      formAction: ["'self'"],
      frameAncestors: ["'self'"]
    }
  }
}));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));
app.use(session({
  name: 'sell.sid',
  secret,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  store: MongoStore.create({ mongoUrl, collectionName: 'sessions', ttl: 2 * 60 * 60 }),
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 2 * 60 * 60 * 1000
  }
}));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 40,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: { message: 'Too many attempts. Please wait and try again.' }
});

app.use('/css', express.static(path.join(__dirname, 'public', 'css'), { fallthrough: false }));
app.use('/js', express.static(path.join(__dirname, 'public', 'js'), { fallthrough: false }));
app.use('/images', express.static(path.join(__dirname, 'public', 'images'), { fallthrough: false }));
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads'), { fallthrough: false }));

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/index.html', (req, res) => res.redirect('/'));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));
app.get('/register.html', (req, res) => res.redirect('/register'));

// Signed-in shell. The client router decides which portal page to show, and
// every API behind it enforces the role again on the server.
app.get('/dashboard', async (req, res, next) => {
  try {
    if (!req.session?.userId) return res.redirect('/');
    const User = require('./models/User');
    const user = await User.findById(req.session.userId).select('role status').lean();
    if (!user || user.status !== 'Active') {
      req.session.destroy(() => {});
      return res.redirect('/');
    }
    res.sendFile(path.join(__dirname, 'views', 'dashboard.html'));
  } catch (err) { next(err); }
});

app.use('/api/auth', authLimiter, require('./routes/auth'));
app.use('/api/register', authLimiter, require('./routes/register'));
app.use('/api/semesters', require('./routes/semesters'));
app.use('/api/subject-offerings', require('./routes/subjectOfferings'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/prospectus', require('./routes/prospectus'));
app.use('/api/student-portal', require('./routes/studentPortal'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/students', require('./routes/students'));
app.use('/api/instructors', require('./routes/instructors'));
app.use('/api/subjects', require('./routes/subjects'));
app.use('/api/rooms', require('./routes/rooms'));
app.use('/api/schedules', require('./routes/schedules'));
app.use('/api/scheduling', require('./routes/schedulingModule'));
app.use('/api/courses', require('./routes/courses'));
app.use('/api/enrollments', require('./routes/enrollments'));
app.use('/api/activity-logs', require('./routes/activityLogs'));
app.use('/api/profile', require('./routes/profile'));
app.use('/api/portal', require('./routes/portal'));
app.use('/api/instructor-portal', require('./routes/instructorPortal'));

app.use(notFound);
app.use(errorHandler);

(async () => {
  try {
    await connectDB();
    const seeded = await seedBaseData();
    console.log(`Base data ready: 3 courses, 7 subjects, 30 rooms, 28 schedule options. New schedules inserted this run: ${seeded.createdSchedules}`);
    await seedDemoUsers();
    console.log('Demo users ready: admin / Admin@12345, maria.santos / Student@12345, daniel.cruz / Teacher@12345');
    app.listen(PORT, () => console.log(`Southern Canillo College — School Scheduling: http://localhost:${PORT}`));
  } catch (err) {
    console.error('Startup failed:', err);
    process.exit(1);
  }
})();
