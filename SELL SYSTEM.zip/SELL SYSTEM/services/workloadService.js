const Schedule = require('../models/Schedule');
const Instructor = require('../models/Instructor');
const { getSettings, toMinutes, time12 } = require('./settingsService');

// Weekday order used throughout the report.
const DAY_KEYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const DAY_FULL = { Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday' };

// A gap at least this long between two classes on the same day counts as idle
// time. It is what makes a timetable feel like ping-pong: the instructor drives
// in, teaches once, and drives out. 60 minutes is longer than any single MWF or
// TTh session, so it can never be a normal changeover.
const LONG_GAP_MINUTES = 60;

const round2 = n => Math.round(n * 100) / 100;

// Active schedules for the term being planned. Schedules with no semester are
// the ones still being placed, and they occupy instructors and rooms, so they
// count - the same rule routes/schedulingModule.js uses for room blocking.
function semesterFilter(semesterId) {
  if (!semesterId) return { status: 'Active' };
  return {
    status: 'Active',
    $or: [{ semester: semesterId }, { semester: null }, { semester: { $exists: false } }]
  };
}

// One instructor's hours for one day: total minutes, the idle gaps between
// consecutive classes, and whether the configured daily target is met.
function analyseDay(sessions, dailyTargetMinutes) {
  const sorted = [...sessions].sort((a, b) => a.start - b.start);
  const minutesTaught = sorted.reduce((sum, s) => sum + (s.end - s.start), 0);

  const gaps = [];
  for (let i = 1; i < sorted.length; i++) {
    const gap = sorted[i].start - sorted[i - 1].end;
    if (gap > 0) {
      gaps.push({
        from: sorted[i - 1].end,
        to: sorted[i].start,
        minutes: gap,
        long: gap >= LONG_GAP_MINUTES,
        fromLabel: time12(sorted[i - 1].end),
        toLabel: time12(sorted[i].start)
      });
    }
  }
  const idleMinutes = gaps.reduce((sum, g) => sum + g.minutes, 0);

  return {
    classes: sorted.length,
    minutes: minutesTaught,
    hours: round2(minutesTaught / 60),
    firstStart: sorted.length ? sorted[0].start : null,
    lastEnd: sorted.length ? sorted[sorted.length - 1].end : null,
    gaps,
    gapCount: gaps.length,
    longGapCount: gaps.filter(g => g.long).length,
    idleMinutes,
    // Met only when the hours actually taught reach the configured target.
    atTarget: minutesTaught >= dailyTargetMinutes
  };
}

/**
 * Teaching load for every instructor in a term, computed live from Active
 * schedules.
 *
 * Nothing is cached on the Instructor document on purpose: a stored total
 * drifts the moment a schedule is edited, and a stale number is exactly how a
 * system ends up reporting somebody as "fully loaded" when they are not. Every
 * figure here can be traced back to a schedule.
 *
 * Schedules with no instructor (TBA) are reported separately rather than being
 * credited to anybody - unassigned hours are not load.
 */
async function instructorWorkloads({ semesterId = null } = {}) {
  const [settings, instructors, schedules] = await Promise.all([
    getSettings(),
    Instructor.find({ status: 'Active' }).sort({ lastName: 1, firstName: 1 }).lean(),
    Schedule.find(semesterFilter(semesterId))
      .populate('subject', 'subjectCode subjectName units')
      .populate('instructor', 'firstName lastName')
      .populate('room', 'roomCode')
      .lean()
  ]);

  const targetPerDay = (settings.dailyTargetHours || 8) * 60;

  const byInstructor = new Map(instructors.map(i => [String(i._id), []]));
  const tba = [];

  for (const s of schedules) {
    const start = toMinutes(s.startTime);
    const end = toMinutes(s.endTime);
    const entry = {
      scheduleId: String(s._id),
      subject: s.subject ? s.subject.subjectCode : ' - ',
      room: s.room ? s.room.roomCode : ' - ',
      start,
      end,
      minutes: Math.max(0, end - start)
    };
    const key = s.instructor ? String(s.instructor._id || s.instructor) : null;
    if (key && byInstructor.has(key)) {
      for (const day of s.weekdays || []) {
        if (!byInstructor.get(key)[day]) byInstructor.get(key)[day] = [];
        byInstructor.get(key)[day].push(entry);
      }
    } else {
      // TBA: the hours are real, but they belong to nobody yet.
      tba.push({ ...entry, days: s.weekdays || [] });
    }
  }

  const rows = instructors.map(instructor => {
    const perDay = byInstructor.get(String(instructor._id)) || {};
    const days = {};
    let weeklyMinutes = 0;
    let teachingDays = 0;
    let daysAtTarget = 0;
    let longGaps = 0;
    let idleMinutes = 0;
    let maxDayMinutes = 0;
    let maxDay = null;

    for (const key of DAY_KEYS) {
      const sessions = perDay[key] || [];
      if (!sessions.length) continue;
      const day = analyseDay(sessions, targetPerDay);
      days[key] = { label: DAY_FULL[key], ...day };
      weeklyMinutes += day.minutes;
      teachingDays++;
      if (day.atTarget) daysAtTarget++;
      longGaps += day.longGapCount;
      idleMinutes += day.idleMinutes;
      if (day.minutes > maxDayMinutes) { maxDayMinutes = day.minutes; maxDay = key; }
    }

    // Honest status, derived per day rather than from a weekly total. An
    // instructor who teaches 6 hours across three days is not "fully loaded"
    // just because the week looks busy.
    let status;
    if (!teachingDays) status = 'No classes assigned';
    else if (daysAtTarget === teachingDays) status = 'Fully loaded';
    else status = `Below target on ${teachingDays - daysAtTarget} of ${teachingDays} day(s)`;

    return {
      _id: instructor._id,
      instructorId: instructor.instructorId || '',
      name: `${instructor.firstName || ''} ${instructor.lastName || ''}`.trim(),
      department: instructor.department,
      weeklyMinutes,
      weeklyHours: round2(weeklyMinutes / 60),
      teachingDays,
      days,
      maxDayMinutes,
      maxDay: maxDay ? DAY_FULL[maxDay] : null,
      daysAtTarget,
      targetPerDayMinutes: targetPerDay,
      targetPerDayHours: settings.dailyTargetHours,
      // A full teaching week at the configured target - shown as context, not
      // as a pass/fail bar, because a 3-day load can never reach it.
      targetWeeklyMinutes: targetPerDay * 5,
      targetWeeklyHours: round2(targetPerDay * 5 / 60),
      loaded: teachingDays > 0 && daysAtTarget === teachingDays,
      status,
      longGaps,
      idleMinutes
    };
  });

  const tbaMinutes = tba.reduce((sum, e) => sum + e.minutes * e.days.length, 0);
  const assignedMinutes = rows.reduce((sum, r) => sum + r.weeklyMinutes, 0);
  const allScheduledMinutes = assignedMinutes + tbaMinutes;

  return {
    settings: {
      dayStart: settings.dayStart,
      dayEnd: settings.dayEnd,
      dailyTargetHours: settings.dailyTargetHours,
      activeRoomLimit: settings.activeRoomLimit,
      sessionRules: settings.sessionRules
    },
    instructors: rows,
    totals: {
      assignedMinutes,
      assignedHours: round2(assignedMinutes / 60),
      targetWeeklyMinutes: targetPerDay * 5,
      targetWeeklyHours: round2(targetPerDay * 5 / 60)
    },
    unassigned: {
      schedules: tba.length,
      // Each schedule contributes its session length once per class day.
      weeklyMinutes: tbaMinutes,
      weeklyHours: round2(tbaMinutes / 60),
      // Share of all scheduled teaching that still has no instructor. This is
      // the real constraint on "are we fully staffed", not any one load.
      shareOfAllScheduled: allScheduledMinutes ? round2(tbaMinutes / allScheduledMinutes) : 0,
      items: tba
    }
  };
}

/**
 * Room demand per day: how many rooms are needed at the busiest moment, and
 * whether that exceeds the configured planning limit.
 *
 * A shortage is REPORTED, never silently resolved into a conflict - the
 * registrar has to decide whether to open another room or move a class.
 */
async function roomDemand({ semesterId = null } = {}) {
  const [settings, schedules] = await Promise.all([
    getSettings(),
    Schedule.find(semesterFilter(semesterId)).populate('subject', 'subjectCode').lean()
  ]);

  const perDay = {};
  for (const key of DAY_KEYS) {
    const events = [];
    for (const s of schedules) {
      if (!(s.weekdays || []).includes(key)) continue;
      events.push({ at: toMinutes(s.startTime), delta: 1, end: toMinutes(s.endTime), schedule: s });
      events.push({ at: toMinutes(s.endTime), delta: -1, end: toMinutes(s.endTime), schedule: s });
    }
    // Sort by time, ending before starting at the same minute so back-to-back
    // classes never look like an overlap.
    events.sort((a, b) => a.at - b.at || a.delta - b.delta);

    let current = 0;
    let peak = 0;
    let peakAt = null;
    for (const e of events) {
      current += e.delta;
      if (current > peak) { peak = current; peakAt = e.at; }
    }
    if (!peak) continue;

    perDay[key] = {
      label: DAY_FULL[key],
      peakConcurrent: peak,
      peakAt,
      peakAtLabel: time12(peakAt),
      scheduledClasses: events.filter(e => e.delta === 1).length
    };
  }

  const limit = settings.activeRoomLimit || 0;   // 0 means "every stored room"
  const shortages = Object.entries(perDay)
    .filter(([, d]) => limit > 0 && d.peakConcurrent > limit)
    .map(([key, d]) => ({
      day: d.label,
      dayKey: key,
      needed: d.peakConcurrent,
      available: limit,
      short: d.peakConcurrent - limit,
      atLabel: d.peakAtLabel,
      message: `${d.label} needs ${d.peakConcurrent} rooms at ${d.peakAtLabel} but only ${limit} are planned.`
    }));

  return {
    activeRoomLimit: limit,
    unlimited: limit === 0,
    perDay,
    shortages,
    feasible: shortages.length === 0
  };
}

module.exports = {
  instructorWorkloads,
  roomDemand,
  DAY_KEYS,
  DAY_FULL,
  LONG_GAP_MINUTES
};
