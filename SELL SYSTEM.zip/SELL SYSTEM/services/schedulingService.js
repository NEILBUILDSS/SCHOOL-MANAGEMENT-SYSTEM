const Schedule = require('../models/Schedule');
const Enrollment = require('../models/Enrollment');
const User = require('../models/User');
const Student = require('../models/Student');
const Subject = require('../models/Subject');
const Room = require('../models/Room');
const Instructor = require('../models/Instructor');
const { validateTime, httpError } = require('../utils/validation');
const settingsService = require('./settingsService');
const { getCurrentSemester } = require('./semesterService');

let mutationQueue = Promise.resolve();

async function withSchedulingLock(task) {
  let release;
  const next = new Promise(resolve => { release = resolve; });
  const previous = mutationQueue;
  mutationQueue = mutationQueue.then(() => next, () => next);
  await previous.catch(() => {});
  try {
    return await task();
  } finally {
    release();
  }
}

function minutes(time) {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

function overlaps(aStart, aEnd, bStart, bEnd) {
  return minutes(aStart) < minutes(bEnd) && minutes(bStart) < minutes(aEnd);
}

function sameDay(a, b) {
  return a.some(day => b.includes(day));
}

// Schedule rows store a section as course + year + sectionType + blockLabel.
// Missing legacy values mean the schema default (Open section), not a separate
// unnamed section.
const refId = value => (value && typeof value === 'object' && value._id ? String(value._id) : String(value ?? ''));
const normSectionType = value => (value === 'Block' ? 'Block' : 'Open');
const normBlockLabel = value => String(value || '').trim().toUpperCase();

function isSameSection(a, b) {
  return refId(a.course) === refId(b.course)
    && Number(a.yearLevel) === Number(b.yearLevel)
    && normSectionType(a.sectionType) === normSectionType(b.sectionType)
    && normBlockLabel(a.blockLabel) === normBlockLabel(b.blockLabel);
}

function sectionName(section) {
  const year = `Year ${Number(section.yearLevel) || '—'}`;
  return normSectionType(section.sectionType) === 'Block'
    ? `${section.blockLabel ? `Block ${section.blockLabel}` : 'Block Section'} · ${year}`
    : `Open Section · ${year}`;
}

// ---------------------------------------------------------------------------
// Room daily-usage helpers (8-hour rule).
//
// A room may host at most settings.dailyTargetHours of classes per school day
// (default 8). Usage is measured per room, per day, per semester from the saved
// start/end times of Active schedules; overlapping intervals are merged so no
// minute is counted twice, and back-to-back classes are a legal fit, never a
// conflict.
const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function mergeIntervals(intervals) {
  const sorted = intervals
    .map(i => ({ start: i.start, end: i.end }))
    .filter(i => Number.isFinite(i.start) && Number.isFinite(i.end) && i.end > i.start)
    .sort((a, b) => a.start - b.start || a.end - b.end);
  const merged = [];
  for (const interval of sorted) {
    const last = merged[merged.length - 1];
    if (last && interval.start <= last.end) last.end = Math.max(last.end, interval.end);
    else merged.push({ ...interval });
  }
  return merged;
}

function sumMergedMinutes(intervals) {
  return mergeIntervals(intervals).reduce((sum, i) => sum + (i.end - i.start), 0);
}

function scheduleDayIntervals(schedules, day) {
  const intervals = [];
  for (const schedule of schedules) {
    if (!schedule.weekdays || !schedule.weekdays.includes(day)) continue;
    const start = minutes(schedule.startTime);
    const end = minutes(schedule.endTime);
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) continue;
    intervals.push({ start, end });
  }
  return intervals;
}

// Pure verdict for placing a candidate class window into one room's existing
// schedule set (already scoped by the caller to room + semester).
function evaluateRoomTimeWindow(schedules, weekdays, startTime, endTime, dailyLimitMinutes) {
  const limit = Number(dailyLimitMinutes) > 0 ? Number(dailyLimitMinutes) : 8 * 60;
  const days = [...new Set(Array.isArray(weekdays) ? weekdays : [])].filter(d => WEEKDAYS.includes(d));
  const start = minutes(startTime);
  const end = minutes(endTime);
  const duration = end - start;
  const hasWindow = Number.isFinite(start) && Number.isFinite(end) && duration > 0;
  const perDay = [];
  let ok = true;
  let reason = '';
  for (const day of days) {
    const merged = mergeIntervals(scheduleDayIntervals(schedules, day));
    const occupiedMinutes = merged.reduce((sum, i) => sum + (i.end - i.start), 0);
    // Adjacent classes do not overlap: one ending at 9:00 allows another starting at 9:00.
    const conflict = hasWindow ? merged.some(i => start < i.end && i.start < end) : false;
    let dayOk = true;
    let dayReason = '';
    if (conflict) {
      dayOk = false;
      dayReason = `The room already has a class at that time on ${day}.`;
    } else if (hasWindow && occupiedMinutes + duration > limit) {
      dayOk = false;
      const hours = Math.round(limit / 60);
      dayReason = occupiedMinutes >= limit
        ? `The room already reached its ${hours}-hour daily limit on ${day}.`
        : `This schedule would exceed the room's ${hours}-hour daily limit on ${day}.`;
    }
    if (!dayOk && !reason) reason = dayReason;
    if (!dayOk) ok = false;
    perDay.push({ day, occupiedMinutes, mergedIntervals: merged, conflict, ok: dayOk, reason: dayReason });
  }
  const busiestMinutes = perDay.reduce((max, d) => Math.max(max, d.occupiedMinutes), 0);
  return { ok, reason, duration: hasWindow ? duration : 0, busiestMinutes, perDay };
}

// Daily limit in minutes from the stored scheduling settings (default 8 hours).
function dailyLimitMinutesFrom(settings) {
  const hours = Number(settings && settings.dailyTargetHours) > 0 ? Number(settings.dailyTargetHours) : 8;
  return hours * 60;
}

// Active schedules of one room inside one semester. Schedules with no semester
// belong to the period they were made for, so - like semesterScheduleFilter in
// the plotting module - they count against the CURRENT semester only.
async function loadRoomSemesterSchedules(roomId, semesterId, excludeScheduleId = null) {
  const filter = { room: roomId, status: 'Active' };
  if (semesterId) {
    const current = await getCurrentSemester();
    // $or must sit at the top level of the filter - it is not a valid field value.
    if (current && String(current._id) === String(semesterId)) {
      filter.$or = [{ semester: semesterId }, { semester: null }];
    } else {
      filter.semester = semesterId;
    }
  }
  if (excludeScheduleId) filter._id = { $ne: excludeScheduleId };
  return Schedule.find(filter).select('weekdays startTime endTime room semester status').lean();
}

// Hard daily room limit, rechecked immediately before a schedule is written.
async function checkRoomDailyLimit(candidate, excludeScheduleId = null, semesterId = null) {
  if (candidate.status !== 'Active') return null;
  const limit = dailyLimitMinutesFrom(await settingsService.getSettings());
  const existing = await loadRoomSemesterSchedules(candidate.room._id, semesterId, excludeScheduleId);
  const verdict = evaluateRoomTimeWindow(existing, candidate.weekdays, candidate.startTime, candidate.endTime, limit);
  if (verdict.ok) return verdict;
  throw httpError(409, `Room ${candidate.room.roomCode}: ${verdict.reason}`);
}

async function validateScheduleBasics(data) {
  const weekdays = Array.isArray(data.weekdays) ? [...new Set(data.weekdays)] : [];
  const allowed = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  if (!weekdays.length || weekdays.some(d => !allowed.includes(d))) throw httpError(400, 'Choose valid class days.');

  const startTime = validateTime(data.startTime, 'Start time');
  const endTime = validateTime(data.endTime, 'End time');
  const start = minutes(startTime), end = minutes(endTime);

  // The school day and the session-length rule are configurable, so both are
  // read from settings rather than the old hard-coded 7:30 AM - 8:30 PM window.
  const settings = await settingsService.getSettings();
  const dayStart = minutes(settings.dayStart), dayEnd = minutes(settings.dayEnd);
  if (start < dayStart || end > dayEnd || start >= end) {
    throw httpError(400, `Classes must be within ${settingsService.time12(settings.dayStart)} to ${settingsService.time12(settings.dayEnd)} and end after they start.`);
  }

  const subject = await Subject.findById(data.subject);
  if (!subject || subject.status !== 'Active') throw httpError(400, 'Select a valid active subject.');
  const room = await Room.findById(data.room);
  if (!room || room.status !== 'Active') throw httpError(400, 'Select a valid active room.');

  // Session length follows the day pattern: MWF runs 1 hour, TTh runs 1.5 hours.
  // Patterns with no explicit rule fall back to the legacy units rule.
  const pattern = settingsService.patternKeyFor(weekdays);
  const session = settingsService.sessionMinutesFor(settings, pattern, subject.units, weekdays.length);
  if (session.error) throw httpError(400, session.error);
  const duration = session.minutes;
  if (end - start !== duration) {
    throw httpError(400, `A ${settingsService.patternLabelFor(pattern)} class must last ${duration} minutes per session. Starting at ${settingsService.time12(startTime)} it has to end at ${settingsService.time12(settingsService.minutesToHHMM(start + duration))}.`);
  }

  const breakHit = settingsService.breakCollision(settings, startTime, endTime);
  if (breakHit) {
    throw httpError(400, `This class would run through the ${breakHit.label} break (${settingsService.time12(breakHit.startTime)} - ${settingsService.time12(breakHit.endTime)}). Choose a slot that clears the break.`);
  }

  if (subject.laboratoryRequired) {
    if (room.roomType !== 'Laboratory') throw httpError(400, 'Laboratory subjects must use a laboratory room.');
    if (duration < 60 || duration > 180) throw httpError(400, 'Laboratory classes must last 60 to 180 minutes in 30-minute increments.');
  } else if (duration < 30 || duration > 360) {
    throw httpError(400, 'Class sessions must last 30 to 360 minutes.');
  }

  const courseId = String(data.course || subject.course);
  if (String(subject.course) !== courseId) throw httpError(400, 'Schedule course must match the subject course.');
  const yearLevel = Number(data.yearLevel);
  if (![1,2,3,4].includes(yearLevel)) throw httpError(400, 'Year level must be 1 to 4.');

  let instructor = null;
  if (data.instructor) {
    instructor = await Instructor.findById(data.instructor);
    if (!instructor || instructor.status !== 'Active') throw httpError(400, 'Select a valid active instructor.');
  }
  const status = data.status === 'Active' ? 'Active' : 'Inactive';
  if (status === 'Active' && !instructor) throw httpError(400, 'Assign an instructor before activating a schedule.');

  return { subject, room, instructor, weekdays, startTime, endTime, course: subject.course, yearLevel, status };
}

async function checkScheduleConflicts(candidate, excludeScheduleId = null, semesterId = null) {
  if (candidate.status !== 'Active') return;
  const filter = { status: 'Active', weekdays: { $in: candidate.weekdays } };
  // Room and instructor availability are scoped to the semester being planned:
  // a class booked for one semester does not block another, and schedules with
  // no semester count against the current period only.
  // $or must sit at the top level of the filter - it is not a valid field value.
  if (semesterId) {
    const current = await getCurrentSemester();
    if (current && String(current._id) === String(semesterId)) {
      filter.$or = [{ semester: semesterId }, { semester: null }];
    } else {
      filter.semester = semesterId;
    }
  }
  if (excludeScheduleId) filter._id = { $ne: excludeScheduleId };
  const others = await Schedule.find(filter).lean();
  for (const other of others) {
    if (!sameDay(candidate.weekdays, other.weekdays)) continue;
    if (!overlaps(candidate.startTime, candidate.endTime, other.startTime, other.endTime)) continue;
    if (String(other.room) === String(candidate.room._id)) throw httpError(409, 'Schedule conflict: the selected room is already in use at that time.');
    if (candidate.instructor && other.instructor && String(other.instructor) === String(candidate.instructor._id)) throw httpError(409, 'Schedule conflict: the selected instructor already has a class at that time.');
    if (isSameSection(candidate, other)) {
      throw httpError(409, `Schedule conflict: ${sectionName(candidate)} already has a class on ${other.weekdays.join(', ')} at ${settingsService.time12(other.startTime)} - ${settingsService.time12(other.endTime)}.`);
    }
  }
}

async function checkExistingEnrollmentsForSchedule(candidate, scheduleId) {
  if (candidate.status !== 'Active') return;
  const enrollments = await Enrollment.find({ schedule: scheduleId, status: 'Active' }).populate('student').lean();
  const seats = settingsService.seatsFor(candidate.room.capacity, await settingsService.getSettings());
  if (enrollments.length > seats) throw httpError(409, `Only ${seats} students can be enrolled here (${enrollments.length} already enrolled). This room holds ${candidate.room.capacity} and the section limit is ${seats}.`);

  for (const enrollment of enrollments) {
    const student = enrollment.student;
    if (!student) continue;
    if (String(student.course) !== String(candidate.course) || Number(student.yearLevel) !== Number(candidate.yearLevel)) {
      throw httpError(409, `Schedule change would make an existing enrollment invalid for student ${student.studentId}.`);
    }
    const otherEnrollments = await Enrollment.find({ student: student._id, status: 'Active', schedule: { $ne: scheduleId } }).populate({ path: 'schedule', match: { status: 'Active' } }).lean();
    for (const otherEnrollment of otherEnrollments) {
      const other = otherEnrollment.schedule;
      if (String(otherEnrollment.subject) === String(candidate.subject._id)) {
        throw httpError(409, `Schedule change would create a duplicate active subject for student ${student.studentId}.`);
      }
      if (!other) continue;
      if (sameDay(candidate.weekdays, other.weekdays) && overlaps(candidate.startTime, candidate.endTime, other.startTime, other.endTime)) {
        throw httpError(409, `Schedule change would create a time conflict for student ${student.studentId}.`);
      }
    }
  }
}

async function validateEnrollment({ studentId, scheduleId, semesterId, excludeEnrollmentId = null }) {
  const student = await Student.findById(studentId);
  if (!student) throw httpError(400, 'Select a valid student.');
  // Student status is now derived from enrollment, so check the login account instead.
  const account = await User.findById(student.user).select('status').lean();
  if (!account || account.status !== 'Active') throw httpError(400, 'Select a valid active student.');
  const schedule = await Schedule.findById(scheduleId).populate('subject room instructor');
  if (!schedule || schedule.status !== 'Active' || schedule.subject?.status !== 'Active' || schedule.room?.status !== 'Active' || (schedule.instructor && schedule.instructor.status !== 'Active')) {
    throw httpError(400, 'Students can only be enrolled in an active schedule with active subject, room, and instructor records.');
  }
  if (String(student.course) !== String(schedule.course)) throw httpError(409, 'The student course does not match this schedule.');
  if (Number(student.yearLevel) !== Number(schedule.yearLevel)) throw httpError(409, 'The student year level does not match this schedule.');

  const duplicateFilter = { student: student._id, subject: schedule.subject._id, status: 'Active' };
  if (excludeEnrollmentId) duplicateFilter._id = { $ne: excludeEnrollmentId };
  if (await Enrollment.exists(duplicateFilter)) throw httpError(409, 'The student already has an active enrollment in this subject.');

  const activeCountFilter = { schedule: schedule._id, status: 'Active' };
  if (excludeEnrollmentId) activeCountFilter._id = { $ne: excludeEnrollmentId };
  const activeCount = await Enrollment.countDocuments(activeCountFilter);
  const seats = settingsService.seatsFor(schedule.room.capacity, await settingsService.getSettings());
  if (activeCount >= seats) throw httpError(409, `This schedule has reached its limit of ${seats} students (${activeCount} enrolled). The room holds ${schedule.room.capacity}.`);

  const otherFilter = { student: student._id, status: 'Active' };
  if (excludeEnrollmentId) otherFilter._id = { $ne: excludeEnrollmentId };
  const others = await Enrollment.find(otherFilter).populate({ path: 'schedule', match: { status: 'Active' } }).lean();
  for (const enrollment of others) {
    const other = enrollment.schedule;
    if (!other || String(other._id) === String(schedule._id)) continue;
    if (sameDay(schedule.weekdays, other.weekdays) && overlaps(schedule.startTime, schedule.endTime, other.startTime, other.endTime)) {
      throw httpError(409, 'Enrollment conflict: the student already has another class at that time.');
    }
  }
  return { student, schedule };
}

module.exports = {
  withSchedulingLock,
  validateScheduleBasics,
  checkScheduleConflicts,
  checkExistingEnrollmentsForSchedule,
  validateEnrollment,
  checkRoomDailyLimit,
  loadRoomSemesterSchedules,
  evaluateRoomTimeWindow,
  mergeIntervals,
  sumMergedMinutes,
  dailyLimitMinutesFrom,
  WEEKDAYS,
  minutes,
  overlaps,
  sameDay,
  isSameSection,
  sectionName,
  normSectionType,
  normBlockLabel
};
