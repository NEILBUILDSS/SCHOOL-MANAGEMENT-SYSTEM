const Schedule = require('../models/Schedule');
const Instructor = require('../models/Instructor');
const Room = require('../models/Room');
const { getSettings, toMinutes, sessionMinutesFor, patternKeyFor, time12, minutesToHHMM } = require('./settingsService');

// A gap at least this long between two of an instructor's classes on the same
// day is what the timetable is supposed to avoid: one class in the morning, a
// long wait, another in the afternoon. Longer than any single session, so it
// can never be an ordinary changeover.
const LONG_GAP = 60;

const round2 = n => Math.round(n * 100) / 100;
const at = m => time12(minutesToHHMM(m));

function semesterFilter(semesterId) {
  if (!semesterId) return { status: 'Active' };
  return { status: 'Active', $or: [{ semester: semesterId }, { semester: null }, { semester: { $exists: false } }] };
}

const overlaps = (aStart, aEnd, bStart, bEnd) => aStart < bEnd && bStart < aEnd;
const sameDay = (a, b) => (a || []).some(d => (b || []).includes(d));

/**
 * Read-only suggestions for a term.
 *
 * Nothing here writes. Every suggestion comes with the reason it cannot simply
 * be applied - a room already booked, an instructor already teaching, a section
 * already elsewhere - because a timetable rule that silently rewrites itself is
 * worse than one that explains itself.
 */
async function suggestions({ semesterId = null } = {}) {
  const [settings, instructors, schedules, rooms] = await Promise.all([
    getSettings(),
    Instructor.find({ status: 'Active' }).sort({ lastName: 1, firstName: 1 }).lean(),
    Schedule.find(semesterFilter(semesterId))
      .populate('subject', 'subjectCode subjectName units laboratoryRequired')
      .populate('room', 'roomCode roomName roomType capacity')
      .populate('course', 'code name')
      .populate({ path: 'instructor', select: 'firstName lastName instructorId' })
      .lean(),
    Room.find({ status: 'Active' }).select('roomCode roomType capacity status').lean()
  ]);

  const name = p => p ? `${p.firstName || ''} ${p.lastName || ''}`.trim() : 'TBA';
  const label = s => s.subject ? `${s.subject.subjectCode} - ${s.subject.subjectName}` : ' - ';
  const sectionOf = s => [s.course ? s.course.code : '', s.yearLevel ? `Year ${s.yearLevel}` : '',
    s.sectionType || '', s.blockLabel || ''].filter(Boolean).join(' ');
  const when = s => `${(s.weekdays || []).join('/')} ${time12(s.startTime)} - ${time12(s.endTime)}`;

  const norm = blockLabel => String(blockLabel || '').trim().toUpperCase();
  const isLab = s => Boolean(s.subject && s.subject.laboratoryRequired);

  // ---- current load per instructor, and busy lookup -------------------------
  const loadMinutes = new Map(instructors.map(i => [String(i._id), 0]));
  for (const s of schedules) {
    if (!s.instructor) continue;
    const key = String(s.instructor._id || s.instructor);
    if (!loadMinutes.has(key)) continue;
    const len = toMinutes(s.endTime) - toMinutes(s.startTime);
    loadMinutes.set(key, loadMinutes.get(key) + len * (s.weekdays || []).length);
  }

  const busyInstructor = (id, day, start, end, exceptScheduleId) =>
    schedules.find(o => o.instructor && String(o.instructor._id || o.instructor) === String(id)
      && (o.weekdays || []).includes(day)
      && String(o._id) !== String(exceptScheduleId)
      && overlaps(start, end, toMinutes(o.startTime), toMinutes(o.endTime)));

  const busyRoom = (roomId, day, start, end, exceptScheduleId) =>
    schedules.find(o => o.room && String(o.room._id || o.room) === String(roomId)
      && (o.weekdays || []).includes(day)
      && String(o._id) !== String(exceptScheduleId)
      && overlaps(start, end, toMinutes(o.startTime), toMinutes(o.endTime)));

  const busySection = (courseId, yearLevel, sectionType, blockLabel, day, start, end, exceptScheduleId) =>
    schedules.find(o => o.course && courseId
      && String(o.course._id || o.course) === String(courseId)
      && Number(o.yearLevel) === Number(yearLevel)
      && o.sectionType === sectionType
      && norm(o.blockLabel) === norm(blockLabel)
      && (o.weekdays || []).includes(day)
      && String(o._id) !== String(exceptScheduleId)
      && overlaps(start, end, toMinutes(o.startTime), toMinutes(o.endTime)));

  // ---------------------------------------------------------------- 1. TBA
  // The single biggest win: hours that belong to nobody cannot be taught.
  const unassignedInstructors = [];
  for (const s of schedules.filter(x => !x.instructor)) {
    const start = toMinutes(s.startTime), end = toMinutes(s.endTime);
    const candidates = [];
    const blocked = new Set();

    for (const i of instructors) {
      const key = String(i._id);
      const clash = (s.weekdays || []).find(d => busyInstructor(key, d, start, end, s._id));
      if (clash) { blocked.add(name(i)); continue; }
      const labClash = isLab(s) && s.room && s.room.roomType !== 'Laboratory';
      if (labClash) continue;
      candidates.push({
        _id: i._id,
        name: name(i),
        instructorId: i.instructorId || '',
        currentWeeklyHours: round2((loadMinutes.get(key) || 0) / 60),
        newWeeklyHours: round2(((loadMinutes.get(key) || 0) + (end - start) * (s.weekdays || []).length) / 60)
      });
    }
    // Lightest load first - the point is to balance, not to pile more on.
    candidates.sort((a, b) => a.currentWeeklyHours - b.currentWeeklyHours);

    unassignedInstructors.push({
      schedule: String(s._id),
      subject: label(s),
      section: sectionOf(s),
      room: s.room ? s.room.roomCode : ' - ',
      days: s.weekdays || [],
      time: `${time12(s.startTime)} - ${time12(s.endTime)}`,
      candidates: candidates.slice(0, 3),
      blockedBy: candidates.length ? null
        : `every instructor already teaches at ${when(s)}`
    });
  }

  // ------------------------------------------------------- 2. Session length
  // Sessions that do not match the day-pattern rule, with the end time they
  // should have and whatever stands in the way of simply moving them.
  const sessionLengths = [];
  for (const s of schedules) {
    const start = toMinutes(s.startTime), end = toMinutes(s.endTime);
    const pattern = patternKeyFor(s.weekdays || []);
    const expected = sessionMinutesFor(settings, pattern, s.subject ? s.subject.units : 0, (s.weekdays || []).length);
    if (expected.error || end - start === expected.minutes) continue;

    const suggestedEnd = start + expected.minutes;
    const blockers = [];
    if (suggestedEnd > toMinutes(settings.dayEnd)) {
      blockers.push(`it would finish at ${at(suggestedEnd)}, after the school day ends at ${time12(settings.dayEnd)}`);
    }
    for (const day of s.weekdays || []) {
      if (s.room && busyRoom(s.room._id, day, start, suggestedEnd, s._id)) {
        blockers.push(`${s.room.roomCode} is already booked later that ${day}`);
        break;
      }
    }
    if (s.instructor) {
      for (const day of s.weekdays || []) {
        if (busyInstructor(s.instructor._id, day, start, suggestedEnd, s._id)) {
          blockers.push(`${name(s.instructor)} is already teaching later that ${day}`);
          break;
        }
      }
    }

    sessionLengths.push({
      schedule: String(s._id),
      subject: label(s),
      section: sectionOf(s),
      days: s.weekdays || [],
      pattern: pattern || 'no rule - falls back to subject units',
      current: { time: `${time12(s.startTime)} - ${time12(s.endTime)}`, minutes: end - start },
      suggested: { time: `${time12(s.startTime)} - ${at(suggestedEnd)}`, minutes: expected.minutes },
      blockers
    });
  }

  // ------------------------------------------------------------ 3. Idle gaps
  // A long empty stretch in an instructor's day. The suggestion names a
  // concrete move only when it can prove the destination is actually free.
  const idleGaps = [];
  for (const i of instructors) {
    const key = String(i._id);
    const mine = schedules.filter(s => s.instructor && String(s.instructor._id || s.instructor) === key);
    for (const day of ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']) {
      const todays = mine.filter(s => (s.weekdays || []).includes(day))
        .sort((a, b) => toMinutes(a.startTime) - toMinutes(b.startTime));
      for (let n = 1; n < todays.length; n++) {
        const gapStart = toMinutes(todays[n - 1].endTime);
        const gapEnd = toMinutes(todays[n].startTime);
        if (gapEnd - gapStart < LONG_GAP) continue;

        // Could one of this instructor's classes on ANOTHER day be moved into
        // the gap? Only offer it when the room and the section are provably free.
        const moves = [];
        for (const other of mine) {
          if ((other.weekdays || []).includes(day)) continue;
          const os = toMinutes(other.startTime), oe = toMinutes(other.endTime);
          if (!overlaps(os, oe, gapStart, gapEnd)) continue;
          const blockers = [];
          if (os < gapStart || oe > gapEnd) blockers.push(`it lasts ${oe - os} minutes and the gap is only ${gapEnd - gapStart}`);
          if (other.room && busyRoom(other.room._id, day, os, oe, other._id)) blockers.push(`${other.room.roomCode} is already booked on that ${day}`);
          if (busySection(other.course && other.course._id, other.yearLevel, other.sectionType, other.blockLabel, day, os, oe, other._id)) {
            blockers.push('that section already has a class at that time');
          }
          moves.push({
            from: `${(other.weekdays || []).join('/')} ${time12(other.startTime)} - ${time12(other.endTime)}`,
            subject: label(other),
            to: `${day} ${at(os)} - ${at(oe)}`,
            blockers
          });
        }

        idleGaps.push({
          instructor: name(i),
          day,
          gap: `${at(gapStart)} - ${at(gapEnd)}`,
          minutes: gapEnd - gapStart,
          between: [label(todays[n - 1]), label(todays[n])],
          moves: moves.filter(m => m.blockers.length === 0),
          considered: moves.length,
          blockedBy: moves.length === 0
            ? 'none of this instructor\'s other classes fall inside the gap'
            : (moves.every(m => m.blockers.length) ? 'every candidate move is blocked: ' + moves[0].blockers.join('; ') : null)
        });
      }
    }
  }
  idleGaps.sort((a, b) => b.minutes - a.minutes);

  const openableRooms = rooms.filter(r => r.status === 'Active').length;

  return {
    semesterId,
    settings: {
      dayStart: settings.dayStart,
      dayEnd: settings.dayEnd,
      dailyTargetHours: settings.dailyTargetHours,
      sessionRules: settings.sessionRules
    },
    summary: {
      unassignedSchedules: unassignedInstructors.length,
      assignableNow: unassignedInstructors.filter(x => x.candidates.length).length,
      sessionLengthProblems: sessionLengths.length,
      fixableNow: sessionLengths.filter(x => !x.blockers.length).length,
      idleGaps: idleGaps.length,
      closableNow: idleGaps.filter(x => x.moves.length).length,
      activeRooms: openableRooms
    },
    unassignedInstructors,
    sessionLengths,
    idleGaps,
    // Stated up front so nobody mistakes this for an auto-planner.
    note: 'Suggestions only. Nothing here has been written to the timetable. Each suggestion lists the constraint that would have to be cleared first.'
  };
}

module.exports = { suggestions, LONG_GAP };
