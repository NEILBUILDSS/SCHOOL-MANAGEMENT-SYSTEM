const bcrypt = require('bcryptjs');

const User = require('../models/User');
const Student = require('../models/Student');
const Instructor = require('../models/Instructor');
const { required, validatePassword, httpError } = require('../utils/validation');
const { nextStudentId, nextInstructorId } = require('./idService');
const { logActivity } = require('./logService');

// Public registration only collects an account type and credentials. The
// existing User schema still requires a unique email address, so accounts get
// a private, non-deliverable alias derived from their unique username. People
// sign in with their username; the alias is never shown as a registration field.
const EMAIL_DOMAIN = {
  Student: 'student.southerncanillo.local',
  Instructor: 'instructor.southerncanillo.local'
};

const PROFILE_ID = {
  Student: { field: 'studentId', label: 'Student ID', factory: nextStudentId },
  Instructor: { field: 'instructorId', label: 'Instructor ID', factory: nextInstructorId }
};

async function createProfileWithId(Model, role, fields) {
  const id = PROFILE_ID[role];
  let lastDuplicate = null;

  for (let attempt = 0; attempt < 10; attempt += 1) {
    try {
      return await Model.create({ ...fields, [id.field]: await id.factory() });
    } catch (err) {
      if (err && err.code === 11000 && (
        (err.keyPattern && err.keyPattern[id.field]) ||
        (err.keyValue && err.keyValue[id.field])
      )) {
        lastDuplicate = err;
        continue;
      }
      throw err;
    }
  }

  if (lastDuplicate) {
    throw httpError(409, `Could not generate a unique ${id.label}. Please try again.`);
  }
  throw httpError(409, `Could not create the ${id.label}. Please try again.`);
}

async function registerAccount({ role: requestedRole, username: rawUsername, password, confirmPassword }) {
  const role = requestedRole ? String(requestedRole) : 'Student';
  if (!['Student', 'Instructor'].includes(role)) {
    throw httpError(400, 'Public registration is for Student and Instructor accounts only.');
  }

  const username = required(rawUsername, 'Username', 50).toLowerCase();
  const cleanPassword = validatePassword(password);

  if (cleanPassword !== String(confirmPassword ?? '')) {
    throw httpError(400, 'Password confirmation does not match.');
  }

  const email = `${username}@${EMAIL_DOMAIN[role]}`;
  if (await User.exists({ $or: [{ username }, { email }] })) {
    throw httpError(409, 'That username is already in use.');
  }

  const passwordHash = await bcrypt.hash(cleanPassword, 12);
  const user = await User.create({
    role,
    username,
    email,
    passwordHash,
    status: 'Active'
  });

  let profile;
  try {
    if (role === 'Student') {
      profile = await createProfileWithId(Student, role, {
        user: user._id,
        firstName: username,
        lastName: '',
        contactNumber: '',
        course: null,
        yearLevel: 1
      });
    } else {
      profile = await createProfileWithId(Instructor, role, {
        user: user._id,
        firstName: username,
        middleName: '',
        lastName: '',
        contactNumber: '',
        department: ''
      });
    }
  } catch (err) {
    await User.deleteOne({ _id: user._id }).catch(() => {});
    throw err;
  }

  await logActivity({
    performedBy: user._id,
    category: 'Registration',
    action: `${role} account created`,
    description: `${role} account ${username} was registered.`
  });

  return {
    user,
    profile,
    role,
    publicId: profile[PROFILE_ID[role].field]
  };
}

module.exports = { registerAccount };
