﻿const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Student = require('../models/Student');
const Instructor = require('../models/Instructor');
const Course = require('../models/Course');
const { required, validateEmail, validatePassword, clean, httpError } = require('../utils/validation');
const { logActivity } = require('./logService');
const { nextStudentId } = require('./idService');

async function createPersonAccount({ role, data, actorUserId = null, selfRegistration = false }) {
  if (!['Student', 'Instructor'].includes(role)) throw httpError(400, 'Only Student and Instructor accounts can be created here.');

  const username = required(data.username, 'Username', 50).toLowerCase();
  const email = validateEmail(data.email);
  const password = validatePassword(data.password);
  if (password !== String(data.confirmPassword ?? '')) throw httpError(400, 'Password confirmation does not match.');

  const firstName = required(data.firstName, 'First name', 80);
  const middleName = clean(data.middleName, 80);
  const lastName = required(data.lastName, 'Last name', 80);
  const contactNumber = required(data.contactNumber, 'Contact number', 40);

  if (await User.exists({ $or: [{ username }, { email }] })) {
    throw httpError(409, 'Username or email is already in use.');
  }

  let personDoc;
  let suppliedStudentId = null;
  if (role === 'Student') {
    // Self-registration never asks for a Student ID: the server allocates the
    // next YYYY-#### value from an atomic counter. Admin-created records may
    // still supply an explicit ID, but an omitted ID is generated the same way.
    if (!selfRegistration && data.studentId !== undefined && String(data.studentId).trim() !== '') {
      suppliedStudentId = required(data.studentId, 'Student ID', 50).toUpperCase();
      if (await Student.exists({ studentId: suppliedStudentId })) throw httpError(409, 'Student ID is already in use.');
    }
    const courseCode = required(data.course, 'Course', 10).toUpperCase();
    const course = await Course.findOne({ code: courseCode, status: 'Active' });
    if (!course) throw httpError(400, 'Select a valid active course.');
    const yearLevel = Number(data.yearLevel);
    if (![1, 2, 3, 4].includes(yearLevel)) throw httpError(400, 'Year level must be 1 to 4.');
    personDoc = {
      firstName,
      middleName,
      lastName,
      contactNumber,
      course: course._id,
      yearLevel,

      telephoneNumber: clean(data.telephoneNumber, 40),
      birthPlace: clean(data.birthPlace, 160),
      religion: clean(data.religion, 100),
      citizenship: clean(data.citizenship, 100),
      civilStatus: clean(data.civilStatus, 60),

      currentAddress: {
        houseNo: clean(data.currentHouseNo, 160),
        streetNo: clean(data.currentStreetNo, 160),
        barangay: clean(data.currentBarangay, 160),
        city: clean(data.currentCity, 160),
        province: clean(data.currentProvince, 160),
        zipCode: clean(data.currentZipCode, 20)
      },

      permanentAddress: {
        houseNo: clean(data.permanentHouseNo, 160),
        streetNo: clean(data.permanentStreetNo, 160),
        barangay: clean(data.permanentBarangay, 160),
        city: clean(data.permanentCity, 160),
        province: clean(data.permanentProvince, 160),
        zipCode: clean(data.permanentZipCode, 20)
      },

      father: {
        name: clean(data.fatherName, 180),
        occupation: clean(data.fatherOccupation, 140),
        mobileNumber: clean(data.fatherMobileNumber, 40)
      },

      mother: {
        name: clean(data.motherName, 180),
        occupation: clean(data.motherOccupation, 140),
        mobileNumber: clean(data.motherMobileNumber, 40)
      },

      guardian: {
        name: clean(data.guardianName, 180),
        occupation: clean(data.guardianOccupation, 140),
        mobileNumber: clean(data.guardianMobileNumber, 40)
      },

      emergencyContact: {
        name: clean(data.emergencyName, 180),
        relationship: clean(data.emergencyRelationship, 100),
        mobileNumber: clean(data.emergencyMobileNumber, 40)
      },

      education: {

        primary: {
          school: clean(data.primarySchool, 220),
          address: clean(data.primaryAddress, 260),
          schoolYear: clean(data.primarySchoolYear, 40)
        },

        secondary: {
          school: clean(data.secondarySchool, 220),
          address: clean(data.secondaryAddress, 260),
          schoolYear: clean(data.secondarySchoolYear, 40)
        },

        seniorHigh: {
          school: clean(data.seniorHighSchool, 220),
          address: clean(data.seniorHighAddress, 260),
          schoolYear: clean(data.seniorHighSchoolYear, 40)
        },

        lastAttended: {
          school: clean(data.lastAttendedSchool, 220),
          address: clean(data.lastAttendedAddress, 260),
          schoolYear: clean(data.lastAttendedSchoolYear, 40)
        }

      }
    };
  } else {
    const instructorId = required(data.instructorId, 'Instructor ID', 50).toUpperCase();
    if (await Instructor.exists({ instructorId })) throw httpError(409, 'Instructor ID is already in use.');
    const department = required(data.department, 'Department', 120);
    personDoc = { instructorId, firstName, middleName, lastName, contactNumber, department };
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const user = await User.create({ role, username, email, passwordHash, status: 'Active' });

  try {
    if (role === 'Student') {
      personDoc.user = user._id;
      if (suppliedStudentId) {
        personDoc.studentId = suppliedStudentId;
        await Student.create(personDoc);
      } else {
        let lastDuplicate = null;
        for (let attempt = 0; attempt < 10; attempt += 1) {
          try {
            personDoc.studentId = await nextStudentId();
            await Student.create(personDoc);
            lastDuplicate = null;
            break;
          } catch (err) {
            // A concurrent request may have taken the value after the counter
            // check. Skip that number and try the next one.
            if (err && err.code === 11000 && (
              (err.keyPattern && err.keyPattern.studentId) ||
              (err.keyValue && err.keyValue.studentId)
            )) {
              lastDuplicate = err;
              continue;
            }
            throw err;
          }
        }
        if (lastDuplicate) throw httpError(409, 'Could not generate a unique Student ID. Please try again.');
      }
    } else {
      personDoc.user = user._id;
      await Instructor.create(personDoc);
    }
  } catch (err) {
    await User.deleteOne({ _id: user._id }).catch(() => {});
    throw err;
  }

  await logActivity({
    performedBy: selfRegistration ? user._id : actorUserId,
    category: 'Registration',
    action: `${role} account created`,
    description: `${role} account ${username} was registered.`
  });

  return user;
}

module.exports = { createPersonAccount };

