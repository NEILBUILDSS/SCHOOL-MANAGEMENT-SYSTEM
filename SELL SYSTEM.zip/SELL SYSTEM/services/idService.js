const Counter = require('../models/Counter');
const Student = require('../models/Student');
const Instructor = require('../models/Instructor');
const Room = require('../models/Room');

const pad = (n, width) => String(n).padStart(width, '0');

async function nextSeq(key) {
  // Upserting a brand-new counter can race with another first request. The
  // unique _id makes MongoDB reject one of them, so retry once the document
  // exists and let $inc hand out the next number atomically.
  for (let attempt = 0; attempt < 5; attempt += 1) {
    try {
      const counter = await Counter.findOneAndUpdate(
        { _id: key },
        { $inc: { seq: 1 } },
        { new: true, upsert: true, setDefaultsOnInsert: true }
      );
      return counter.seq;
    } catch (err) {
      if (err && err.code === 11000) continue;
      throw err;
    }
  }
  throw new Error('Could not allocate the next ID sequence. Please try again.');
}

// Keeps taking the next number until it finds one that is not used yet
// (this also skips data that already exists, such as the seeded ROOM-001 to ROOM-030).
async function generateUnique(key, format, isTaken) {
  for (let attempt = 0; attempt < 1000; attempt += 1) {
    const value = format(await nextSeq(key));
    if (!(await isTaken(value))) return value;
  }
  throw new Error('Could not generate a unique ID. Please try again.');
}

function nextStudentId(date = new Date()) {
  const year = date.getFullYear();
  return generateUnique(`student-${year}`, n => `${year}-${pad(n, 4)}`, v => Student.exists({ studentId: v }));
}

function nextInstructorId() {
  return generateUnique('instructor', n => `INS-${pad(n, 3)}`, v => Instructor.exists({ instructorId: v }));
}

function nextRoomCode() {
  return generateUnique('room', n => `ROOM-${pad(n, 3)}`, v => Room.exists({ roomCode: v }));
}

module.exports = { nextStudentId, nextInstructorId, nextRoomCode };