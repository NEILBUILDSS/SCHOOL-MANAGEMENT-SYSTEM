const Course = require('../models/Course');
const Subject = require('../models/Subject');
const Room = require('../models/Room');
const Schedule = require('../models/Schedule');

const courseSeeds = [
  { seedKey: 'course-it', code: 'IT', name: 'BS Information Technology', status: 'Active' },
  { seedKey: 'course-cs', code: 'CS', name: 'BS Computer Science', status: 'Active' },
  { seedKey: 'course-is', code: 'IS', name: 'BS Information Systems', status: 'Active' }
];

const subjectSeeds = [
  { seedKey: 'subject-it101', subjectCode: 'IT101', subjectName: 'Introduction to Computing', courseCode: 'IT', units: 3, laboratoryRequired: false, description: 'Foundations of computing, information technology, and digital systems.' },
  { seedKey: 'subject-it102', subjectCode: 'IT102', subjectName: 'Computer Programming 1', courseCode: 'IT', units: 3, laboratoryRequired: true, description: 'Programming fundamentals, problem solving, and laboratory exercises.' },
  { seedKey: 'subject-it103', subjectCode: 'IT103', subjectName: 'Web Systems and Technologies', courseCode: 'IT', units: 3, laboratoryRequired: true, description: 'Core web technologies and practical web development.' },
  { seedKey: 'subject-cs101', subjectCode: 'CS101', subjectName: 'Introduction to Computer Science', courseCode: 'CS', units: 3, laboratoryRequired: false, description: 'Core concepts, computational thinking, and computer science foundations.' },
  { seedKey: 'subject-cs102', subjectCode: 'CS102', subjectName: 'Data Structures', courseCode: 'CS', units: 3, laboratoryRequired: true, description: 'Linear and non-linear data structures with programming laboratory work.' },
  { seedKey: 'subject-is101', subjectCode: 'IS101', subjectName: 'Fundamentals of Information Systems', courseCode: 'IS', units: 3, laboratoryRequired: false, description: 'Information systems concepts, organizations, and business processes.' },
  { seedKey: 'subject-is102', subjectCode: 'IS102', subjectName: 'Systems Analysis and Design', courseCode: 'IS', units: 3, laboratoryRequired: false, description: 'Requirements, process modeling, analysis, and systems design fundamentals.' }
];

function roomSeed(index) {
  const n = String(index).padStart(3, '0');
  const lab = index >= 21;
  return {
    seedKey: `room-${n}`,
    roomCode: `ROOM-${n}`,
    roomName: lab ? `Computer Laboratory ${index - 20}` : `Lecture Room ${index}`,
    roomType: lab ? 'Laboratory' : 'Non-Laboratory',
    capacity: lab ? 35 : 45,
    equipment: lab ? ['Desktop computers', 'Projector', 'Whiteboard', 'Air conditioning'] : ['Projector', 'Whiteboard', 'Electric fans'],
    status: 'Active',
    photoPath: `/images/rooms/room-${n}.svg`,
    photoIsPlaceholder: true
  };
}

const schedulePatterns = [
  { weekdays: ['Mon','Wed'], startTime: '07:30', nonLabRoom: 1, labRoom: 21 },
  { weekdays: ['Tue','Thu'], startTime: '09:00', nonLabRoom: 5, labRoom: 22 },
  { weekdays: ['Mon','Wed'], startTime: '11:30', nonLabRoom: 17, labRoom: 23 },
  { weekdays: ['Tue','Thu'], startTime: '13:30', nonLabRoom: 17, labRoom: 24 }
];

function addMinutes(hhmm, mins) {
  const [h,m] = hhmm.split(':').map(Number);
  const total = h*60+m+mins;
  return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`;
}

async function ensureDefaultSemester() {
  // Semesters follow the school calendar automatically (see services/semesterService.js).
  await require('./semesterService').getCurrentSemester();
}

async function ensureSampleProspectus(subjects) {
  const Prospectus = require('../models/Prospectus');
  if (await Prospectus.estimatedDocumentCount()) return;
  const byCourse = new Map();
  for (const s of [...subjects].sort((a, b) => a.subjectCode.localeCompare(b.subjectCode))) {
    const year = s.subjectCode.endsWith('102') ? 2 : 1;
    const key = String(s.course);
    if (!byCourse.has(key)) byCourse.set(key, []);
    const items = byCourse.get(key);
    const inYear = items.filter(i => i.yearLevel === year).length;
    items.push({ yearLevel: year, term: inYear === 0 ? '1st Semester' : '2nd Semester', subject: s._id });
  }
  for (const [course, items] of byCourse) await Prospectus.create({ course, items });
}

async function seedBaseData() {
  await ensureDefaultSemester();
  for (const c of courseSeeds) await Course.updateOne({ seedKey: c.seedKey }, { $setOnInsert: c }, { upsert: true });
  const courses = Object.fromEntries((await Course.find({ seedKey: { $in: courseSeeds.map(c => c.seedKey) } })).map(c => [c.code, c]));

  for (const s of subjectSeeds) {
    const doc = { ...s, course: courses[s.courseCode]._id, status: 'Active' };
    delete doc.courseCode;
    await Subject.updateOne({ seedKey: s.seedKey }, { $setOnInsert: doc }, { upsert: true });
  }

  for (let i=1;i<=30;i++) {
    const room = roomSeed(i);
    await Room.updateOne({ seedKey: room.seedKey }, { $setOnInsert: room }, { upsert: true });
  }

  const subjects = await Subject.find({ seedKey: { $in: subjectSeeds.map(s => s.seedKey) } });
  const rooms = await Room.find({ seedKey: { $regex: /^room-/ } });
  const roomByNumber = Object.fromEntries(rooms.map(r => [Number(r.roomCode.split('-')[1]), r]));
  // Sample offerings belong to whatever semester is currently open.
  const currentSemester = await require('./semesterService').getCurrentSemester();
  let createdSchedules = 0;
  for (const subject of subjects) {
    const course = await Course.findById(subject.course);
    for (let i=0;i<4;i++) {
      const pattern = schedulePatterns[i];
      const room = roomByNumber[subject.laboratoryRequired ? pattern.labRoom : pattern.nonLabRoom];
      const duration = subject.units * 60 / pattern.weekdays.length;
      if (!Number.isInteger(duration)) throw new Error(`The seed schedule for ${subject.subjectCode} cannot evenly distribute its unit hours.`);
      const seedKey = `${subject.seedKey}-option-${i+1}`;
      const result = await Schedule.updateOne(
        { seedKey },
        { $setOnInsert: {
          seedKey,
          subject: subject._id,
          instructor: null,
          room: room._id,
          weekdays: pattern.weekdays,
          startTime: pattern.startTime,
          endTime: addMinutes(pattern.startTime, duration),
          course: course._id,
          yearLevel: subject.subjectCode.endsWith('102') ? 2 : 1,
          status: 'Inactive',
          semester: currentSemester ? currentSemester._id : null
        }},
        { upsert: true }
      );
      if (result.upsertedCount) createdSchedules++;
      else {
        const existing = await Schedule.findOne({ seedKey }).select('weekdays startTime endTime').lean();
        const [startHour, startMinute] = existing.startTime.split(':').map(Number);
        const [endHour, endMinute] = existing.endTime.split(':').map(Number);
        const weeklyMinutes = existing.weekdays.length * ((endHour * 60 + endMinute) - (startHour * 60 + startMinute));
        if (weeklyMinutes !== subject.units * 60) {
          const correctedDuration = subject.units * 60 / existing.weekdays.length;
          if (!Number.isInteger(correctedDuration)) throw new Error(`Cannot correct the seed schedule duration for ${subject.subjectCode}.`);
          await Schedule.updateOne({ _id: existing._id }, { $set: { endTime: addMinutes(existing.startTime, correctedDuration) } });
        }
      }
    }
  }
  await ensureSampleProspectus(subjects);
  return { courses: 3, subjects: 7, rooms: 30, scheduleOptions: 28, createdSchedules };
}

async function seedDemoUsers() {
  const User = require('../models/User');
  const Student = require('../models/Student');
  const Instructor = require('../models/Instructor');
  const bcrypt = require('bcryptjs');
  const saltRounds = 12;

  // Demo users with required profile fields
  const demoUsers = [
    { username: 'admin', role: 'Admin', email: 'admin@school.local', password: 'Admin@12345' },
    { username: 'maria.santos', role: 'Student', email: 'maria.santos@school.local', password: 'Student@12345', firstName: 'Maria', lastName: 'Santos', yearLevel: 2 },
    { username: 'daniel.cruz', role: 'Instructor', email: 'daniel.cruz@school.local', password: 'Teacher@12345', firstName: 'Daniel', lastName: 'Cruz' }
  ];

  for (const user of demoUsers) {
    let existingUser = await User.findOne({ username: user.username });
    
    if (!existingUser) {
      const passwordHash = await bcrypt.hash(user.password, saltRounds);
      existingUser = await User.create({
        username: user.username,
        email: user.email,
        passwordHash,
        role: user.role,
        status: 'Active',
        registrationStatus: 'Approved'
      });
    }

    // Ensure profile exists for Student/Instructor with required fields
    if (user.role === 'Student') {
      const existingStudent = await Student.findOne({ user: existingUser._id });
      if (!existingStudent) {
        await Student.create({
          user: existingUser._id,
          studentId: `2024-${String(1000 + Math.floor(Math.random() * 9000))}`,
          firstName: user.firstName,
          lastName: user.lastName,
          yearLevel: user.yearLevel
        });
      } else if (!existingStudent.firstName) {
        // Update missing firstName for existing profile
        await Student.updateOne(
          { _id: existingStudent._id },
          { $set: { firstName: user.firstName, lastName: user.lastName } }
        );
      }
    } else if (user.role === 'Instructor') {
      const existingInstructor = await Instructor.findOne({ user: existingUser._id });
      if (!existingInstructor) {
        await Instructor.create({
          user: existingUser._id,
          instructorId: `INS-${String(100 + Math.floor(Math.random() * 900))}`,
          firstName: user.firstName,
          lastName: user.lastName,
          department: 'Computer Science'
        });
      } else if (!existingInstructor.firstName) {
        // Update missing firstName for existing profile
        await Instructor.updateOne(
          { _id: existingInstructor._id },
          { $set: { firstName: user.firstName, lastName: user.lastName } }
        );
      }
    }
  }
}

module.exports = { seedBaseData, seedDemoUsers };
