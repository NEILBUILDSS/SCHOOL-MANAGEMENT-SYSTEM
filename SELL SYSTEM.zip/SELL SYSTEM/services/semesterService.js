const Semester = require('../models/Semester');
const Enrollment = require('../models/Enrollment');
const Student = require('../models/Student');
const { httpError } = require('../utils/validation');

// The semesters follow the standard school calendar, so nobody has to manage them by hand:
//   1st Semester: Aug 10 - Dec 18   2nd Semester: Jan 11 - May 28   Summer: Jun 8 - Jul 31
// A semester becomes the current one on its start date and stays current until the next one starts.
const utc = (year, month, day) => new Date(Date.UTC(year, month - 1, day));

function academicYearStart(date) {
  return date.getUTCMonth() >= 7 ? date.getUTCFullYear() : date.getUTCFullYear() - 1;
}

function calendarFor(y) {
  const academicYear = `${y}-${y + 1}`;
  return [
    { academicYear, term: '1st Semester', startDate: utc(y, 8, 10), endDate: utc(y, 12, 18) },
    { academicYear, term: '2nd Semester', startDate: utc(y + 1, 1, 11), endDate: utc(y + 1, 5, 28) },
    { academicYear, term: 'Summer', startDate: utc(y + 1, 6, 8), endDate: utc(y + 1, 7, 31) }
  ];
}

// Make sure this academic year and the next one exist.
async function ensureAcademicYears(date) {
  const start = academicYearStart(date);
  for (const y of [start, start + 1]) {
    const wanted = calendarFor(y);
    if ((await Semester.countDocuments({ academicYear: wanted[0].academicYear })) >= wanted.length) {
      // Heal any semester whose start/end dates were lost (e.g. a manual database edit);
      // null dates would otherwise make enrollment silently report "closed" forever.
      for (const s of wanted) {
        await Semester.updateOne(
          { academicYear: s.academicYear, term: s.term, $or: [{ startDate: null }, { endDate: null }] },
          { $set: { startDate: s.startDate, endDate: s.endDate } }
        );
      }
      continue;
    }
    for (const s of wanted) {
      if (await Semester.exists({ academicYear: s.academicYear, term: s.term })) continue;
      try { await Semester.create(s); } catch (err) { if (err.code !== 11000) throw err; }
    }
  }
}

const findCurrentFlag = () => Semester.findOne({ isCurrent: true });

// A student is Active only while enrolled in the current semester; otherwise Inactive.
async function syncAllStudentStatuses() {
  const current = await findCurrentFlag();
  const ids = current ? await Enrollment.distinct('student', { semester: current._id, status: 'Active' }) : [];
  await Student.updateMany({ _id: { $in: ids } }, { $set: { status: 'Active' } });
  await Student.updateMany({ _id: { $nin: ids } }, { $set: { status: 'Inactive' } });
}

// Switching ends the enrollments of every other semester (their results stay as history)
// and re-calculates every student's status.
async function switchTo(target) {
  const previous = await findCurrentFlag();
  await Semester.updateMany({ isCurrent: true }, { $set: { isCurrent: false } });
  try {
    await Semester.updateOne({ _id: target._id }, { $set: { isCurrent: true } });
  } catch (err) {
    if (previous) await Semester.updateOne({ _id: previous._id }, { $set: { isCurrent: true } });
    throw err;
  }
  const ended = await Enrollment.updateMany(
    { status: 'Active', semester: { $ne: target._id } },
    { $set: { status: 'Inactive' } }
  );
  return ended.modifiedCount || 0;
}

let running = null;
function syncCurrentSemester(now = new Date()) {
  if (running) return running;
  running = (async () => {
    await ensureAcademicYears(now);
    const desired = (await Semester.findOne({ startDate: { $lte: now } }).sort({ startDate: -1 })) ||
      (await Semester.findOne().sort({ startDate: 1 }));
    const current = await findCurrentFlag();
    if (desired && (!current || String(current._id) !== String(desired._id))) await switchTo(desired);
    return desired;
  })().finally(() => { running = null; });
  return running;
}

async function getCurrentSemester() {
  await syncCurrentSemester();
  return findCurrentFlag();
}

async function syncStudentStatus(studentId) {
  const current = await getCurrentSemester();
  const enrolled = current
    ? await Enrollment.exists({ student: studentId, semester: current._id, status: 'Active' })
    : null;
  await Student.updateOne({ _id: studentId }, { $set: { status: enrolled ? 'Active' : 'Inactive' } });
}

async function listSemesters() {
  await syncCurrentSemester();
  return Semester.find().sort({ startDate: -1 }).lean();
}

module.exports = { getCurrentSemester, syncCurrentSemester, syncStudentStatus, syncAllStudentStatuses, listSemesters, ensureAcademicYears };