const Setting = require('../models/Setting');

// ---------------------------------------------------------------------------
// Scheduling settings service
//
// Central read/write for the tunable scheduling values. Reads are cached for a
// few seconds so a burst of conflict checks does not hammer one collection,
// and every write clears the cache so the next read sees the new value.
//
// getSettings() never writes. If the school has not saved a settings row yet
// it returns the same defaults the model declares, so behaviour is identical
// to the original hard-coded rules until an admin actually changes something.
// ---------------------------------------------------------------------------

const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

function toMinutes(value) {
  const m = TIME_RE.exec(String(value || ''));
  if (!m) return NaN;
  return Number(m[1]) * 60 + Number(m[2]);
}

function minutesToHHMM(total) {
  const safe = Math.max(0, Math.round(total));
  return `${String(Math.floor(safe / 60) % 24).padStart(2, '0')}:${String(safe % 60).padStart(2, '0')}`;
}

// 12-hour label used in the messages a registrar reads, e.g. 07:30 -> "7:30 AM".
function time12(value) {
  const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(String(value || ''));
  if (!m) return String(value || '');
  let h = Number(m[1]) % 12;
  if (h === 0) h = 12;
  return `${h}:${m[2]} ${Number(m[1]) >= 12 ? 'PM' : 'AM'}`;
}

// Human label for a day pattern, used in validation messages so an error names
// the exact pattern the admin picked rather than a weekday list.
const PATTERN_LABELS = {
  MWF: 'MWF (Monday, Wednesday, Friday)',
  TTH: 'TTh (Tuesday, Thursday)',
  F: 'Friday-only',
  SATURDAY: 'Saturday-only',
  SUNDAY: 'Sunday-only'
};

function patternLabelFor(patternKey) {
  return PATTERN_LABELS[patternKey] || 'This day pattern';
}

// Day-pattern keys match DAY_PATTERNS in public/js/app.js.
const DAY_PATTERNS = [
  { key: 'MWF', weekdays: ['Mon', 'Wed', 'Fri'] },
  { key: 'TTH', weekdays: ['Tue', 'Thu'] },
  { key: 'F', weekdays: ['Fri'] },
  { key: 'SATURDAY', weekdays: ['Sat'] },
  { key: 'SUNDAY', weekdays: ['Sun'] }
];

// Maps a stored weekday list to a planner pattern key, or '' when the list
// matches no known pattern (mixed selections such as Mon+Tue).
function patternKeyFor(weekdays) {
  const days = Array.isArray(weekdays) ? weekdays : [];
  const hit = DAY_PATTERNS.find(p =>
    p.weekdays.length === days.length && p.weekdays.every(d => days.includes(d))
  );
  return hit ? hit.key : '';
}

function defaultSettings() {
  return {
    key: 'scheduling',
    dayStart: '07:30',
    dayEnd: '17:00',
    breaksEnabled: false,
    breaks: [],
    dailyTargetHours: 8,
    sectionCapacity: 10,
    activeRoomLimit: 5,
    enforcePatternDuration: true,
    sessionRules: [{ pattern: 'MWF', minutes: 60 }, { pattern: 'TTH', minutes: 90 }]
  };
}

let cache = null;
let cacheAt = 0;
const CACHE_MS = 5000;

async function getSettings() {
  if (cache && Date.now() - cacheAt < CACHE_MS) return cache;
  let doc = null;
  try {
    doc = await Setting.findOne({ key: 'scheduling' }).lean();
  } catch (err) {
    // A read failure must never take a scheduling route down; fall back to
    // the documented defaults and let the next call retry the database.
    doc = null;
  }
  cache = doc || defaultSettings();
  cacheAt = Date.now();
  return cache;
}

function invalidateSettingsCache() {
  cache = null;
  cacheAt = 0;
}

// Persist an update. Returns the saved document. Validation lives on the
// model, so an invalid value never reaches the database.
async function saveSettings(update) {
  const doc = await Setting.findOne({ key: 'scheduling' });
  if (doc) {
    doc.set(update || {});
    await doc.save();
  } else {
    await Setting.create(Object.assign(defaultSettings(), update || {}));
  }
  invalidateSettingsCache();
  return Setting.findOne({ key: 'scheduling' }).lean();
}

// Session length a class day pattern requires, in minutes.
//
// enforcePatternDuration = true  -> the pattern fixes the length (MWF 60, TTh 90).
// enforcePatternDuration = false -> legacy rule: subject units * 60, split evenly.
//
// Returns { minutes } on success or { error } explaining why no length applies.
// It never guesses: an unmatchable pattern or an uneven split is reported so
// the caller can show a fixable message instead of storing a wrong duration.
function sessionMinutesFor(settings, patternKey, subjectUnits, dayCount) {
  const days = Number(dayCount) || 0;
  if (!days) return { error: 'Choose at least one class day to calculate the session length.' };

  if (settings.enforcePatternDuration !== false) {
    const rule = (settings.sessionRules || []).find(r => r.pattern === patternKey);
    if (rule) return { minutes: Number(rule.minutes), source: 'pattern' };
    // Patterns with no explicit rule (single-day and weekend classes) fall
    // through to the legacy units rule rather than being silently forced.
  }

  const units = Number(subjectUnits);
  if (!units) return { error: 'Choose a subject to calculate the session length.' };
  const total = units * 60;
  if (total % days !== 0 || (total / days) % 30 !== 0) {
    return { error: `${units} unit(s) cannot be split evenly across ${days} class day(s) in 30-minute sessions.` };
  }
  return { minutes: total / days, source: 'units' };
}

// True when a class would run across a configured break. Only consulted when
// breaks are enabled; a disabled break list can never block a schedule.
function breakCollision(settings, startTime, endTime) {
  if (!settings || !settings.breaksEnabled || !(settings.breaks || []).length) return null;
  const s = toMinutes(startTime);
  const e = toMinutes(endTime);
  if (Number.isNaN(s) || Number.isNaN(e)) return null;
  for (const b of settings.breaks) {
    const bs = toMinutes(b.startTime);
    const be = toMinutes(b.endTime);
    if (!Number.isNaN(bs) && !Number.isNaN(be) && s < be && bs < e) {
      return b;
    }
  }
  return null;
}

// The class list is hard-capped at ten officially enrolled students per
// section. Section capacity may be configured lower, but never higher.
const CLASS_LIST_LIMIT = 10;

// Planned size of one section: the configured size, capped so the registrar,
// student and instructor portals all agree on the same class-list limit.
function plannedSectionSize(settings) {
  const section = Number(settings && settings.sectionCapacity);
  const configured = Number.isFinite(section) && section > 0 ? section : CLASS_LIST_LIMIT;
  return Math.max(1, Math.min(configured, CLASS_LIST_LIMIT));
}

// Seats one schedule may actually fill: the smaller of the room's physical
// capacity and the section size, then hard-capped at ten. It never invents
// seats a room cannot hold, and a room with no known capacity offers no seats.
function seatsFor(roomCapacity, settings) {
  const room = Number(roomCapacity) || 0;
  if (!room) return 0;
  return Math.min(room, plannedSectionSize(settings));
}

module.exports = {
  getSettings,
  saveSettings,
  invalidateSettingsCache,
  defaultSettings,
  sessionMinutesFor,
  breakCollision,
  seatsFor,
  plannedSectionSize,
  CLASS_LIST_LIMIT,
  patternKeyFor,
  patternLabelFor,
  toMinutes,
  minutesToHHMM,
  time12,
  DAY_PATTERNS
};
