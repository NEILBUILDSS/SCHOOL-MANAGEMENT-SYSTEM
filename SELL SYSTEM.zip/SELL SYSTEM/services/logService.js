const ActivityLog = require('../models/ActivityLog');
const User = require('../models/User');
const Student = require('../models/Student');

async function actorLabel(userId) {
  if (!userId) return 'System';
  const user = await User.findById(userId).select('username role').lean();
  if (!user) return 'System';
  return `${user.username} (${user.role})`;
}

// Readable student reference for activity logs: "RONEL SARABILLO (2026-00123)".
async function studentLabel(studentId) {
  if (!studentId) return 'Unknown student';
  const student = await Student.findById(studentId).select('studentId firstName lastName').lean();
  if (!student) return 'Deleted student';
  const name = [student.firstName, student.lastName].filter(Boolean).join(' ') || 'Unknown student';
  return student.studentId ? `${name} (${student.studentId})` : name;
}

async function logActivity({ performedBy = null, category, action, description, performedByLabel = null }) {
  const label = performedByLabel || await actorLabel(performedBy);
  return ActivityLog.create({ performedBy, performedByLabel: label, category, action, description });
}

module.exports = { logActivity, studentLabel };
