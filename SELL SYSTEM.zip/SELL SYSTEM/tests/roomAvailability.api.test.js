// End-to-end API tests: boots the real server on a SEPARATE temp database, then
// exercises login, the rooms availability API and schedule create/update exactly
// as the scheduling interface consumes them. The temp database is dropped after
// the run, so no project data is touched. Run with: npm test
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const path = require('node:path');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

process.env.ROOM_DAILY_LIMIT_HOURS = '8';

const ROOT = path.join(__dirname, '..');
const PORT = 3207;
const BASE = 'http://127.0.0.1:' + PORT;
const TEST_URI = 'mongodb://127.0.0.1:27017/college_scheduling_api_test_opencode';

const User = require('../models/User');
const Instructor = require('../models/Instructor');
const Subject = require('../models/Subject');
const Student = require('../models/Student');
const Schedule = require('../models/Schedule');
const Room = require('../models/Room');
const Enrollment = require('../models/Enrollment');

let server = null;

function extractSetCookies(res) {
  const list = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
  return list.map(c => c.split(';')[0]).filter(Boolean);
}

function makeClient() {
  let cookie = '';
  const merge = res => {
    const parts = extractSetCookies(res);
    if (parts.length) {
      const jar = new Map(cookie ? cookie.split('; ').map(p => [p.split('=')[0], p]) : []);
      for (const p of parts) jar.set(p.split('=')[0], p);
      cookie = [...jar.values()].join('; ');
    }
  };
  const request = async (route, { method = 'GET', body, csrf } = {}) => {
    const res = await fetch(BASE + route, {
      method,
      headers: {
        ...(body ? { 'content-type': 'application/json' } : {}),
        ...(csrf ? { 'x-csrf-token': csrf } : {}),
        ...(cookie ? { cookie } : {})
      },
      ...(body ? { body: JSON.stringify(body) } : {})
    });
    merge(res);
    let data = null;
    try { data = await res.json(); } catch { /* non-JSON */ }
    return { status: res.status, data };
  };
  return request;
}

async function runScenarios(t, api, csrf, ctx) {
  const { roomX, roomY, subject, DURATION, body, addMinutes } = ctx;
  const w0 = ['07:30', addMinutes('07:30', DURATION)];
  const meta = (await api('/api/scheduling/meta')).data;
  const semester = meta.semesters.find(s => s.isCurrent) || meta.semesters[0];
  assert.ok(semester, 'a semester must exist for availability checks');
  const courseId = meta.courses.find(c => c.code === 'IT')?._id || meta.courses[0]._id;
  const sectionKey = 'O:1';
  const availability = (query) => api('/api/scheduling/rooms/available?' + new URLSearchParams({
    semester: semester._id,
    course: courseId,
    sectionKey,
    subject: subject._id,
    ...query
  }).toString());

  await t.test('valid start times use the real session length and clear instructor conflicts', async () => {
    // Put the instructor in a different section, so only the instructor rule can
    // remove 10:00 and its overlapping neighbours from the offered starts.
    const blocker = await api('/api/schedules', {
      method: 'POST', csrf,
      body: body(roomX._id, '10:00', '11:00', {
        instructor: ctx.instructorId,
        weekdays: ['Mon', 'Wed', 'Fri'],
        yearLevel: 2,
        sectionType: 'Open',
        blockLabel: ''
      })
    });
    assert.equal(blocker.status, 201, JSON.stringify(blocker.data));
    try {
      const answer = await availability({ day: 'MWF', instructor: ctx.instructorId });
      assert.equal(answer.status, 200, JSON.stringify(answer.data));
      assert.equal(answer.data.sessionMinutes, 60);
      const starts = answer.data.validTimes.map(s => s.start);
      assert.ok(starts.includes('11:00'), 'the slot after the instructor class must be offered: ' + starts.join(','));
      assert.ok(!starts.includes('10:00'), 'the exact instructor slot must not be offered');
      assert.ok(!starts.includes('09:30'), 'a start overlapping the instructor class must not be offered');
      assert.ok(!starts.includes('10:30'), 'a start overlapping the instructor class must not be offered');
      for (const slot of answer.data.validTimes) {
        assert.equal(addMinutes(slot.start, 60), slot.end, `MWF ${slot.start} must last 60 minutes`);
        assert.ok(slot.freeRooms > 0, 'every offered start must have a room');
      }

      const tth = await availability({ day: 'TTH', instructor: ctx.instructorId });
      assert.equal(tth.status, 200, JSON.stringify(tth.data));
      assert.equal(tth.data.sessionMinutes, 90);
      for (const slot of tth.data.validTimes) {
        assert.equal(addMinutes(slot.start, 90), slot.end, `TTh ${slot.start} must last 90 minutes`);
      }
    } finally {
      await api('/api/scheduling/schedules/' + blocker.data._id, { method: 'DELETE', csrf });
    }
  });

  await t.test('rooms smaller than the planned section are blocked, not offered', async () => {
    const originalCapacity = roomY.capacity;
    const shrunk = await api('/api/rooms/' + roomY._id, { method: 'PATCH', csrf, body: { capacity: 5 } });
    assert.equal(shrunk.status, 200, JSON.stringify(shrunk.data));
    try {
      const answer = await availability({ day: 'MWF', startTime: '09:00' });
      assert.equal(answer.status, 200, JSON.stringify(answer.data));
      assert.equal(answer.data.requiredSeats, 10);
      assert.ok(!answer.data.available.some(r => String(r._id) === String(roomY._id)), 'the 5-seat room must not be available');
      const blocked = answer.data.blocked.find(r => String(r._id) === String(roomY._id));
      assert.ok(blocked, 'the 5-seat room must be reported as blocked');
      assert.equal(blocked.reason, 'capacity');
      assert.match(blocked.message, /5 seats/);
      assert.ok(Array.isArray(answer.data.available[0].equipment), 'room cards receive the equipment list');
    } finally {
      await api('/api/rooms/' + roomY._id, { method: 'PATCH', csrf, body: { capacity: originalCapacity } });
    }
  });

  await t.test('a fresh room shows Available in the room list', async () => {
    const rooms = (await api('/api/rooms?status=Active')).data;
    const row = rooms.find(r => r._id === roomX._id);
    assert.ok(row, 'room must appear in the list');
    assert.equal(row.availability, 'Available');
  });

  await t.test('after booking, room list still shows Available (day not full)', async () => {
    const created = await api('/api/schedules', { method: 'POST', csrf, body: body(roomX._id, w0[0], w0[1]) });
    assert.equal(created.status, 201, JSON.stringify(created.data));
    const rooms = (await api('/api/rooms?status=Active')).data;
    assert.equal(rooms.find(r => r._id === roomX._id).availability, 'Available'); // 120 of 480 min
    assert.equal(rooms.find(r => r._id === roomY._id).availability, 'Available');
  });

  await t.test('an overlapping schedule in the same room is rejected with a clear error', async () => {
    const clash = await api('/api/schedules', { method: 'POST', csrf, body: body(roomX._id, '08:00', addMinutes('08:00', DURATION)) });
    assert.equal(clash.status, 409);
    assert.match(clash.data.message, /already in use/);
  });

  await t.test('the room fills to exactly 8 hours, then further Monday bookings are rejected', async () => {
    let start = w0[1];
    for (let i = 0; i < 7; i++) { // schedules 2..8 -> 8 x 60 min = 480 min exactly
      const res = await api('/api/schedules', { method: 'POST', csrf, body: body(roomX._id, start, addMinutes(start, DURATION)) });
      assert.equal(res.status, 201, 'booking ' + (i + 2) + ' should fit: ' + JSON.stringify(res.data));
      start = addMinutes(start, DURATION);
    }
    const over = await api('/api/schedules', { method: 'POST', csrf, body: body(roomX._id, start, addMinutes(start, DURATION)) });
    assert.equal(over.status, 409);
    assert.match(over.data.message, /already reached its 8-hour daily limit on Mon/);
    // A different room at a time when the instructor is also free is unaffected.
    const otherRoom = await api('/api/schedules', { method: 'POST', csrf, body: body(roomY._id, '15:30', addMinutes('15:30', DURATION)) });
    assert.equal(otherRoom.status, 201, JSON.stringify(otherRoom.data));
  });

  await t.test('the room-list availability reflects the daily limit (Occupied at 8 hours)', async () => {
    const rooms = (await api('/api/rooms?status=Active')).data;
    assert.equal(rooms.find(r => r._id === roomX._id).availability, 'Occupied'); // 480/480 minutes on Monday
    assert.equal(rooms.find(r => r._id === roomY._id).availability, 'Available'); // only 120 minutes
  });

  await t.test('the conflict pre-flight endpoint reports time conflicts with real details', async () => {
    const res = await api(`/api/rooms/${roomX._id}/conflicts`, { method: 'POST', csrf, body: { weekdays: ['Mon'], startTime: '09:00', endTime: addMinutes('09:00', DURATION) } });
    assert.equal(res.status, 200);
    assert.equal(res.data.conflict, true);
    assert.equal(res.data.reason, 'time');
    assert.equal(res.data.room, roomX.roomCode);
    assert.equal(res.data.subject, subject.subjectCode);
    assert.equal(res.data.day, 'Mon');
    assert.match(res.data.time, /^\d{2}:\d{2} - \d{2}:\d{2}$/);
  });

  await t.test('the conflict pre-flight endpoint reports the daily limit for a free but full day', async () => {
    const res = await api(`/api/rooms/${roomX._id}/conflicts`, { method: 'POST', csrf, body: { weekdays: ['Mon'], startTime: '15:30', endTime: '16:30' } });
    assert.equal(res.data.conflict, true);
    assert.equal(res.data.reason, 'daily-limit');
    assert.match(res.data.message, /8-hour daily limit/);
  });

  await t.test('updating a schedule revalidates without conflicting with itself', async () => {
    const first = (await api('/api/schedules?room=' + roomX._id + '&status=Active')).data
      .find(s => s.startTime === w0[0] && String(s.room?._id) === String(roomX._id));
    assert.ok(first, 'the first created schedule must be listed');
    // Move it to Tuesday: Monday's 07:30 window frees up (day back to 360 min).
    const moved = await api('/api/schedules/' + first._id, { method: 'PATCH', csrf, body: { weekdays: ['Tue'] } });
    assert.equal(moved.status, 200, JSON.stringify(moved.data));
    const roomsAfter = (await api('/api/rooms?status=Active')).data;
    assert.equal(roomsAfter.find(r => r._id === roomX._id).availability, 'Available');
    // A fresh booking now fits the freed Monday slot.
    const refilled = await api('/api/schedules', { method: 'POST', csrf, body: body(roomX._id, w0[0], w0[1]) });
    assert.equal(refilled.status, 201, JSON.stringify(refilled.data));
    // Re-saving the very same day/time/room must not conflict with the schedule itself.
    const resave = await api('/api/schedules/' + first._id, { method: 'PATCH', csrf, body: { weekdays: ['Tue'], startTime: w0[0], endTime: addMinutes(w0[0], DURATION) } });
    assert.equal(resave.status, 200, JSON.stringify(resave.data));
  });

  await t.test('two concurrent requests cannot double-book the same room and time', async () => {
    const [a, b] = await Promise.all([
      api('/api/schedules', { method: 'POST', csrf, body: body(roomX._id, '07:30', addMinutes('07:30', DURATION), { weekdays: ['Wed'] }) }),
      api('/api/schedules', { method: 'POST', csrf, body: body(roomX._id, '07:30', addMinutes('07:30', DURATION), { weekdays: ['Wed'] }) })
    ]);
    const statuses = [a.status, b.status].sort();
    assert.deepEqual(statuses, [201, 409], 'exactly one booking succeeds: ' + JSON.stringify([a.data, b.data]));
    const rejected = a.status === 409 ? a : b;
    assert.match(rejected.data.message, /already in use/);
  });

  await t.test('the next class is recommended as a consecutive period, not the earliest gap', async () => {
    const sequenceRoom = await Room.create({
      roomCode: 'SEQ-ROOM', roomName: 'Sequence Room', roomType: 'Non-Laboratory',
      capacity: 40, building: 'Test', status: 'Active'
    });
    await Schedule.create({
      subject: subject._id,
      room: sequenceRoom._id,
      course: courseId,
      yearLevel: 3,
      sectionType: 'Open',
      blockLabel: '',
      weekdays: ['Mon', 'Wed', 'Fri'],
      startTime: '09:00',
      endTime: '10:00',
      semester: semester._id,
      status: 'Active'
    });
    const answer = await availability({ day: 'MWF', sectionKey: 'O:3' });
    assert.equal(answer.status, 200, JSON.stringify(answer.data));
    const starts = answer.data.validTimes.map(slot => slot.start);
    assert.ok(starts.includes('07:30'), 'the earlier free period remains selectable: ' + starts.join(','));
    assert.ok(starts.includes('08:00'), 'the consecutive period before the section class must be valid');
    assert.equal(answer.data.recommendedStart, '08:00', 'the consecutive period is preferred over the earlier gap');
    const earlier = answer.data.validTimes.find(slot => slot.start === '07:30');
    const adjacent = answer.data.validTimes.find(slot => slot.start === '08:00');
    assert.equal(earlier.recommended, false);
    assert.equal(adjacent.recommended, true);
  });

  await t.test('the class list stops at 10 real enrollments and records stay limited to attendance, assignments and activities', async () => {
    const capRoom = await Room.create({
      roomCode: 'CAP-ROOM', roomName: 'Class Cap Room', roomType: 'Non-Laboratory',
      capacity: 40, building: 'Test', status: 'Active'
    });
    const capSchedule = await Schedule.create({
      subject: subject._id,
      room: capRoom._id,
      course: courseId,
      yearLevel: 1,
      sectionType: 'Open',
      blockLabel: '',
      weekdays: ['Sat'],
      startTime: '07:30',
      endTime: '08:30',
      instructor: ctx.instructorId,
      semester: semester._id,
      status: 'Active'
    });

    const passwordHash = bcrypt.hashSync('Password123!', 10);
    const studentIds = [];
    for (let i = 1; i <= 11; i++) {
      const n = String(i).padStart(2, '0');
      const user = await User.create({
        role: 'Student',
        username: 'capstudent' + n,
        email: 'capstudent' + n + '@test.local',
        passwordHash,
        status: 'Active'
      });
      const student = await Student.create({
        user: user._id,
        studentId: 'CAP-' + n,
        firstName: 'Cap',
        lastName: 'Student' + n,
        contactNumber: '091700000' + n,
        course: courseId,
        yearLevel: 1,
        status: 'Active'
      });
      studentIds.push(student._id);
    }

    const enrollments = [];
    for (let i = 0; i < 10; i++) {
      const res = await api('/api/enrollments', {
        method: 'POST', csrf,
        body: { studentId: studentIds[i], scheduleId: capSchedule._id }
      });
      assert.equal(res.status, 201, 'enrollment ' + (i + 1) + ': ' + JSON.stringify(res.data));
      enrollments.push(res.data.enrollment);
    }
    const over = await api('/api/enrollments', {
      method: 'POST', csrf,
      body: { studentId: studentIds[10], scheduleId: capSchedule._id }
    });
    assert.equal(over.status, 409, JSON.stringify(over.data));
    assert.match(over.data.message, /limit of 10 students/);
    assert.equal(await Enrollment.countDocuments({ schedule: capSchedule._id, status: 'Active' }), 10);

    // The instructor sees the same 10 real enrollments and can record only the
    // three class-record columns. A stray grade field is rejected.
    const instructorApi = makeClient();
    const loginCsrf = (await instructorApi('/api/auth/csrf')).data.csrfToken;
    const instructorLogin = await instructorApi('/api/auth/login', {
      method: 'POST', csrf: loginCsrf,
      body: { login: 'roomtest.instructor', password: 'Password123!', rememberMe: false }
    });
    assert.equal(instructorLogin.status, 200, JSON.stringify(instructorLogin.data));
    const instructorCsrf = instructorLogin.data.csrfToken;

    const records = await instructorApi('/api/instructor-portal/subjects/' + capSchedule._id + '/records');
    assert.equal(records.status, 200, JSON.stringify(records.data));
    assert.equal(records.data.students.length, 10);
    assert.ok(records.data.students.every(row => row.student && row.student.studentId.startsWith('CAP-')));

    const enrollmentId = String(enrollments[0]._id || enrollments[0]);
    const saved = await instructorApi('/api/instructor-portal/subjects/' + capSchedule._id + '/records', {
      method: 'POST', csrf: instructorCsrf,
      body: { rows: [{ enrollment: enrollmentId, attendancePresent: 1, assignments: 88, activities: 92 }] }
    });
    assert.equal(saved.status, 200, JSON.stringify(saved.data));
    const savedRow = saved.data.students.find(row => String(row.enrollment) === enrollmentId);
    assert.ok(savedRow && savedRow.record);
    assert.equal(savedRow.record.assignments, 88);
    assert.equal(savedRow.record.activities, 92);

    const strayGrade = await instructorApi('/api/instructor-portal/subjects/' + capSchedule._id + '/records', {
      method: 'POST', csrf: instructorCsrf,
      body: { rows: [{ enrollment: enrollmentId, attendancePresent: 1, assignments: 88, activities: 92, finalGrade: 1.25 }] }
    });
    assert.equal(strayGrade.status, 400, JSON.stringify(strayGrade.data));
    assert.match(strayGrade.data.message, /only hold attendance, assignments and activities/);
  });
}

const addMinutes = (hhmm, minutesToAdd) => {
  const [h, m] = hhmm.split(':').map(Number);
  const total = h * 60 + m + minutesToAdd;
  return String(Math.floor(total / 60)).padStart(2, '0') + ':' + String(total % 60).padStart(2, '0');
};

test('room availability HTTP API', async t => {
  t.after(async () => {
    if (server) server.kill();
    if (mongoose.connection.readyState) {
      await mongoose.connection.dropDatabase();
      await mongoose.disconnect();
    }
  });

  // 1. Boot the real server against the temp database.
  server = spawn(process.execPath, ['server.js'], {
    cwd: ROOT,
    env: {
      ...process.env,
      PORT: String(PORT),
      MONGODB_URI: TEST_URI,
      SESSION_SECRET: 'room-availability-test-secret-0123456789abcdef',
      NODE_ENV: 'development'
    },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let bootError = '';
  server.stderr.on('data', d => { bootError += String(d); });
  const deadline = Date.now() + 120000;
  let up = false;
  while (Date.now() < deadline) {
    if (server.exitCode !== null) break;
    try { const res = await fetch(BASE + '/'); if (res.ok) { up = true; break; } } catch { /* not up yet */ }
    await new Promise(r => setTimeout(r, 500));
  }
  assert.ok(up, 'server must start. Last stderr: ' + bootError.slice(-800));

  // 2. Seed users directly in the temp database and log in over HTTP.
  await mongoose.connect(TEST_URI);
  const passwordHash = bcrypt.hashSync('Password123!', 10);
  await User.create({ role: 'Admin', username: 'roomtest.admin', email: 'roomtest.admin@test.local', passwordHash });
  const instructorUser = await User.create({ role: 'Instructor', username: 'roomtest.instructor', email: 'roomtest.instructor@test.local', passwordHash });
  const instructor = await Instructor.create({ user: instructorUser._id, firstName: 'Test', lastName: 'Instructor', contactNumber: '09170000000', department: 'IT' });

  const api = makeClient();
  const csrf0 = (await api('/api/auth/csrf')).data.csrfToken;
  const login = await api('/api/auth/login', { method: 'POST', csrf: csrf0, body: { login: 'roomtest.admin', password: 'Password123!', rememberMe: false } });
  assert.equal(login.status, 200, 'admin login must succeed');
  const csrf = login.data.csrfToken;
  assert.equal(login.data.role, 'Admin');

  // 3. Fetch the same options the scheduling form uses; create a 2-unit test subject.
  const options = (await api('/api/schedules/options')).data;
  assert.ok(options.rooms.length > 0 && options.courses.length > 0);
  const course = options.courses.find(c => c.code === 'IT') || options.courses[0];
  const subject = await Subject.create({ subjectCode: 'RMTEST2', subjectName: 'Room Availability Test', course: course._id, units: 1, laboratoryRequired: false, status: 'Active' });
  const roomX = options.rooms[0];
  const roomY = options.rooms[1];
  const DURATION = subject.units * 60; // 60 minutes per single-day session
  const body = (room, startTime, endTime, extra = {}) => ({
    subject: subject._id, instructor: instructor._id, room, yearLevel: 1,
    weekdays: ['Mon'], startTime, endTime, status: 'Active', sectionType: 'Open', blockLabel: '',
    course: course._id, ...extra
  });
  return runScenarios(t, api, csrf, { roomX, roomY, subject, DURATION, body, addMinutes, instructorId: instructor._id });
});
