// End-to-end tests for the simplified public registration flow. It boots the
// real server against a throwaway database and verifies credential-only sign-up,
// unique usernames, password confirmation, bcrypt storage, Student and
// Instructor roles, Admin rejection and login with the new accounts.
// Run with: npm test
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const path = require('node:path');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const ROOT = path.join(__dirname, '..');
const PORT = 3210;
const BASE = 'http://127.0.0.1:' + PORT;
const TEST_URI = 'mongodb://127.0.0.1:27017/college_scheduling_registration_test_opencode';
const PASSWORD = 'Student@12345';

const User = require('../models/User');
const Student = require('../models/Student');
const Instructor = require('../models/Instructor');

let server = null;

function extractSetCookies(res) {
  const list = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
  return list.map(c => c.split(';')[0]).filter(Boolean);
}

function makeClient() {
  let cookie = '';
  const merge = res => {
    const parts = extractSetCookies(res);
    if (parts.length) {
      const jar = new Map(cookie ? cookie.split('; ').map(p => [p.split('=')[0], p]) : []);
      for (const p of parts) jar.set(p.split('=')[0], p);
      cookie = [...jar.values()].join('; ');
    }
  };
  return async (route, { method = 'GET', body, csrf } = {}) => {
    const res = await fetch(BASE + route, {
      method,
      headers: {
        ...(body ? { 'content-type': 'application/json' } : {}),
        ...(csrf ? { 'x-csrf-token': csrf } : {}),
        ...(cookie ? { cookie } : {})
      },
      ...(body ? { body: JSON.stringify(body) } : {})
    });
    merge(res);
    let data = null;
    try { data = await res.json(); } catch { /* non-JSON */ }
    return { status: res.status, data };
  };
}

async function fetchCsrf(client) {
  const answer = await client('/api/auth/csrf');
  assert.equal(answer.status, 200, JSON.stringify(answer.data));
  return answer.data.csrfToken;
}

async function postRegistration(client, csrf, body) {
  return client('/api/register', { method: 'POST', csrf, body });
}

test('public registration accepts credentials only and creates Student or Instructor accounts', async t => {
  t.after(async () => {
    if (server) server.kill();
    await new Promise(resolve => setTimeout(resolve, 300));
    if (mongoose.connection.readyState) {
      await mongoose.connection.dropDatabase();
      await mongoose.disconnect();
    }
  });

  await mongoose.connect(TEST_URI);
  await mongoose.connection.dropDatabase();
  await mongoose.disconnect();

  server = spawn(process.execPath, ['server.js'], {
    cwd: ROOT,
    env: {
      ...process.env,
      PORT: String(PORT),
      MONGODB_URI: TEST_URI,
      SESSION_SECRET: 'registration-test-secret-0123456789abcdef',
      NODE_ENV: 'development'
    },
    stdio: ['ignore', 'ignore', 'pipe']
  });
  let bootError = '';
  server.stderr.on('data', d => { bootError += String(d); });
  const deadline = Date.now() + 120000;
  let up = false;
  while (Date.now() < deadline) {
    if (server.exitCode !== null) break;
    try {
      const res = await fetch(BASE + '/');
      if (res.ok) { up = true; break; }
    } catch { /* not up yet */ }
    await new Promise(r => setTimeout(r, 500));
  }
  assert.ok(up, 'server must start. Last stderr: ' + bootError.slice(-800));

  await mongoose.connect(TEST_URI);
  await Promise.all([User.init(), Student.init(), Instructor.init()]);

  const stamp = Date.now();
  const username = 'new.student.' + stamp;
  const client = makeClient();
  const csrf = await fetchCsrf(client);

  const created = await postRegistration(client, csrf, {
    username,
    password: PASSWORD,
    confirmPassword: PASSWORD
  });
  assert.equal(created.status, 201, JSON.stringify(created.data));
  assert.match(created.data.studentId, new RegExp('^' + new Date().getFullYear() + '-\\d{4}$'));

  const user = await User.findOne({ username }).lean();
  assert.ok(user, 'the login account must be saved');
  assert.equal(user.role, 'Student');
  assert.equal(user.status, 'Active');
  assert.equal(user.email, username + '@student.southerncanillo.local');
  assert.notEqual(user.passwordHash, PASSWORD, 'the plain-text password must never be stored');
  assert.equal(await bcrypt.compare(PASSWORD, user.passwordHash), true, 'the saved hash must verify the password');

  const student = await Student.findOne({ user: user._id }).lean();
  assert.ok(student, 'the Student profile must be linked to the login account');
  assert.equal(student.studentId, created.data.studentId);
  assert.equal(student.firstName, username);
  assert.equal(student.course, null);

  // The new credentials must work with the existing login endpoint.
  const loginClient = makeClient();
  const loginCsrf = await fetchCsrf(loginClient);
  const login = await loginClient('/api/auth/login', {
    method: 'POST', csrf: loginCsrf,
    body: { login: username, password: PASSWORD, rememberMe: false }
  });
  assert.equal(login.status, 200, JSON.stringify(login.data));
  assert.equal(login.data.role, 'Student');

  const me = await loginClient('/api/auth/me');
  assert.equal(me.status, 200, JSON.stringify(me.data));
  assert.equal(me.data.user.role, 'Student');
  assert.equal(me.data.profile.studentId, created.data.studentId);

  const schedule = await loginClient('/api/portal/my-schedule');
  assert.equal(schedule.status, 200, JSON.stringify(schedule.data));
  assert.deepEqual(schedule.data, []);

  // A valid Student credential must not expose Admin or Instructor endpoints.
  const adminEndpoint = await loginClient('/api/students');
  assert.equal(adminEndpoint.status, 403);
  const instructorEndpoint = await loginClient('/api/instructor-portal/subjects');
  assert.equal(instructorEndpoint.status, 403);

  // Usernames are case-insensitively unique.
  const duplicateClient = makeClient();
  const duplicateCsrf = await fetchCsrf(duplicateClient);
  const duplicate = await postRegistration(duplicateClient, duplicateCsrf, {
    username: username.toUpperCase(),
    password: 'Another@12345',
    confirmPassword: 'Another@12345'
  });
  assert.equal(duplicate.status, 409, JSON.stringify(duplicate.data));
  assert.match(duplicate.data.message, /username is already in use/i);
  assert.equal(await User.countDocuments({ username }), 1);

  // Password confirmation is enforced on the server.
  const mismatchClient = makeClient();
  const mismatchCsrf = await fetchCsrf(mismatchClient);
  const mismatchName = 'mismatch.student.' + stamp;
  const mismatch = await postRegistration(mismatchClient, mismatchCsrf, {
    username: mismatchName,
    password: PASSWORD,
    confirmPassword: 'Different@12345'
  });
  assert.equal(mismatch.status, 400, JSON.stringify(mismatch.data));
  assert.match(mismatch.data.message, /confirmation does not match/i);
  assert.equal(await User.exists({ username: mismatchName }), null);

  // Public registration cannot create an Admin account.
  const adminClient = makeClient();
  const adminCsrf = await fetchCsrf(adminClient);
  const adminName = 'pretend.admin.' + stamp;
  const adminAttempt = await postRegistration(adminClient, adminCsrf, {
    role: 'Admin',
    username: adminName,
    password: PASSWORD,
    confirmPassword: PASSWORD
  });
  assert.equal(adminAttempt.status, 400, JSON.stringify(adminAttempt.data));
  assert.match(adminAttempt.data.message, /student and instructor accounts only/i);
  assert.equal(await User.exists({ username: adminName }), null);
  assert.equal(await User.exists({ username: adminName, role: 'Admin' }), null);

  // The same credential-only form can create an Instructor account. The server
  // generates the Instructor ID and links the Instructor profile.
  const instructorClient = makeClient();
  const instructorCsrf = await fetchCsrf(instructorClient);
  const instructorName = 'new.instructor.' + stamp;
  const instructorCreated = await postRegistration(instructorClient, instructorCsrf, {
    role: 'Instructor',
    username: instructorName,
    password: PASSWORD,
    confirmPassword: PASSWORD
  });
  assert.equal(instructorCreated.status, 201, JSON.stringify(instructorCreated.data));
  assert.equal(instructorCreated.data.role, 'Instructor');
  assert.match(instructorCreated.data.instructorId, /^INS-\d{3}$/);
  assert.equal(instructorCreated.data.studentId, null);
  assert.match(instructorCreated.data.message, /Instructor ID/i);

  const instructorUser = await User.findOne({ username: instructorName }).lean();
  assert.ok(instructorUser, 'the Instructor login account must be saved');
  assert.equal(instructorUser.role, 'Instructor');
  assert.equal(instructorUser.email, instructorName + '@instructor.southerncanillo.local');
  assert.equal(await bcrypt.compare(PASSWORD, instructorUser.passwordHash), true);

  const instructor = await Instructor.findOne({ user: instructorUser._id }).lean();
  assert.ok(instructor, 'the Instructor profile must be linked to the login account');
  assert.equal(instructor.instructorId, instructorCreated.data.instructorId);
  assert.equal(instructor.firstName, instructorName);
  assert.equal(instructor.department, '');

  const instructorLoginClient = makeClient();
  const instructorLoginCsrf = await fetchCsrf(instructorLoginClient);
  const instructorLogin = await instructorLoginClient('/api/auth/login', {
    method: 'POST', csrf: instructorLoginCsrf,
    body: { login: instructorName, password: PASSWORD, rememberMe: false }
  });
  assert.equal(instructorLogin.status, 200, JSON.stringify(instructorLogin.data));
  assert.equal(instructorLogin.data.role, 'Instructor');

  const instructorMe = await instructorLoginClient('/api/auth/me');
  assert.equal(instructorMe.status, 200, JSON.stringify(instructorMe.data));
  assert.equal(instructorMe.data.user.role, 'Instructor');
  assert.equal(instructorMe.data.profile.instructorId, instructorCreated.data.instructorId);

  const instructorSubjects = await instructorLoginClient('/api/instructor-portal/subjects');
  assert.equal(instructorSubjects.status, 200, JSON.stringify(instructorSubjects.data));
  assert.deepEqual(instructorSubjects.data.subjects, []);

  const instructorStudentEndpoint = await instructorLoginClient('/api/student-portal/enrollments');
  assert.equal(instructorStudentEndpoint.status, 403);

  // Concurrent attempts with the same username still create exactly one account.
  const raceName = 'race.student.' + stamp;
  const raceClients = [makeClient(), makeClient()];
  const raceTokens = await Promise.all(raceClients.map(fetchCsrf));
  const raceResults = await Promise.all(raceClients.map((raceClient, i) => postRegistration(raceClient, raceTokens[i], {
    username: raceName,
    password: i === 0 ? 'RaceOne@12345' : 'RaceTwo@12345',
    confirmPassword: i === 0 ? 'RaceOne@12345' : 'RaceTwo@12345'
  })));
  assert.deepEqual(raceResults.map(r => r.status).sort(), [201, 409]);
  assert.equal(await User.countDocuments({ username: raceName }), 1);
  assert.equal(await Student.countDocuments({ firstName: raceName }), 1);
});
