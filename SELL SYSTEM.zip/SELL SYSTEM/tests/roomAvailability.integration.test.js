﻿// Integration tests for semester-scoped room availability, the daily hour limit (settings.dailyTargetHours)
// and the in-lock room recheck. Uses a SEPARATE test database that is dropped after the run, so no
// project data is touched. Run with: npm test
const test = require('node:test');
const assert = require('node:assert/strict');
const mongoose = require('mongoose');

process.env.ROOM_DAILY_LIMIT_HOURS = '8';

const Schedule = require('../models/Schedule');
const {
  withSchedulingLock,
  checkScheduleConflicts,
  checkRoomDailyLimit,
  loadRoomSemesterSchedules,
  evaluateRoomTimeWindow,
  dailyLimitMinutesFrom,
  WEEKDAYS
} = require('../services/schedulingService');

const TEST_URI = 'mongodb://127.0.0.1:27017/college_scheduling_room_test_opencode';

const oid = () => new mongoose.Types.ObjectId();
const semA = oid(), semB = oid(), semC = oid(), semD = oid(), semE = oid();

const candidate = (roomId, roomCode, weekdays, startTime, endTime, extra = {}) => ({
  status: 'Active',
  room: { _id: roomId, roomCode },
  instructor: null,
  weekdays,
  startTime,
  endTime,
  course: oid(),
  yearLevel: 1,
  ...extra
});

async function makeSchedule(roomId, semesterId, weekdays, startTime, endTime) {
  return Schedule.create({
    subject: oid(),
    room: roomId,
    course: oid(),
    yearLevel: 1,
    weekdays,
    startTime,
    endTime,
    status: 'Active',
    semester: semesterId
  });
}

test('room availability service checks', async t => {
  await mongoose.connect(TEST_URI);
  await mongoose.connection.dropDatabase();

  await t.test('scenarios 8/9: availability is scoped to the correct school year and semester', async () => {
    const room = oid();
    await makeSchedule(room, semA, ['Mon'], '08:00', '10:00');
    // Another semester may freely use the same room at the same time.
    await checkScheduleConflicts(candidate(room, 'R1', ['Mon'], '08:00', '09:00'), null, semB);
    await checkRoomDailyLimit(candidate(room, 'R1', ['Mon'], '08:00', '09:00'), null, semB);
    // The same window inside the booked semester is rejected.
    await assert.rejects(() => checkScheduleConflicts(candidate(room, 'R1', ['Mon'], '08:00', '09:00'), null, semA), /already in use/);
  });

  await t.test('scenario 10: updating a schedule never conflicts with itself', async () => {
    const room = oid();
    const existing = await makeSchedule(room, semC, ['Tue'], '13:00', '15:00');
    const other = await makeSchedule(room, semC, ['Tue'], '16:00', '18:00');
    // Re-saving the same day/time/room passes both checks when the schedule excludes itself.
    await checkScheduleConflicts(candidate(room, 'R2', ['Tue'], '13:00', '15:00'), existing._id, semC);
    await checkRoomDailyLimit(candidate(room, 'R2', ['Tue'], '13:00', '15:00'), existing._id, semC);
    // A window that overlaps a different schedule in the room is still rejected.
    await assert.rejects(() => checkScheduleConflicts(candidate(room, 'R2', ['Tue'], '17:00', '19:00'), existing._id, semC), /already in use/);
    void other;
  });

  await t.test('scenarios 3/4/5: the 8-hour daily limit is enforced; over-limit data is reported', async () => {
    const room = oid();
    // 5 x 90-minute TTh sessions fill Monday to 450 of 480 minutes.
    const sessions = [
      ['07:30', '09:00'],
      ['09:00', '10:30'],
      ['10:30', '12:00'],
      ['12:00', '13:30'],
      ['13:30', '15:00']
    ];
    for (const [s, e] of sessions) {
      await makeSchedule(room, semD, ['Mon', 'Thu'], s, e);
    }
    // The 6th session would push the day to 540 minutes (over the 480 limit).
    await assert.rejects(() => checkRoomDailyLimit(candidate(room, 'R3', ['Mon', 'Thu'], '15:00', '16:30'), null, semD), /would exceed the room's 8-hour daily limit/);
    // Add a session that takes Monday past the limit without overlapping the next check.
    await Schedule.create({ subject: oid(), room, course: oid(), yearLevel: 1, weekdays: ['Mon', 'Thu'], startTime: '15:00', endTime: '16:30', status: 'Active', semester: semD });
    // Monday is already at/over the limit; a non-overlapping slot reports "already reached."
    await assert.rejects(() => checkRoomDailyLimit(candidate(room, 'R3', ['Mon', 'Thu'], '16:30', '17:00'), null, semD), /already reached its 8-hour daily limit/);
  });

  await t.test('scenarios 6/7: overlaps are rejected, adjacency stays usable, other days unaffected', async () => {
    const room = oid();
    await makeSchedule(room, semE, ['Mon', 'Thu'], '08:00', '09:30');
    // Back-to-back class is allowed.
    await checkScheduleConflicts(candidate(room, 'R4', ['Mon', 'Thu'], '09:30', '11:00'), null, semE);
    await checkRoomDailyLimit(candidate(room, 'R4', ['Mon', 'Thu'], '09:30', '11:00'), null, semE);
    // Same time on Tuesday is allowed (Tuesday is not a day of the existing class).
    await checkScheduleConflicts(candidate(room, 'R4', ['Tue'], '08:00', '09:30'), null, semE);
    // True overlap on Monday is rejected.
    await assert.rejects(() => checkScheduleConflicts(candidate(room, 'R4', ['Mon', 'Thu'], '09:00', '10:30'), null, semE), /already in use/);
    // Inactive schedules consume no room time.
    await Schedule.create({ subject: oid(), room, course: oid(), yearLevel: 1, weekdays: ['Wed'], startTime: '08:00', endTime: '17:00', status: 'Inactive', semester: semE });
    await checkRoomDailyLimit(candidate(room, 'R4', ['Wed'], '08:00', '10:00'), null, semE);
  });

  await t.test('scenario 11: two concurrent attempts cannot double-book the same room and time', async () => {
    const room = oid();
    const book = () => withSchedulingLock(async () => {
      const c = candidate(room, 'R5', ['Thu'], '16:00', '17:30');
      await checkScheduleConflicts(c, null, semA);
      await checkRoomDailyLimit(c, null, semA);
      await Schedule.create({
        subject: oid(), room, course: oid(), yearLevel: 1,
        weekdays: c.weekdays, startTime: c.startTime, endTime: c.endTime,
        status: 'Active', semester: semA
      });
    });
    const results = await Promise.allSettled([book(), book()]);
    const fulfilled = results.filter(r => r.status === 'fulfilled');
    const rejected = results.filter(r => r.status === 'rejected');
    assert.equal(fulfilled.length, 1, 'exactly one booking should succeed');
    assert.equal(rejected.length, 1, 'the other attempt must be rejected');
    assert.match(rejected[0].reason.message, /already in use/);
    assert.equal(await Schedule.countDocuments({ room, semester: semA, weekdays: 'Thu' }), 1);
  });

  await t.test('section conflicts are rejected while adjacent periods and other sections stay valid', async () => {
    const room = oid();
    const otherRoom = oid();
    const course = oid();
    await Schedule.create({
      subject: oid(), room, course, yearLevel: 1,
      sectionType: 'Open', blockLabel: '',
      weekdays: ['Mon'], startTime: '08:00', endTime: '09:00',
      status: 'Active', semester: semB
    });

    await assert.rejects(
      () => checkScheduleConflicts(candidate(otherRoom, 'R6', ['Mon'], '08:30', '09:30', {
        course, yearLevel: 1, sectionType: 'Open', blockLabel: ''
      }), null, semB),
      /Open Section · Year 1 already has a class/
    );
    // The period immediately after the section's class is not a conflict.
    await checkScheduleConflicts(candidate(otherRoom, 'R6', ['Mon'], '09:00', '10:00', {
      course, yearLevel: 1, sectionType: 'Open', blockLabel: ''
    }), null, semB);
    // A different year level is a different section.
    await checkScheduleConflicts(candidate(otherRoom, 'R6', ['Mon'], '08:30', '09:30', {
      course, yearLevel: 2, sectionType: 'Open', blockLabel: ''
    }), null, semB);
  });

    // Drop the test database and close the connection so the test runner can exit.
    await mongoose.connection.dropDatabase();
    await mongoose.disconnect();
  });

