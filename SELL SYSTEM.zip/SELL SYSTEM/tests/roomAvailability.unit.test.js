// Unit tests for room-availability logic in services/schedulingService.js.
// Run with: npm test   (Node's built-in test runner; no database needed)
const test = require('node:test');
const assert = require('node:assert/strict');

const {
  minutes,
  overlaps,
  sameDay,
  mergeIntervals,
  sumMergedMinutes,
  evaluateRoomTimeWindow,
  dailyLimitMinutesFrom,
  isSameSection,
  sectionName,
  WEEKDAYS
} = require('../services/schedulingService');

const {
  seatsFor,
  plannedSectionSize,
  CLASS_LIST_LIMIT
} = require('../services/settingsService');

const LIMIT = 480; // 8 hours in minutes
const sched = (w, s, e) => ({ weekdays: w, startTime: s, endTime: e });

test('scenario 12: back-to-back classes do not conflict', () => {
  assert.equal(overlaps('08:00', '09:00', '09:00', '10:00'), false);
  assert.equal(overlaps('09:00', '10:00', '08:00', '09:00'), false);
  assert.equal(sameDay(['Mon', 'Wed'], ['Wed', 'Fri']), true);
  assert.equal(minutes('07:30'), 450);
});

test('mergeIntervals counts overlapping and back-to-back intervals once', () => {
  assert.equal(sumMergedMinutes([{ start: 450, end: 750 }, { start: 660, end: 780 }]), 330);
  assert.equal(sumMergedMinutes([{ start: 480, end: 540 }, { start: 540, end: 600 }]), 120);
  assert.deepEqual(mergeIntervals([{ start: 540, end: 600 }, { start: 480, end: 540 }]), [{ start: 480, end: 600 }]);
});

test('dailyTargetHours configures the limit (default 8 = 480 minutes)', () => {
  assert.equal(dailyLimitMinutesFrom({}), 480);
  assert.equal(dailyLimitMinutesFrom({ dailyTargetHours: 10 }), 600);
});

test('scenario 1: a room with no schedules accepts any valid window', () => {
  const verdict = evaluateRoomTimeWindow([], ['Mon', 'Tue'], '07:30', '09:30', LIMIT);
  assert.equal(verdict.ok, true);
  assert.equal(verdict.busiestMinutes, 0);
  assert.equal(verdict.duration, 120);
});

test('scenario 2: free slot is allowed, overlapping slot is not', () => {
  const schedules = [sched(['Mon'], '07:30', '09:30')];
  const free = evaluateRoomTimeWindow(schedules, ['Mon'], '09:30', '10:30', LIMIT);
  assert.equal(free.ok, true);
  assert.equal(free.perDay[0].occupiedMinutes, 120);
  const clash = evaluateRoomTimeWindow(schedules, ['Mon'], '09:00', '10:00', LIMIT);
  assert.equal(clash.ok, false);
  assert.equal(clash.perDay[0].conflict, true);
  assert.match(clash.reason, /already has a class/);
});

test('scenario 3: exactly 8 scheduled hours blocks further Monday bookings but not other days', () => {
  const schedules = [
    sched(['Mon'], '07:30', '09:30'),
    sched(['Mon'], '09:30', '11:30'),
    sched(['Mon'], '11:30', '13:30'),
    sched(['Mon'], '13:30', '15:30')
  ];
  const verdict = evaluateRoomTimeWindow(schedules, ['Mon'], '15:30', '16:30', LIMIT);
  assert.equal(verdict.busiestMinutes, LIMIT);
  assert.equal(verdict.ok, false);
  assert.match(verdict.reason, /already reached its 8-hour daily limit on Mon/);
  const tuesday = evaluateRoomTimeWindow(schedules, ['Tue'], '15:30', '16:30', LIMIT);
  assert.equal(tuesday.ok, true);
});

test('scenario 4: a room already over 8 hours reports the invalid condition', () => {
  const schedules = [sched(['Mon'], '07:30', '12:30'), sched(['Mon'], '12:30', '16:30')];
  const verdict = evaluateRoomTimeWindow(schedules, ['Mon'], '16:30', '17:00', LIMIT);
  assert.equal(verdict.busiestMinutes, 540);
  assert.equal(verdict.ok, false);
  assert.match(verdict.reason, /already reached its 8-hour daily limit/);
});

test('scenario 5: exceeding the daily limit is rejected even in a free slot', () => {
  const schedules = [sched(['Mon'], '07:30', '14:30')]; // 420 used
  const verdict = evaluateRoomTimeWindow(schedules, ['Mon'], '14:30', '16:00', LIMIT); // +90 -> 510
  assert.equal(verdict.perDay[0].conflict, false);
  assert.equal(verdict.ok, false);
  assert.match(verdict.reason, /would exceed the room's 8-hour daily limit/);
  const fits = evaluateRoomTimeWindow(schedules, ['Mon'], '14:30', '15:30', LIMIT);
  assert.equal(fits.ok, true);
});

test('scenario 6: overlapping requested time is a conflict', () => {
  const schedules = [sched(['Mon', 'Wed'], '10:00', '11:00')];
  for (const day of ['Mon', 'Wed']) {
    const verdict = evaluateRoomTimeWindow(schedules, [day], '10:30', '11:30', LIMIT);
    assert.equal(verdict.ok, false, day + ' should conflict');
    assert.equal(verdict.perDay[0].conflict, true);
  }
});

test('scenario 7: a room free on Tuesday but booked on Monday is judged per day', () => {
  const schedules = [sched(['Mon'], '07:30', '12:00'), sched(['Mon'], '12:00', '15:30')];
  const monday = evaluateRoomTimeWindow(schedules, ['Mon'], '08:00', '09:00', LIMIT);
  assert.equal(monday.ok, false);
  const tuesday = evaluateRoomTimeWindow(schedules, ['Tue'], '08:00', '09:00', LIMIT);
  assert.equal(tuesday.ok, true);
  const both = evaluateRoomTimeWindow(schedules, ['Mon', 'Tue'], '08:00', '09:00', LIMIT);
  assert.equal(both.ok, false);
  const perDay = Object.fromEntries(both.perDay.map(d => [d.day, d.ok]));
  assert.deepEqual(perDay, { Mon: false, Tue: true });
});

test('scenario 10: an existing class does not block a free slot on the same day', () => {
  const existing = sched(['Tue'], '13:00', '15:00');
  const verdict = evaluateRoomTimeWindow([existing], ['Tue'], '16:00', '17:30', LIMIT);
  assert.equal(verdict.ok, true);
  assert.equal(verdict.perDay[0].conflict, false);
});

test('scenario 11: concurrent attempts cannot both succeed (verdict level)', () => {
  const schedA = sched(['Thu'], '16:00', '17:30');
  const first = evaluateRoomTimeWindow([], ['Thu'], '16:00', '17:30', LIMIT);
  const second = evaluateRoomTimeWindow([schedA], ['Thu'], '16:00', '17:30', LIMIT);
  assert.equal(first.ok, true);
  assert.equal(second.ok, false);
  assert.match(second.reason, /already has a class at that time on Thu/);
});

test('class list capacity is hard-capped at 10 regardless of settings or room size', () => {
  assert.equal(CLASS_LIST_LIMIT, 10);
  assert.equal(plannedSectionSize({ sectionCapacity: 25 }), 10);
  assert.equal(plannedSectionSize({ sectionCapacity: 7 }), 7);
  assert.equal(plannedSectionSize({}), 10);
  assert.equal(seatsFor(40, { sectionCapacity: 25 }), 10);
  assert.equal(seatsFor(40, { sectionCapacity: 10 }), 10);
  assert.equal(seatsFor(8, { sectionCapacity: 10 }), 8);
  assert.equal(seatsFor(40, { sectionCapacity: 5 }), 5);
  assert.equal(seatsFor(0, { sectionCapacity: 10 }), 0);
});

test('section identity normalizes legacy rows and labels the year', () => {
  const course = '64b000000000000000000001';
  const a = { course, yearLevel: 1, sectionType: 'Open', blockLabel: '' };
  const b = { course, yearLevel: 1 };
  const c = { course, yearLevel: 2, sectionType: 'Open', blockLabel: '' };
  assert.equal(isSameSection(a, b), true);
  assert.equal(isSameSection(a, c), false);
  assert.match(sectionName(a), /Open Section · Year 1/);
  assert.match(sectionName({ course, yearLevel: 3, sectionType: 'Block', blockLabel: 'bsit 3a' }), /Block bsit 3a · Year 3/);
});
