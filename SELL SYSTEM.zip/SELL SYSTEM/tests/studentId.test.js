// End-to-end registration tests for automatic Student ID allocation. The suite
// boots the real server against a throwaway MongoDB database, then verifies
// sequential registration, simultaneous registration, profile/admin visibility,
// and that existing IDs are never overwritten. Run with: npm test
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const path = require('node:path');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const ROOT = path.join(__dirname, '..');
const PORT = 3209;
const BASE = 'http://127.0.0.1:' + PORT;
const TEST_URI = 'mongodb://127.0.0.1:27017/college_scheduling_studentid_test_opencode';
const PASSWORD = 'Student@12345';

const Student = require('../models/Student');
const User = require('../models/User');
const Course = require('../models/Course');
const Counter = require('../models/Counter');

let server = null;

function extractSetCookies(res) {
  const list = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
  return list.map(c => c.split(';')[0]).filter(Boolean);
}

function makeClient() {
  let cookie = '';
  const merge = res => {
    const parts = extractSetCookies(res);
    if (parts.length) {
      const jar = new Map(cookie ? cookie.split('; ').map(p => [p.split('=')[0], p]) : []);
      for (const p of parts) jar.set(p.split('=')[0], p);
      cookie = [...jar.values()].join('; ');
    }
  };
  return async (route, { method = 'GET', body, csrf } = {}) => {
    const res = await fetch(BASE + route, {
      method,
      headers: {
        ...(body ? { 'content-type': 'application/json' } : {}),
        ...(csrf ? { 'x-csrf-token': csrf } : {}),
        ...(cookie ? { cookie } : {})
      },
      ...(body ? { body: JSON.stringify(body) } : {})
    });
    merge(res);
    let data = null;
    try { data = await res.json(); } catch { /* non-JSON */ }
    return { status: res.status, data };
  };
}

async function fetchCsrf(client) {
  const answer = await client('/api/auth/csrf');
  assert.equal(answer.status, 200, JSON.stringify(answer.data));
  return answer.data.csrfToken;
}

async function registerStudent(index) {
  const client = makeClient();
  const csrf = await fetchCsrf(client);
  const stamp = Date.now() + '-' + index;
  const body = {
    username: 'studentid.' + stamp,
    password: PASSWORD,
    confirmPassword: PASSWORD,
    // The public endpoint creates Student accounts only and must ignore extra fields.
    studentId: 'MANUAL-IGNORED-' + index
  };
  const response = await client('/api/register', { method: 'POST', csrf, body });
  return { client, body, response };
}

test('student registration generates unique, persisted Student IDs', async t => {
  t.after(async () => {
    if (server) server.kill();
    await new Promise(resolve => setTimeout(resolve, 300));
    if (mongoose.connection.readyState) {
      await mongoose.connection.dropDatabase();
      await mongoose.disconnect();
    }
  });

  // Start from a clean test database, then boot the real application.
  await mongoose.connect(TEST_URI);
  await mongoose.connection.dropDatabase();
  await mongoose.disconnect();

  server = spawn(process.execPath, ['server.js'], {
    cwd: ROOT,
    env: {
      ...process.env,
      PORT: String(PORT),
      MONGODB_URI: TEST_URI,
      SESSION_SECRET: 'student-id-test-secret-0123456789abcdef',
      NODE_ENV: 'development'
    },
    stdio: ['ignore', 'ignore', 'pipe']
  });
  let bootError = '';
  server.stderr.on('data', d => { bootError += String(d); });
  const deadline = Date.now() + 120000;
  let up = false;
  while (Date.now() < deadline) {
    if (server.exitCode !== null) break;
    try {
      const res = await fetch(BASE + '/');
      if (res.ok) { up = true; break; }
    } catch { /* not up yet */ }
    await new Promise(r => setTimeout(r, 500));
  }
  assert.ok(up, 'server must start. Last stderr: ' + bootError.slice(-800));

  await mongoose.connect(TEST_URI);
  await Promise.all([Student.init(), Counter.init()]);

  const course = await Course.findOne({ code: 'IT', status: 'Active' }).lean() || await Course.findOne({ status: 'Active' }).lean();
  assert.ok(course, 'an active course must exist for registration');

  // A pre-existing ID must be preserved, and the generator must skip it.
  const year = new Date().getFullYear();
  const legacyId = year + '-0001';
  const legacyUser = await User.create({
    role: 'Student',
    username: 'legacy.student',
    email: 'legacy.student@test.local',
    passwordHash: bcrypt.hashSync(PASSWORD, 10)
  });
  await Student.create({
    user: legacyUser._id,
    studentId: legacyId,
    firstName: 'Legacy',
    lastName: 'Student',
    contactNumber: '09170000000',
    course: course._id,
    yearLevel: 1
  });

  const first = await registerStudent(1);
  assert.equal(first.response.status, 201, JSON.stringify(first.response.data));
  const firstId = first.response.data.studentId;
  assert.equal(firstId, year + '-0002', 'the generator must skip the existing 0001 record');
  assert.match(firstId, new RegExp('^' + year + '-\\d{4}$'));
  assert.notEqual(firstId, 'MANUAL-IGNORED-1');

  const studentLoginCsrf = await fetchCsrf(first.client);
  const studentLogin = await first.client('/api/auth/login', {
    method: 'POST', csrf: studentLoginCsrf,
    body: { login: first.body.username, password: PASSWORD, rememberMe: false }
  });
  assert.equal(studentLogin.status, 200, JSON.stringify(studentLogin.data));
  const profile = await first.client('/api/profile');
  assert.equal(profile.status, 200, JSON.stringify(profile.data));
  assert.equal(profile.data.profile.studentId, firstId, 'the generated ID must appear on the student profile');

  // The same ID must be visible in the Admin Portal student records.
  const adminPassword = 'Admin@12345';
  await User.create({
    role: 'Admin',
    username: 'studentid.admin',
    email: 'studentid.admin@test.local',
    passwordHash: bcrypt.hashSync(adminPassword, 10)
  });
  const adminClient = makeClient();
  const adminLoginCsrf = await fetchCsrf(adminClient);
  const adminLogin = await adminClient('/api/auth/login', {
    method: 'POST', csrf: adminLoginCsrf,
    body: { login: 'studentid.admin', password: adminPassword, rememberMe: false }
  });
  assert.equal(adminLogin.status, 200, JSON.stringify(adminLogin.data));
  const adminCsrf = adminLogin.data.csrfToken;
  const adminStudents = await adminClient('/api/students');
  assert.equal(adminStudents.status, 200, JSON.stringify(adminStudents.data));
  assert.ok(adminStudents.data.some(s => s.studentId === firstId), 'the generated ID must appear in the admin student list');

  // Simultaneous registrations must all receive different IDs.
  const parallel = await Promise.all(Array.from({ length: 6 }, (_, i) => registerStudent(10 + i)));
  parallel.forEach(({ response }, i) => {
    assert.equal(response.status, 201, 'parallel registration ' + (i + 1) + ': ' + JSON.stringify(response.data));
  });
  const parallelIds = parallel.map(({ response }) => response.data.studentId);
  assert.equal(new Set(parallelIds).size, parallelIds.length, 'parallel registrations must receive unique IDs');
  parallelIds.forEach(id => {
    assert.match(id, new RegExp('^' + year + '-\\d{4}$'));
    assert.ok(!String(id).startsWith('MANUAL-IGNORED-'));
  });
  assert.equal(await Student.countDocuments({ studentId: { $in: parallelIds } }), parallelIds.length);
  assert.equal(await Student.countDocuments({ studentId: /^MANUAL-IGNORED-/ }), 0);

  // Admin-created students also receive a generated ID when none is supplied.
  const adminCreated = await adminClient('/api/students', {
    method: 'POST', csrf: adminCsrf,
    body: {
      firstName: 'Admin',
      middleName: '',
      lastName: 'Created',
      contactNumber: '09170009999',
      course: course.code,
      yearLevel: 1,
      email: 'admin.created.student@test.local',
      username: 'admin.created.student',
      password: PASSWORD,
      confirmPassword: PASSWORD
    }
  });
  assert.equal(adminCreated.status, 201, JSON.stringify(adminCreated.data));
  const adminCreatedId = adminCreated.data.studentId;
  assert.match(adminCreatedId, new RegExp('^' + year + '-\\d{4}$'));
  assert.ok(!parallelIds.includes(adminCreatedId));
  assert.ok(adminCreatedId !== firstId);

  const allIds = [firstId, ...parallelIds, adminCreatedId];
  assert.equal(await Student.countDocuments({ studentId: { $in: allIds } }), allIds.length);
});
