// Integration test for Rooms > Schedule Plotting availability.
//
// It boots the REAL routes/schedulingModule.js router on an ephemeral port and
// drives it over HTTP against a THROWAWAY database (college_scheduling_test).
// The production database is never touched. Auth is neutralized by replacing
// middleware/auth in the require cache before the router loads.
//
// Usage (MongoDB must be running locally):
//   node scripts\test-room-availability.js

process.env.MONGODB_URI = process.env.TEST_MONGODB_URI || 'mongodb://127.0.0.1:27017/college_scheduling_test';

const path = require('path');
const mongoose = require('mongoose');

// 1) Neutralize auth before the router loads.
const authPath = require.resolve(path.join(__dirname, '..', 'middleware', 'auth.js'));
require.cache[authPath] = {
  id: authPath, filename: authPath, loaded: true, exports: {
    requireAuth: (req, res, next) => { req.user = { _id: '000000000000000000000001', role: 'Admin' }; next(); },
    requireRole: () => (req, res, next) => next(),
    csrfProtect: (req, res, next) => next()
  }
};

const express = require('express');
const { errorHandler } = require(path.join(__dirname, '..', 'middleware', 'errors'));
const Semester = require(path.join(__dirname, '..', 'models', 'Semester'));
const Course = require(path.join(__dirname, '..', 'models', 'Course'));
const Room = require(path.join(__dirname, '..', 'models', 'Room'));
const Subject = require(path.join(__dirname, '..', 'models', 'Subject'));
const Schedule = require(path.join(__dirname, '..', 'models', 'Schedule'));

const results = [];
const check = (name, pass, info) => {
  results.push({ name, pass, info: info || '' });
  console.log(`${pass ? 'PASS' : 'FAIL'}  ${name}${info ? `  [${info}]` : ''}`);
};

(async () => {
  await mongoose.connect(process.env.MONGODB_URI);
  await mongoose.connection.dropDatabase();

  // ---- seed ----------------------------------------------------------------
  const sem = await Semester.create({ academicYear: '2026-2027', term: '1st Semester', startDate: new Date('2026-06-01'), endDate: new Date('2027-04-30'), isCurrent: true });
  const course = await Course.create({ code: 'PSC', name: 'Plot Sample Course' });
  const lec1 = await Room.create({ roomCode: 'PT1-LEC1', roomName: 'Plot Lecture 1', roomType: 'Non-Laboratory', capacity: 40 });
  const lec2 = await Room.create({ roomCode: 'PT1-LEC2', roomName: 'Plot Lecture 2', roomType: 'Non-Laboratory', capacity: 40 });
  const lab1 = await Room.create({ roomCode: 'PT1-LAB1', roomName: 'Plot Lab 1', roomType: 'Laboratory', capacity: 30 });
  const oldRoom = await Room.create({ roomCode: 'PT1-OLD', roomName: 'Plot Retired', roomType: 'Non-Laboratory', capacity: 30, status: 'Inactive' });
  const psub = await Subject.create({ subjectCode: 'PSUB101', subjectName: 'Plot Sample Lecture', course: course._id, units: 3 });
  const plab = await Subject.create({ subjectCode: 'PLAB101', subjectName: 'Plot Sample Lab', course: course._id, units: 3, laboratoryRequired: true });

  // S1: Open Section Year 1, MWF 10:00-11:00 in LEC1. S2: Year 3, TTh 13:00-14:30 in LEC2.
  const s1 = await Schedule.create({ subject: psub._id, room: lec1._id, weekdays: ['Mon', 'Wed', 'Fri'], startTime: '10:00', endTime: '11:00', course: course._id, yearLevel: 1, sectionType: 'Open', status: 'Active', semester: sem._id });
  await Schedule.create({ subject: psub._id, room: lec2._id, weekdays: ['Tue', 'Thu'], startTime: '13:00', endTime: '14:30', course: course._id, yearLevel: 3, sectionType: 'Open', status: 'Active', semester: sem._id });

  // ---- server --------------------------------------------------------------
  const app = express();
  app.use(express.json());
  app.use('/api/scheduling', require(path.join(__dirname, '..', 'routes', 'schedulingModule')));
  app.use(errorHandler);
  const srv = await new Promise(resolve => { const s = app.listen(0, () => resolve(s)); });
  const base = `http://127.0.0.1:${srv.address().port}/api/scheduling`;

  const avail = async q => {
    const r = await fetch(base + '/rooms/available?' + new URLSearchParams(Object.assign({ semester: sem._id, course: course._id }, q)));
    if (!r.ok) throw new Error(`availability ${r.status}: ${await r.text()}`);
    return r.json();
  };
  const assign = body => fetch(base + '/assign', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.assign({ semester: sem._id, course: course._id, instructor: null }, body)) });
  const patch = (id, body) => fetch(base + '/schedules/' + id, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const codes = d => (d.available || []).map(r => r.roomCode).sort();
  const MWF = ['Mon', 'Wed', 'Fri'];

  // ---- availability scenarios ---------------------------------------------
  // 1. A free room appears; the exact-overlap room and the inactive room do not.
  let d = await avail({ sectionKey: 'O:2', subject: psub._id, day: 'MWF', startTime: '10:00' });
  check('free rooms appear (LEC2, LAB1)', JSON.stringify(codes(d)) === JSON.stringify(['PT1-LAB1', 'PT1-LEC2']), codes(d).join(','));
  check('exactly-booked room excluded (LEC1)', !codes(d).includes('PT1-LEC1'));
  check('inactive room never listed (OLD)', !codes(d).includes('PT1-OLD'));

  // 2. Partial overlap: 10:30-11:30 overlaps the booked 10:00-11:00.
  d = await avail({ sectionKey: 'O:2', subject: psub._id, day: 'MWF', startTime: '10:30' });
  check('partially-overlapping room excluded (LEC1 @ 10:30)', !codes(d).includes('PT1-LEC1'), codes(d).join(','));

  // 3. Day-disjoint: LEC2 is booked Tue/Thu 13:00, so Friday 13:00 stays free.
  d = await avail({ sectionKey: 'O:3', subject: psub._id, day: 'F', startTime: '13:00' });
  check('day-disjoint room stays available (LEC2 on Friday)', codes(d).includes('PT1-LEC2'), codes(d).join(','));

  // 4. Day-overlap: the same LEC2 booking blocks Tuesday 13:00.
  d = await avail({ sectionKey: 'O:3', subject: psub._id, day: 'TTH', startTime: '13:00' });
  check('day-overlapping room excluded (LEC2 on TTh)', !codes(d).includes('PT1-LEC2'), codes(d).join(','));

  // 5. A lab subject only sees laboratory rooms.
  d = await avail({ sectionKey: 'O:2', subject: plab._id, day: 'MWF', startTime: '10:00' });
  check('lab subject lists only laboratory rooms', JSON.stringify(codes(d)) === JSON.stringify(['PT1-LAB1']), codes(d).join(','));

  // 6. Section conflict: same section as S1 at the same slot -> blocked, no rooms.
  d = await avail({ sectionKey: 'O:1', subject: psub._id, day: 'MWF', startTime: '10:00' });
  const secIssue = (d.slotIssues || []).find(i => i.type === 'section');
  check('section conflict sets slotValid=false', d.slotValid === false);
  check('section conflict withholds ALL rooms', (d.available || []).length === 0);
  check('section conflict message names the subject', !!secIssue && /already has PSUB101/.test(secIssue.message), secIssue && secIssue.message);

  // 7. TTh vs MWF never conflict (shared-day math).
  d = await avail({ sectionKey: 'O:2', subject: psub._id, day: 'TTH', startTime: '10:00' });
  check('TTh 10:00 is free while LEC1 has MWF 10:00', codes(d).includes('PT1-LEC1'), codes(d).join(','));

  // ---- write scenarios -----------------------------------------------------
  // 8. Backend rejects a conflicting room even if the client submits it manually.
  let r = await assign({ sectionKey: 'O:2', subject: psub._id, room: lec1._id, weekdays: MWF, startTime: '10:00' });
  let body = await r.json();
  check('assign into occupied room rejected 409', r.status === 409 && body.conflicts && body.conflicts.some(c => c.type === 'room'), `HTTP ${r.status}`);

  // 9. A lab subject cannot be plotted into a lecture room.
  r = await assign({ sectionKey: 'O:2', subject: plab._id, room: lec2._id, weekdays: MWF, startTime: '08:00' });
  body = await r.json().catch(() => ({}));
  check('lab subject in lecture room rejected 400', r.status === 400 && /laboratory/i.test(body.message || ''), `HTTP ${r.status} ${body.message || ''}`);

  // 10. The section conflict is enforced at write time too. Year 1 already has
  // S1 at MWF 10:00-11:00, so any assignment there is a section conflict even
  // when the chosen room itself is free (LEC2).
  r = await assign({ sectionKey: 'O:1', subject: psub._id, room: lec2._id, weekdays: MWF, startTime: '10:00' });
  body = await r.json();
  check('assign into a busy section rejected 409', r.status === 409 && body.conflicts && body.conflicts.some(c => c.type === 'section'), `HTTP ${r.status}`);

  // 11. Two simultaneous assignments for the same room/time: exactly one wins.
  const [a, b] = await Promise.all([
    assign({ sectionKey: 'O:2', subject: psub._id, room: lec1._id, weekdays: MWF, startTime: '08:00' }),
    assign({ sectionKey: 'O:3', subject: psub._id, room: lec1._id, weekdays: MWF, startTime: '08:00' })
  ]);
  check('simultaneous same-room assignments: exactly one succeeds', [a.status, b.status].sort().join(',') === '201,409', `statuses ${a.status},${b.status}`);

  // 12. A valid assignment succeeds and immediately marks the room busy.
  r = await assign({ sectionKey: 'O:4', subject: psub._id, room: lec2._id, weekdays: MWF, startTime: '08:00' });
  check('valid assignment succeeds 201', r.status === 201, `HTTP ${r.status}`);
  d = await avail({ sectionKey: 'O:2', subject: psub._id, day: 'MWF', startTime: '08:00' });
  check('freshly-assigned room disappears from availability', !codes(d).includes('PT1-LEC2'), codes(d).join(','));

  // 13. Editing a schedule never conflicts with itself.
  r = await patch(s1._id, { weekdays: MWF, startTime: '10:00', room: lec1._id, instructor: null });
  check('edit keeping same slot succeeds (no self-conflict)', r.status === 200, `HTTP ${r.status}`);

  // 14. ...but an edit into an occupied slot is still rejected.
  r = await patch(s1._id, { weekdays: ['Tue', 'Thu'], startTime: '13:00', room: lec2._id, instructor: null });
  body = await r.json().catch(() => ({}));
  check('edit into occupied room/time rejected 409', r.status === 409, `HTTP ${r.status}`);

  // ---- teardown ------------------------------------------------------------
  srv.close();
  await mongoose.connection.dropDatabase();
  await mongoose.disconnect();

  const failed = results.filter(x => !x.pass);
  console.log(`\n${results.length - failed.length}/${results.length} checks passed.`);
  if (failed.length) {
    console.log('FAILED:');
    failed.forEach(f => console.log(` - ${f.name}`));
    process.exit(1);
  }
  process.exit(0);
})().catch(err => { console.error(err); process.exit(1); });