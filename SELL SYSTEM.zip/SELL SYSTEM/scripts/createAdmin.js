require('dotenv').config();
const readline = require('readline-sync');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const { validateEmail, validatePassword, required } = require('../utils/validation');
const { logActivity } = require('../services/logService');

(async () => {
  try {
    await connectDB();
    console.log('\nCreate the first or another Admin account. Admin registration is never public.\n');
    const username = required(readline.question('Admin username: '), 'Username', 50).toLowerCase();
    const email = validateEmail(readline.questionEMail('Admin email: '));
    const password = validatePassword(readline.question('Admin password: ', { hideEchoBack: true }));
    const confirm = readline.question('Confirm password: ', { hideEchoBack: true });
    if (password !== confirm) throw new Error('Password confirmation does not match.');
    if (await User.exists({ $or: [{ username }, { email }] })) throw new Error('Username or email is already in use.');
    const admin = await User.create({ role: 'Admin', username, email, passwordHash: await bcrypt.hash(password, 12), status: 'Active' });
    await logActivity({ performedBy: admin._id, category: 'Registration', action: 'Administrator account created', description: `Administrator account created: ${username}.` });
    console.log('\nAdmin account created successfully.\n');
  } catch (err) {
    console.error('\nCould not create admin:', err.message, '\n');
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
})();
