require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const { seedBaseData } = require('../services/seedService');

(async () => {
  try {
    await connectDB();
    const result = await seedBaseData();
    console.log('Base data is ready:', result);
  } catch (err) {
    console.error(err);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
})();
