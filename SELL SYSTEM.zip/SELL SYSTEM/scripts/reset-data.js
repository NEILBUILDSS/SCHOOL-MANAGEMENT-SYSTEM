require('dotenv').config();
const readline = require('readline-sync');
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const Student = require('../models/Student');
const Instructor = require('../models/Instructor');
const Enrollment = require('../models/Enrollment');
const Schedule = require('../models/Schedule');
const ClassRecord = require('../models/ClassRecord');
const SubjectOffering = require('../models/SubjectOffering');
const ActivityLog = require('../models/ActivityLog');
const Counter = require('../models/Counter');
const Semester = require('../models/Semester');
const Prospectus = require('../models/Prospectus');
const { seedBaseData } = require('../services/seedService');

(async () => {
  try {
    await connectDB();
    const admins = await User.countDocuments({ role: 'Admin' });
    if (!admins) throw new Error('No Admin account found. Run: npm.cmd run create-admin first.');

    console.log('\nThis will DELETE:');
    console.log('  students:', await Student.countDocuments());
    console.log('  instructors:', await Instructor.countDocuments());
    console.log('  student and instructor login accounts:', await User.countDocuments({ role: { $ne: 'Admin' } }));
    console.log('  enrollments:', await Enrollment.countDocuments());
    console.log('  class records:', await ClassRecord.countDocuments());
    console.log('  subject offerings:', await SubjectOffering.countDocuments());
    console.log('  schedules:', await Schedule.countDocuments(), '(sample schedules are re-created afterwards)');
    console.log('  activity logs:', await ActivityLog.countDocuments());
    console.log('\nKept: Admin accounts (' + admins + '), courses, subjects, rooms.\n');

    const answer = readline.question('Type RESET to continue (anything else cancels): ');
    if (answer !== 'RESET') { console.log('Cancelled. Nothing was deleted.'); return; }

    await Enrollment.deleteMany({});
    await ClassRecord.deleteMany({});
    await SubjectOffering.deleteMany({});
    await Schedule.deleteMany({});
    await Student.deleteMany({});
    await Instructor.deleteMany({});
    await User.deleteMany({ role: { $ne: 'Admin' } });
    await ActivityLog.deleteMany({});
    await Counter.deleteMany({});
    await Semester.deleteMany({});
    await Prospectus.deleteMany({});

    // Rebuild indexes so the new definitions (for example, optional studentId) take effect.
    for (const Model of [Student, Instructor, Enrollment, ClassRecord, SubjectOffering, Counter, Semester, Prospectus]) {
      await Model.syncIndexes();
    }

    const seeded = await seedBaseData();
    console.log('\nReset complete. Sample data reloaded:', seeded);
  } catch (err) {
    console.error('\nReset failed:', err.message, '\n');
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
})();