# Quick Start for Friends

Welcome! Here's the simplest way to get SELL SYSTEM running:

## Step 1: Install dependencies

Open PowerShell, navigate to the SELL SYSTEM folder, and run:

```powershell
# If npm install fails, run this instead:
powershell -ExecutionPolicy Bypass -Command "npm install"
```

## Step 2: Create .env file

```powershell
Copy-Item .env.example .env
```

Edit `.env` and change `SESSION_SECRET` to any 32+ character string (or just use the default for testing).

## Step 3: Start the server

```powershell
npm start
```

## Step 4: Login

Open http://localhost:3002 in your browser.

**Auto-created demo accounts:**

| Portal | Username | Password |
|--------|----------|----------|
| Admin | `admin` | `Admin@12345` |
| Student | `maria.santos` | `Student@12345` |
| Instructor | `daniel.cruz` | `Teacher@12345` |

## Troubleshooting

**If you see "running scripts is disabled":**
```powershell
powershell -ExecutionPolicy Bypass -Command "npm install"
```

**If node/npm commands aren't recognized:**
- Close and reopen VS Code (it picks up PATH changes)
- Or use absolute paths: `C:\Program Files\nodejs\node.exe`

**Browser login issues:**
- Clear browser cookies for localhost:3002
- Try an incognito/private window