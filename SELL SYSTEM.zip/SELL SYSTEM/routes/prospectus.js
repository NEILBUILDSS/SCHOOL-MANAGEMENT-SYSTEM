const express = require('express');
const mongoose = require('mongoose');
const Course = require('../models/Course');
const Subject = require('../models/Subject');
const Prospectus = require('../models/Prospectus');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { httpError } = require('../utils/validation');
const { logActivity } = require('../services/logService');

const router = express.Router();
router.use(requireAuth, requireRole('Admin'));

const isId = v => mongoose.Types.ObjectId.isValid(String(v || ''));

async function loadCourse(courseId) {
  if (!isId(courseId)) throw httpError(400, 'Choose a course.');
  const course = await Course.findById(courseId).lean();
  if (!course) throw httpError(404, 'Course not found.');
  return course;
}

// The prospectus of one course, plus the subjects that can still be added to it.
router.get('/', async (req, res, next) => {
  try {
    const course = await loadCourse(req.query.course);
    const p = await Prospectus.findOne({ course: course._id }).populate('items.subject', 'subjectCode subjectName units').lean();
    const items = ((p && p.items) || []).filter(i => i.subject).map(i => ({
      yearLevel: i.yearLevel,
      term: i.term,
      subject: { _id: i.subject._id, subjectCode: i.subject.subjectCode, subjectName: i.subject.subjectName, units: i.subject.units }
    }));
    const used = new Set(items.map(i => String(i.subject._id)));
    const subjects = await Subject.find({ course: course._id, status: 'Active' }).sort({ subjectCode: 1 }).lean();
    const available = subjects.filter(s => !used.has(String(s._id))).map(s => ({ _id: s._id, subjectCode: s.subjectCode, subjectName: s.subjectName, units: s.units }));
    res.json({ course: { _id: course._id, code: course.code, name: course.name }, items, available });
  } catch (err) { next(err); }
});

router.post('/:courseId/items', csrfProtect, async (req, res, next) => {
  try {
    const course = await loadCourse(req.params.courseId);
    const yearLevel = Number(req.body.yearLevel);
    if (![1, 2, 3, 4].includes(yearLevel)) throw httpError(400, 'Year level must be 1 to 4.');
    if (!Prospectus.TERMS.includes(req.body.term)) throw httpError(400, 'Choose a valid semester.');
    if (!isId(req.body.subjectId)) throw httpError(400, 'Choose a subject.');
    const subject = await Subject.findOne({ _id: req.body.subjectId, course: course._id, status: 'Active' }).lean();
    if (!subject) throw httpError(400, 'That subject does not belong to this course.');

    try {
      await Prospectus.updateOne({ course: course._id }, { $setOnInsert: { status: 'Active' } }, { upsert: true });
    } catch (err) { if (err.code !== 11000) throw err; }
    const result = await Prospectus.updateOne(
      { course: course._id, 'items.subject': { $ne: subject._id } },
      { $push: { items: { yearLevel, term: req.body.term, subject: subject._id } } }
    );
    if (!result.modifiedCount) throw httpError(409, 'That subject is already in this prospectus.');
    await logActivity({ performedBy: req.user._id, category: 'Prospectus', action: 'Subject added to prospectus', description: `${subject.subjectCode} added to ${course.code}, Year ${yearLevel}, ${req.body.term}.` });
    res.status(201).json({ message: `${subject.subjectCode} added to Year ${yearLevel}, ${req.body.term}.` });
  } catch (err) { next(err); }
});

router.delete('/:courseId/items/:subjectId', csrfProtect, async (req, res, next) => {
  try {
    const course = await loadCourse(req.params.courseId);
    if (!isId(req.params.subjectId)) throw httpError(400, 'Choose a subject.');
    const result = await Prospectus.updateOne({ course: course._id }, { $pull: { items: { subject: req.params.subjectId } } });
    if (!result.modifiedCount) throw httpError(404, 'That subject is not in this prospectus.');
    await logActivity({ performedBy: req.user._id, category: 'Prospectus', action: 'Subject removed from prospectus', description: `A subject was removed from the ${course.code} prospectus.` });
    res.json({ message: 'Subject removed from the prospectus.' });
  } catch (err) { next(err); }
});

module.exports = router;