const express = require('express');
const Enrollment = require('../models/Enrollment');
const Student = require('../models/Student');
const Schedule = require('../models/Schedule');
const Course = require('../models/Course');
const Semester = require('../models/Semester');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { httpError, escapeRegex } = require('../utils/validation');
const { logActivity, studentLabel } = require('../services/logService');
const { withSchedulingLock, validateEnrollment } = require('../services/schedulingService');
const { getCurrentSemester } = require('../services/semesterService');

const router = express.Router();
router.use(requireAuth, requireRole('Admin'));

function personName(person) {
  return person ? `${person.firstName || ''} ${person.lastName || ''}`.trim() : '';
}

// Admin enrollment register. Filters mirror the columns shown on the page so
// the server, not the browser, decides what is visible.
router.get('/', async (req, res, next) => {
  try {
    const filter = {};
    if (['Active', 'Inactive'].includes(String(req.query.status))) filter.status = req.query.status;
    if (/^[a-f\d]{24}$/i.test(String(req.query.semester || ''))) filter.semester = req.query.semester;

    if (req.query.course) {
      const course = await Course.findOne({ code: String(req.query.course).toUpperCase() }).lean();
      filter.student = { $in: course ? await Student.find({ course: course._id }).distinct('_id') : [] };
    }
    if (req.query.year && [1, 2, 3, 4].includes(Number(req.query.year))) {
      const ids = await Student.find({ yearLevel: Number(req.query.year) }).distinct('_id');
      filter.student = { $in: ids };
    }
    if (req.query.q) {
      const rx = new RegExp(escapeRegex(String(req.query.q).trim()), 'i');
      const students = await Student.find({ $or: [{ studentId: rx }, { firstName: rx }, { lastName: rx }] }).distinct('_id');
      filter.student = { $in: students };
    }

    const rows = await Enrollment.find(filter)
      .populate({ path: 'student', populate: [{ path: 'course', select: 'code' }, { path: 'user', select: 'status' }] })
      .populate('subject', 'subjectCode subjectName units')
      .populate({ path: 'schedule', populate: [{ path: 'room', select: 'roomCode' }, { path: 'instructor', select: 'firstName lastName' }] })
      .populate('semester', 'academicYear term')
      .sort({ updatedAt: -1 })
      .limit(500)
      .lean();

    res.json(rows.map(row => ({
      _id: row._id,
      student: {
        _id: row.student?._id,
        studentId: row.student?.studentId,
        name: personName(row.student),
        course: row.student?.course?.code || '',
        yearLevel: row.student?.yearLevel
      },
      subject: row.subject,
      schedule: row.schedule ? {
        _id: row.schedule._id,
        room: row.schedule.room?.roomCode || '',
        instructor: personName(row.schedule.instructor) || 'TBA',
        weekdays: row.schedule.weekdays,
        startTime: row.schedule.startTime,
        endTime: row.schedule.endTime
      } : null,
      semester: row.semester ? `${row.semester.academicYear} ${row.semester.term}` : '—',
      status: row.status,
      result: row.result,
      createdAt: row.createdAt
    })));
  } catch (err) { next(err); }
});

router.get('/options/:studentId', async (req, res, next) => {
  try {
    const student = await Student.findById(req.params.studentId).lean();
    if (!student) throw httpError(404, 'Student not found.');
    const semester = await getCurrentSemester();
    const periodFilter = semester
      ? { $or: [{ semester: semester._id }, { semester: null }, { semester: { $exists: false } }] }
      : {};
    const schedules = await Schedule.find({
      course: student.course,
      yearLevel: student.yearLevel,
      status: 'Active',
      ...periodFilter
    })
      .populate('subject room course')
      .populate({ path: 'instructor', select: 'firstName lastName' })
      .sort({ startTime: 1 })
      .lean();
    res.json(schedules);
  } catch (err) { next(err); }
});

router.post('/', csrfProtect, async (req, res, next) => {
  try {
    const enrollment = await withSchedulingLock(async () => {
      const semester = await getCurrentSemester();
      if (!semester) throw httpError(409, 'No current semester is available. Please try again.');
      const { student, schedule } = await validateEnrollment({
        studentId: req.body.studentId,
        scheduleId: req.body.scheduleId,
        semesterId: semester._id
      });
      return Enrollment.create({
        student: student._id,
        schedule: schedule._id,
        subject: schedule.subject._id,
        semester: semester._id,
        result: 'Enrolled',
        status: 'Active'
      });
    });
    await logActivity({
      performedBy: req.user._id,
      category: 'Enrollment',
      action: 'Enrollment created',
      description: `Created enrollment for ${await studentLabel(enrollment.student)}.`
    });
    res.status(201).json({ message: 'Enrollment created.', enrollment });
  } catch (err) {
    if (err.code === 11000) return next(httpError(409, 'That student already has an active enrollment in this subject.'));
    next(err);
  }
});

router.patch('/:id', csrfProtect, async (req, res, next) => {
  try {
    const enrollment = await withSchedulingLock(async () => {
      const current = await Enrollment.findById(req.params.id);
      if (!current) throw httpError(404, 'Enrollment not found.');
      const semester = await getCurrentSemester();
      if (!semester || String(current.semester) !== String(semester._id)) {
        throw httpError(409, 'Enrollments from an earlier semester are academic history and cannot be changed.');
      }
      if (['Passed', 'Failed', 'Incomplete'].includes(current.result)) {
        throw httpError(409, 'This enrollment already has a result and cannot be changed.');
      }
      const nextStatus = req.body.status;
      if (!['Active', 'Inactive'].includes(nextStatus)) throw httpError(400, 'Status must be Active or Inactive.');
      if (nextStatus === 'Active') {
        await validateEnrollment({
          studentId: current.student,
          scheduleId: current.schedule,
          semesterId: current.semester,
          excludeEnrollmentId: current._id
        });
      }
      current.status = nextStatus;
      current.result = nextStatus === 'Active' ? 'Enrolled' : 'Dropped';
      await current.save();
      return current;
    });
    await logActivity({
      performedBy: req.user._id,
      category: 'Enrollment',
      action: 'Enrollment status updated',
      description: `Enrollment for ${await studentLabel(enrollment.student)} set to ${enrollment.status}.`
    });
    res.json({ message: 'Enrollment updated successfully.' });
  } catch (err) { next(err); }
});

module.exports = router;
