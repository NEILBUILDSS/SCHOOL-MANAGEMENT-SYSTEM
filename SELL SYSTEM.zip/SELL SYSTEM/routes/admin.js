const express = require('express');
const Student = require('../models/Student');
const Instructor = require('../models/Instructor');
const Subject = require('../models/Subject');
const Schedule = require('../models/Schedule');
const Room = require('../models/Room');
const Enrollment = require('../models/Enrollment');
const ActivityLog = require('../models/ActivityLog');
const { requireAuth, requireRole } = require('../middleware/auth');
const { getCurrentSemester } = require('../services/semesterService');
const { escapeRegex } = require('../utils/validation');

const router = express.Router();
router.use(requireAuth, requireRole('Admin'));

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const LABELS = { Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday' };

function personName(person) {
  return person ? `${person.firstName || ''} ${person.lastName || ''}`.trim() : 'TBA';
}

function minutes(value) {
  const [h, m] = String(value || '0:0').split(':').map(Number);
  return h * 60 + m;
}

function time12(value) {
  const [h, m] = String(value || '0:0').split(':').map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
}

function scheduleLabel(schedule) {
  const subject = schedule.subject;
  const room = schedule.room;
  return {
    _id: schedule._id,
    subject: subject ? `${subject.subjectCode} - ${subject.subjectName}` : '—',
    subjectCode: subject ? subject.subjectCode : '',
    instructor: personName(schedule.instructor),
    room: room ? room.roomCode : '—',
    days: (schedule.weekdays || []).join(', '),
    time: `${time12(schedule.startTime)} - ${time12(schedule.endTime)}`,
    course: schedule.course ? schedule.course.code : '—',
    yearLevel: schedule.yearLevel,
    status: schedule.status
  };
}

router.get('/dashboard', async (req, res, next) => {
  try {
    const current = await getCurrentSemester();
    const semesterFilter = current ? { $or: [{ semester: current._id }, { semester: null }] } : {};

    const [students, instructors, subjects, activeSchedules, rooms, schedules, recentStudents, recentInstructors, recentActivity, enrollmentCount] = await Promise.all([
      Student.countDocuments(),
      Instructor.countDocuments(),
      Subject.countDocuments({ status: 'Active' }),
      Schedule.countDocuments({ status: 'Active', ...semesterFilter }),
      Room.find().select('roomCode roomType capacity status').lean(),
      Schedule.find({ status: 'Active', ...semesterFilter })
        .populate('subject', 'subjectCode subjectName')
        .populate('room', 'roomCode')
        .populate('course', 'code')
        .populate({ path: 'instructor', select: 'firstName lastName' })
        .sort({ startTime: 1 })
        .lean(),
      Student.find().populate('course', 'code').sort({ createdAt: -1 }).limit(5).lean(),
      Instructor.find().sort({ createdAt: -1 }).limit(5).lean(),
      ActivityLog.find().sort({ createdAt: -1 }).limit(6).lean(),
      Enrollment.countDocuments(current ? { status: 'Active', semester: current._id } : { status: 'Active' })
    ]);

    const today = DAYS[new Date().getDay()];
    const nowMinutes = new Date().getHours() * 60 + new Date().getMinutes();
    const todaysClasses = schedules.filter(s => (s.weekdays || []).includes(today));
    const nextClass = todaysClasses
      .filter(s => minutes(s.startTime) >= nowMinutes)
      .sort((a, b) => minutes(a.startTime) - minutes(b.startTime))[0] || null;

    const weekLoad = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => ({
      day,
      label: LABELS[day],
      count: schedules.filter(s => (s.weekdays || []).includes(day)).length
    }));

    // Instructor workload: active class hours per week (start/end spans counted
    // once per distinct class day).
    const workload = new Map();
    for (const schedule of schedules) {
      if (!schedule.instructor) continue;
      const key = String(schedule.instructor._id);
      const hours = ((minutes(schedule.endTime) - minutes(schedule.startTime)) / 60) * (schedule.weekdays || []).length;
      const row = workload.get(key) || { name: personName(schedule.instructor), hours: 0, classes: 0 };
      row.hours += hours;
      row.classes += 1;
      workload.set(key, row);
    }
    const topInstructors = [...workload.values()].sort((a, b) => b.hours - a.hours).slice(0, 3);
    const maxHours = topInstructors.length ? Math.max(...topInstructors.map(i => i.hours), 1) : 1;

    const activeRoomIds = new Set(schedules.map(s => String(s.room?._id || s.room)));
    const roomMix = {
      lecture: rooms.filter(r => r.roomType === 'Non-Laboratory').length,
      laboratory: rooms.filter(r => r.roomType === 'Laboratory').length,
      inactive: rooms.filter(r => r.status === 'Inactive').length,
      inUse: activeRoomIds.size,
      total: rooms.length
    };

    // Scheduled minutes per room type today (for the donut "room usage" panel).
    let usedMinutes = 0;
    for (const s of todaysClasses) usedMinutes += minutes(s.endTime) - minutes(s.startTime);

    res.json({
      totals: { students, instructors, subjects, activeSchedules, enrollments: enrollmentCount, rooms: rooms.length },
      today: {
        day: LABELS[today],
        classes: todaysClasses.length,
        roomsInUse: activeRoomIds.size,
        usedHours: Math.round((usedMinutes / 60) * 10) / 10,
        nextClass: nextClass ? scheduleLabel(nextClass) : null
      },
      weekLoad,
      roomMix,
      topInstructors: topInstructors.map(i => ({
        name: i.name,
        initials: i.name.split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase(),
        hours: Math.round(i.hours * 10) / 10,
        classes: i.classes,
        percent: Math.round((i.hours / maxHours) * 100)
      })),
      scheduleUpdates: schedules.slice(0, 8).map(scheduleLabel),
      recentRegistrations: [
        ...recentStudents.map(x => ({ kind: 'Student', name: personName(x), detail: x.course ? x.course.code : '', createdAt: x.createdAt })),
        ...recentInstructors.map(x => ({ kind: 'Instructor', name: personName(x), detail: x.department || '', createdAt: x.createdAt }))
      ].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 6),
      recentActivity,
      currentSemester: current ? { _id: current._id, label: `${current.academicYear} ${current.term}`, startDate: current.startDate, endDate: current.endDate } : null
    });
  } catch (err) { next(err); }
});

// Global search used by the top bar. Returns compact results the client can
// turn into router links; it never exposes more than a label and an id.
router.get('/search', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    if (q.length < 2) return res.json({ results: [] });
    const rx = new RegExp(escapeRegex(q), 'i');
    const [students, instructors, subjects, rooms] = await Promise.all([
      Student.find({ $or: [{ studentId: rx }, { firstName: rx }, { lastName: rx }] }).limit(4).lean(),
      Instructor.find({ $or: [{ instructorId: rx }, { firstName: rx }, { lastName: rx }] }).limit(3).lean(),
      Subject.find({ $or: [{ subjectCode: rx }, { subjectName: rx }] }).limit(3).lean(),
      Room.find({ $or: [{ roomCode: rx }, { roomName: rx }] }).limit(3).lean()
    ]);
    const results = [
      ...students.map(s => ({ type: 'Student', label: `${s.studentId} — ${personName(s)}`, route: `student/${s._id}` })),
      ...instructors.map(i => ({ type: 'Instructor', label: `${i.instructorId} — ${personName(i)}`, route: `instructor/${i._id}` })),
      ...subjects.map(s => ({ type: 'Subject', label: `${s.subjectCode} — ${s.subjectName}`, route: `subject/${s._id}` })),
      ...rooms.map(r => ({ type: 'Room', label: `${r.roomCode} — ${r.roomName}`, route: `room/${r._id}` }))
    ];
    res.json({ results });
  } catch (err) { next(err); }
});

module.exports = router;
