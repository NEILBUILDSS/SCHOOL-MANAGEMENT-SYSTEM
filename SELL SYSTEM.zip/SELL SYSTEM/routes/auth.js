const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Student = require('../models/Student');
const Instructor = require('../models/Instructor');
const { requireAuth, csrfProtect, ensureCsrfToken } = require('../middleware/auth');
const { required, httpError } = require('../utils/validation');

const router = express.Router();

router.get('/csrf', (req, res) => {
  res.json({ csrfToken: ensureCsrfToken(req) });
});

router.post('/login', csrfProtect, async (req, res, next) => {
  try {
    const login = required(req.body.login, 'Email or username', 254).toLowerCase();
    const password = String(req.body.password || '');
    const user = await User.findOne({ $or: [{ email: login }, { username: login }] });
    if (!user || user.status !== 'Active' || !(await bcrypt.compare(password, user.passwordHash))) {
      throw httpError(401, 'Invalid email/username or password.');
    }
    req.session.regenerate(async err => {
      if (err) return next(err);
      req.session.userId = user._id.toString();
      req.session.role = user.role;

      const rememberMe =
        req.body.rememberMe === true ||
        req.body.rememberMe === 'true';

      req.session.cookie.maxAge =
        rememberMe
          ? 30 * 24 * 60 * 60 * 1000
          : 2 * 60 * 60 * 1000;

      const token = ensureCsrfToken(req);
      user.lastLoginAt = new Date();
      await user.save();
      res.json({ message: 'Login successful.', role: user.role, csrfToken: token });
    });
  } catch (err) {
    next(err);
  }
});

router.get('/me', requireAuth, async (req, res, next) => {
  try {
    let profile = null;
    if (req.user.role === 'Student') profile = await Student.findOne({ user: req.user._id }).populate('course').lean();
    if (req.user.role === 'Instructor') profile = await Instructor.findOne({ user: req.user._id }).lean();
    res.json({
      user: { id: req.user._id, username: req.user.username, email: req.user.email, role: req.user.role, status: req.user.status },
      profile,
      csrfToken: ensureCsrfToken(req)
    });
  } catch (err) { next(err); }
});

router.post('/logout', requireAuth, csrfProtect, (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie('sell.sid');
    res.json({ message: 'Logged out.' });
  });
});

module.exports = router;
