const express = require('express');
const Setting = require('../models/Setting');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { clean, httpError } = require('../utils/validation');
const { getSettings, saveSettings } = require('../services/settingsService');
const { logActivity } = require('../services/logService');

// Scheduling settings. Anyone who can plot a schedule must be able to read
// the rules the server is enforcing, but only an Admin may change them.
const router = express.Router();
router.use(requireAuth);

const TIME_RE = /^(?:[01]\d|2[0-3]):[0-5]\d$/;

// Booleans arrive from a form as 'true'/'false' strings, so accept both.
function asBoolean(value, label) {
  if (value === true || value === 'true') return true;
  if (value === false || value === 'false') return false;
  throw httpError(400, `${label} must be true or false.`);
}

function asNumber(value, label, { min, max }) {
  const n = Number(value);
  if (!Number.isFinite(n)) throw httpError(400, `${label} must be a number.`);
  if (!Number.isInteger(n) || n < min || n > max) {
    throw httpError(400, `${label} must be a whole number between ${min} and ${max}.`);
  }
  return n;
}

function asTime(value, label) {
  const v = clean(value, 5);
  if (!TIME_RE.test(v)) throw httpError(400, `${label} must use 24-hour HH:MM format.`);
  return v;
}

// Breaks and session rules arrive as JSON arrays from the settings page.
function asArray(value, label) {
  if (value === undefined || value === null || value === '') return undefined;
  if (Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(String(value));
    if (Array.isArray(parsed)) return parsed;
  } catch (err) { /* fall through to the error below */ }
  throw httpError(400, `${label} must be a list.`);
}

// Only the fields this route manages are read from the body, so an unknown
// key can never be smuggled into the settings document.
function pickUpdate(body) {
  const update = {};
  if (body.dayStart !== undefined) update.dayStart = asTime(body.dayStart, 'Day start');
  if (body.dayEnd !== undefined) update.dayEnd = asTime(body.dayEnd, 'Day end');
  if (body.breaksEnabled !== undefined) update.breaksEnabled = asBoolean(body.breaksEnabled, 'Breaks enabled');
  if (body.dailyTargetHours !== undefined) update.dailyTargetHours = asNumber(body.dailyTargetHours, 'Daily target hours', { min: 1, max: 24 });
  if (body.sectionCapacity !== undefined) update.sectionCapacity = asNumber(body.sectionCapacity, 'Section capacity', { min: 1, max: 10 });
  if (body.activeRoomLimit !== undefined) update.activeRoomLimit = asNumber(body.activeRoomLimit, 'Active room limit', { min: 0, max: 500 });
  if (body.enforcePatternDuration !== undefined) update.enforcePatternDuration = asBoolean(body.enforcePatternDuration, 'Enforce pattern duration');

  const breaks = asArray(body.breaks, 'Breaks');
  if (breaks !== undefined) {
    update.breaks = breaks.map((b, i) => {
      if (!b || typeof b !== 'object') throw httpError(400, `Break ${i + 1} is not a valid break.`);
      return {
        label: clean(b.label, 60) || `Break ${i + 1}`,
        startTime: asTime(b.startTime, `Break ${i + 1} start`),
        endTime: asTime(b.endTime, `Break ${i + 1} end`)
      };
    });
  }

  const rules = asArray(body.sessionRules, 'Session rules');
  if (rules !== undefined) {
    update.sessionRules = rules.map((r, i) => {
      if (!r || typeof r !== 'object') throw httpError(400, `Session rule ${i + 1} is not valid.`);
      const pattern = clean(r.pattern, 20);
      if (!Setting.PATTERN_KEYS.includes(pattern)) {
        throw httpError(400, `Session rule ${i + 1} uses an unknown day pattern.`);
      }
      return { pattern, minutes: asNumber(r.minutes, `${pattern} session length`, { min: 30, max: 360 }) };
    });
  }
  return update;
}

router.get('/', requireRole('Admin'), async (req, res, next) => {
  try {
    res.json({ settings: await getSettings() });
  } catch (err) { next(err); }
});

router.patch('/', requireRole('Admin'), csrfProtect, async (req, res, next) => {
  try {
    const update = pickUpdate(req.body || {});
    if (!Object.keys(update).length) throw httpError(400, 'No settings were submitted.');
    // The model validates ordering, overlap and duplicate patterns, so an
    // invalid combination is refused before anything is written.
    const settings = await saveSettings(update);

    const described = Object.keys(update).join(', ');
    await logActivity({
      performedBy: req.user._id,
      category: 'Scheduling',
      action: 'Scheduling settings updated',
      description: `Updated scheduling settings: ${described}.`
    });
    res.json({ message: 'Scheduling settings saved.', settings });
  } catch (err) { next(err); }
});

module.exports = router;
