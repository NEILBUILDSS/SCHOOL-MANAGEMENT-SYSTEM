const express = require('express');
const Subject = require('../models/Subject');
const Schedule = require('../models/Schedule');
const Course = require('../models/Course');
const Prospectus = require('../models/Prospectus');
const Semester = require('../models/Semester');
const mongoose = require('mongoose');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { required, clean, httpError, escapeRegex } = require('../utils/validation');
const { logActivity } = require('../services/logService');
const { getCurrentSemester } = require('../services/semesterService');

const router = express.Router();
router.use(requireAuth);

async function validatePrerequisites(ids, courseId, subjectId = null) {
  if (!Array.isArray(ids)) throw httpError(400, 'Prerequisites must be submitted as a list.');
  const values = ids.map(String);
  if (new Set(values).size !== values.length) throw httpError(400, 'A prerequisite can only be selected once.');
  if (values.some(value => !mongoose.Types.ObjectId.isValid(value) || value === String(subjectId))) {
    throw httpError(400, 'Choose valid prerequisite subjects other than this subject.');
  }
  const prerequisites = await Subject.find({ _id: { $in: values }, course: courseId }).select('_id prerequisites').lean();
  if (prerequisites.length !== values.length) throw httpError(400, 'Prerequisite subjects must belong to the same course.');

  const visited = new Set();
  const reachesSubject = async id => {
    if (String(id) === String(subjectId)) return true;
    if (visited.has(String(id))) return false;
    visited.add(String(id));
    const item = await Subject.findById(id).select('prerequisites').lean();
    for (const prerequisiteId of item?.prerequisites || []) {
      if (await reachesSubject(prerequisiteId)) return true;
    }
    return false;
  };
  if (subjectId) {
    for (const prerequisite of prerequisites) {
      if (await reachesSubject(prerequisite._id)) throw httpError(400, 'Prerequisite relationships cannot contain a cycle.');
    }
  }
  return prerequisites.map(item => item._id);
}

// Co-requisites are validated the same way as prerequisites (same course, no self-reference,
// no duplicates) but deliberately WITHOUT the cycle check: a mutual co-requisite pair such as
// IT 1017 <-> IT 1019 is legal and must not be rejected.
async function validateCoRequisites(ids, courseId, subjectId = null) {
  if (!Array.isArray(ids)) throw httpError(400, 'Co-requisites must be submitted as a list.');
  const values = ids.map(String);
  if (new Set(values).size !== values.length) throw httpError(400, 'A co-requisite can only be selected once.');
  if (values.some(value => !mongoose.Types.ObjectId.isValid(value) || value === String(subjectId))) {
    throw httpError(400, 'Choose valid co-requisite subjects other than this subject.');
  }
  const coRequisites = await Subject.find({ _id: { $in: values }, course: courseId }).select('_id').lean();
  if (coRequisites.length !== values.length) throw httpError(400, 'Co-requisite subjects must belong to the same course.');
  return coRequisites.map(item => item._id);
}

const SUBJECT_TERMS = Semester.schema.path('term').enumValues;
const AVAILABILITY = ['all', 'open', 'not_open'];

// This project stores a school year as the academicYear string on Semester
// documents (there is no separate SchoolYear collection). Resolving the pair
// this way keeps the Subjects page and the Schedules page on the same term.
async function resolveSubjectTerm(schoolYearId, semester) {
  const current = await getCurrentSemester();
  const year = String(schoolYearId || '').trim();
  const term = String(semester || '').trim();

  if (year && !/^\d{4}-\d{4}$/.test(year)) throw httpError(400, 'Choose a valid school year.');
  if (term && !SUBJECT_TERMS.includes(term)) throw httpError(400, 'Choose a valid semester.');

  if (year && term) {
    const exact = await Semester.findOne({ academicYear: year, term }).lean();
    if (!exact) throw httpError(404, 'Selected school year and semester was not found.');
    return exact;
  }

  if (year) {
    // "All semesters" still needs a term for the plotted count. Use the same
    // term name as the current period, then fall back to the year's first term.
    const sameTerm = current ? await Semester.findOne({ academicYear: year, term: current.term }).lean() : null;
    if (sameTerm) return sameTerm;
    const firstTerm = await Semester.findOne({ academicYear: year }).sort({ startDate: 1 }).lean();
    if (firstTerm) return firstTerm;
    throw httpError(404, 'That school year has no terms yet.');
  }

  if (term && current) {
    const found = await Semester.findOne({ academicYear: current.academicYear, term }).lean();
    if (found) return found;
  }

  return current;
}

router.get('/', requireRole('Admin'), async (req,res,next)=>{ try {
  const filter={};
  if(req.query.status && ['Active','Inactive'].includes(req.query.status)) filter.status=req.query.status;
  if(req.query.course){ const c=await Course.findOne({code:String(req.query.course).toUpperCase()}); filter.course=c?c._id:null; }
  if(req.query.q){ const rx=new RegExp(escapeRegex(req.query.q),'i'); filter.$or=[{subjectCode:rx},{subjectName:rx}]; }
  const availability=AVAILABILITY.includes(String(req.query.availability||''))?String(req.query.availability):'all';
  const term=await resolveSubjectTerm(req.query.schoolYearId,req.query.semester);
  const subjects=await Subject.find(filter).populate('course').populate('prerequisites', 'subjectCode subjectName').populate('coRequisites', 'subjectCode subjectName').sort({subjectCode:1}).lean();
  const ids=subjects.map(s=>s._id);
  const [counts,prospectuses]=await Promise.all([
    term
      ? Schedule.aggregate([{ $match:{subject:{$in:ids},semester:term._id} },{ $group:{_id:'$subject',count:{$sum:1}} }])
      : Promise.resolve([]),
    Prospectus.find({'items.subject':{$in:ids}}).select('items').lean()
  ]);
  const plotted=Object.fromEntries(counts.map(x=>[String(x._id),x.count]));
  const placements=new Map();
  for(const prospectus of prospectuses) for(const item of prospectus.items) placements.set(String(item.subject),{yearLevel:item.yearLevel,term:item.term});
  let rows=subjects.map(s=>({...s,...placements.get(String(s._id)),plottedSections:plotted[String(s._id)]||0}));
  if(availability==='open') rows=rows.filter(s=>s.plottedSections>0);
  if(availability==='not_open') rows=rows.filter(s=>s.plottedSections===0);
  res.json(rows);
} catch(e){next(e);} });

router.post('/', requireRole('Admin'), csrfProtect, async (req,res,next)=>{ try {
  const course=await Course.findOne({code:required(req.body.course,'Course',10).toUpperCase(),status:'Active'});
  if(!course) throw httpError(400,'Select a valid course.');
  const prerequisites=await validatePrerequisites(req.body.prerequisiteIds || [],course._id);
  const coRequisites=await validateCoRequisites(req.body.coRequisiteIds || [],course._id);
  const yearLevel=req.body.yearLevel===undefined||req.body.yearLevel===''?null:Number(req.body.yearLevel);
  const term=req.body.term||'';
  if((yearLevel===null)!==(!term)) throw httpError(400,'Year level and semester must be provided together.');
  if(yearLevel!==null&&![1,2,3,4].includes(yearLevel)) throw httpError(400,'Year level must be 1 to 4.');
  if(term&&!Prospectus.TERMS.includes(term)) throw httpError(400,'Choose a valid semester.');
  const subject=await Subject.create({
    subjectCode:required(req.body.subjectCode,'Subject code',30).toUpperCase(),
    subjectName:required(req.body.subjectName,'Subject name',150),
    description:clean(req.body.description,1000), course:course._id, prerequisites, coRequisites,
    units:Number(req.body.units), laboratoryRequired:req.body.laboratoryRequired===true||req.body.laboratoryRequired==='true', status:req.body.status==='Inactive'?'Inactive':'Active'
  });
  if(yearLevel!==null){
    try{
      await Prospectus.findOneAndUpdate(
        {course:course._id},
        {$push:{items:{yearLevel,term,subject:subject._id}}},
        {upsert:true,new:true,setDefaultsOnInsert:true,runValidators:true}
      );
    }catch(error){
      await Subject.deleteOne({_id:subject._id});
      if(error.code===11000) throw httpError(409,'This subject is already assigned in the course prospectus.');
      throw error;
    }
  }
  await logActivity({performedBy:req.user._id,category:'Subject',action:'Subject created',description:`Created subject ${subject.subjectCode}.`});
  res.status(201).json(subject);
} catch(e){if(e.code===11000)return next(httpError(409,'Subject code already exists.'));next(e);} });

router.get('/:id', async (req,res,next)=>{ try {
  const subject=await Subject.findById(req.params.id).populate('course').populate('prerequisites', 'subjectCode subjectName').populate('coRequisites', 'subjectCode subjectName').lean(); if(!subject) throw httpError(404,'Subject not found.');
  const schedules=await Schedule.find({subject:subject._id}).populate({path:'instructor',populate:{path:'user',select:'email username'}}).populate('room course').sort({startTime:1}).lean();
  res.json({subject,schedules});
} catch(e){next(e);} });

router.patch('/:id', requireRole('Admin'), csrfProtect, async (req,res,next)=>{ try {
  const subject=await Subject.findById(req.params.id); if(!subject) throw httpError(404,'Subject not found.'); const old=subject.subjectCode;
  if(req.body.subjectCode!==undefined) subject.subjectCode=required(req.body.subjectCode,'Subject code',30).toUpperCase();
  if(req.body.subjectName!==undefined) subject.subjectName=required(req.body.subjectName,'Subject name',150);
  if(req.body.description!==undefined) subject.description=clean(req.body.description,1000);
  if(req.body.units!==undefined){ const u=Number(req.body.units); if(!Number.isInteger(u)||u<1||u>6) throw httpError(400,'Units must be 1 to 6.'); subject.units=u; }
  if(req.body.laboratoryRequired!==undefined) {
    const nextLab=req.body.laboratoryRequired===true||req.body.laboratoryRequired==='true';
    if(nextLab && !subject.laboratoryRequired){
      const existing=await Schedule.find({subject:subject._id}).populate('room').lean();
      if(existing.some(x=>x.room?.roomType!=='Laboratory')) throw httpError(409,'Move all schedule options for this subject to laboratory rooms before requiring a laboratory.');
    }
    subject.laboratoryRequired=nextLab;
  }
  if(req.body.course!==undefined){ const c=await Course.findOne({code:String(req.body.course).toUpperCase(),status:'Active'}); if(!c) throw httpError(400,'Select a valid course.'); if(await Schedule.exists({subject:subject._id})) throw httpError(409,'Course cannot be changed while schedule options exist for this subject.'); subject.course=c._id; }
  if(req.body.prerequisiteIds!==undefined) subject.prerequisites=await validatePrerequisites(req.body.prerequisiteIds,subject.course,subject._id);
  if(req.body.coRequisiteIds!==undefined) subject.coRequisites=await validateCoRequisites(req.body.coRequisiteIds,subject.course,subject._id);
  if(req.body.status!==undefined){ if(!['Active','Inactive'].includes(req.body.status)) throw httpError(400,'Invalid status.'); if(req.body.status==='Inactive'&&await Schedule.exists({subject:subject._id,status:'Active'})) throw httpError(409,'Set active schedules for this subject to Inactive before deactivating the subject.'); subject.status=req.body.status; }
  await subject.save(); await logActivity({performedBy:req.user._id,category:'Subject',action:'Subject updated',description:`Updated subject ${old}.`}); res.json({message:'Subject updated successfully.'});
} catch(e){next(e);} });
module.exports=router;
