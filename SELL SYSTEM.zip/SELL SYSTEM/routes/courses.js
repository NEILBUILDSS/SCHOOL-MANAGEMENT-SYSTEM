const express=require('express');
const Course=require('../models/Course');
const Student=require('../models/Student');
const Subject=require('../models/Subject');
const Schedule=require('../models/Schedule');
const {requireAuth,requireRole,csrfProtect}=require('../middleware/auth');
const {required,clean,httpError}=require('../utils/validation');
const {logActivity}=require('../services/logService');
// Fixed dropdown vocabularies for the Add Course form; keep in sync with the
// options rendered in public/js/app.js (renderAddCourse).
const DEPARTMENTS=['College of Information Technology','College of Education','College of Business Administration'];
const DEGREE_LEVELS=["Bachelor's Degree",'Associate Degree',"Master's Degree",'Doctorate'];
const router=express.Router();router.use(requireAuth);

router.get('/', requireRole('Admin'), async(req,res,next)=>{try{const courses=await Course.find().sort({code:1}).lean();const result=[];for(const c of courses){result.push({...c,courseCode:c.code,courseName:c.name,studentCount:await Student.countDocuments({course:c._id}),subjectCount:await Subject.countDocuments({course:c._id})});}res.json(result);}catch(e){next(e);}});
// courseCode/courseName are accepted spellings (and echoed back); they are
// stored as code/name so the record stays selectable everywhere courses are
// referenced. Duplicate codes answer 409 via the unique index.
router.post('/', requireRole('Admin'),csrfProtect,async(req,res,next)=>{try{
  const code=required(req.body.courseCode??req.body.code,'Course code',10).toUpperCase();
  const name=required(req.body.courseName??req.body.name,'Course name',160);
  const department=required(req.body.department,'Department / college',80);
  if(!DEPARTMENTS.includes(department))throw httpError(400,'Choose a valid department / college.');
  const degreeLevel=required(req.body.degreeLevel,'Degree level',40);
  if(!DEGREE_LEVELS.includes(degreeLevel))throw httpError(400,'Choose a valid degree level.');
  const duration=required(req.body.duration,'Program duration',40);
  const years=Number(req.body.years);
  if(!Number.isInteger(years)||years<1||years>10)throw httpError(400,'Number of years must be a whole number between 1 and 10.');
  let totalUnits=null;
  if(req.body.totalUnits!==undefined&&req.body.totalUnits!==null&&req.body.totalUnits!==''){
    totalUnits=Number(req.body.totalUnits);
    if(!Number.isInteger(totalUnits)||totalUnits<1||totalUnits>1000)throw httpError(400,'Total required units must be a whole number of at least 1.');
  }
  const course=await Course.create({
    code,name,department,degreeLevel,duration,years,totalUnits,
    description:clean(req.body.description,1000),
    abbreviation:clean(req.body.abbreviation,20),
    curriculumYear:clean(req.body.curriculumYear,40),
    major:clean(req.body.major,80),
    status:req.body.status==='Inactive'?'Inactive':'Active'
  });
  await logActivity({performedBy:req.user._id,category:'Course',action:'Course created',description:`Created course ${code}.`});
  const plain=course.toObject();
  res.status(201).json({message:'Course created successfully.',course:{...plain,courseCode:plain.code,courseName:plain.name}});
}catch(e){if(e.code===11000)return next(httpError(409,'A course with this code already exists.'));next(e);}});
router.get('/:id', requireRole('Admin'),async(req,res,next)=>{try{
  const course=await Course.findById(req.params.id).lean();
  if(!course)throw httpError(404,'Course not found.');
  const subjects=await Subject.find({course:course._id}).sort({subjectCode:1}).lean();
  const [studentCount,instructorIds]=await Promise.all([
    Student.countDocuments({course:course._id,status:'Active'}),
    Schedule.distinct('instructor',{course:course._id,status:'Active',instructor:{$ne:null}})
  ]);
  const curriculumUnits=subjects.reduce((total,subject)=>total+(Number(subject.units)||0),0);
  res.json({
    course:{...course,courseCode:course.code,courseName:course.name},
    subjects,
    studentCount,
    subjectCount:subjects.length,
    instructorCount:instructorIds.length,
    curriculumUnits
  });
}catch(e){next(e);}});
router.patch('/:id', requireRole('Admin'),csrfProtect,async(req,res,next)=>{try{
  const c=await Course.findById(req.params.id);
  if(!c)throw httpError(404,'Course not found.');
  const old=c.code;
  if(req.body.name!==undefined)c.name=required(req.body.name,'Course name',160);
  if(req.body.description!==undefined)c.description=clean(req.body.description,1000);
  if(req.body.status!==undefined){
    if(!['Active','Inactive'].includes(req.body.status))throw httpError(400,'Invalid status.');
    if(req.body.status==='Inactive'&&(await Student.exists({course:c._id,status:'Active'})||await Subject.exists({course:c._id,status:'Active'})))throw httpError(409,'This course still has active students or subjects.');
    c.status=req.body.status;
  }
  await c.save();
  await logActivity({performedBy:req.user._id,category:'Course',action:'Course updated',description:`Updated course ${old}.`});
  res.json({message:'Course updated successfully.'});
}catch(e){next(e);}});
module.exports=router;
