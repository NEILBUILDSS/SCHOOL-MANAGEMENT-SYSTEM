const express = require('express');
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const multer = require('multer');
const Room = require('../models/Room');
const Schedule = require('../models/Schedule');
const { getCurrentSemester } = require('../services/semesterService');
// rooms.js already declares its own time12() helper below with the same
// signature, so only the settings helpers are imported here.
const { getSettings, toMinutes, minutesToHHMM, patternKeyFor, sessionMinutesFor } = require('../services/settingsService');
const Instructor = require('../models/Instructor');
const Subject = require('../models/Subject');
const Course = require('../models/Course');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { required, clean, httpError, escapeRegex } = require('../utils/validation');
const { logActivity } = require('../services/logService');
const { sumMergedMinutes, dailyLimitMinutesFrom, evaluateRoomTimeWindow } = require('../services/schedulingService');

const router=express.Router();
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024,files:1}});
router.use(requireAuth,requireRole('Admin'));

const DAY_ORDER=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const DAY_NAMES={Mon:'Monday',Tue:'Tuesday',Wed:'Wednesday',Thu:'Thursday',Fri:'Friday',Sat:'Saturday',Sun:'Sunday'};

function detectImage(buffer){
  if(buffer.length>=3 && buffer[0]===0xff && buffer[1]===0xd8 && buffer[2]===0xff) return {ext:'jpg',mime:'image/jpeg'};
  if(buffer.length>=8 && buffer.slice(0,8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]))) return {ext:'png',mime:'image/png'};
  if(buffer.length>=12 && buffer.slice(0,4).toString()==='RIFF' && buffer.slice(8,12).toString()==='WEBP') return {ext:'webp',mime:'image/webp'};
  return null;
}

function roomStatus(value){
  if(value===undefined||value==='Open'||value==='Active') return 'Active';
  if(value==='Unavailable'||value==='Inactive') return 'Inactive';
  throw httpError(400,'Choose Open or Unavailable room status.');
}

async function ensureUniqueRoomName(name,excludeId=null){
  const filter={roomName:new RegExp('^'+escapeRegex(name)+'$','i')};
  if(excludeId)filter._id={$ne:excludeId};
  if(await Room.exists(filter))throw httpError(409,'A room with this name already exists.');
}

function minutes(time){const [h,m]=String(time||'0:0').split(':').map(Number);return h*60+m;}
function overlaps(aStart,aEnd,bStart,bEnd){return minutes(aStart)<minutes(bEnd)&&minutes(bStart)<minutes(aEnd);}
function sameDay(a,b){return (a||[]).some(d=>(b||[]).includes(d));}
function time12(value){const [h,m]=String(value||'0:0').split(':').map(Number);const suffix=h>=12?'PM':'AM';return `${h%12||12}:${String(m).padStart(2,'0')} ${suffix}`;}
function dayNames(days){return [...new Set(days||[])].sort((a,b)=>DAY_ORDER.indexOf(a)-DAY_ORDER.indexOf(b)).map(d=>DAY_NAMES[d]||d);}
// "Monday", "Monday & Wednesday", "Monday, Wednesday & Friday"
function dayPhrase(days){
  const names=dayNames(days);
  if(names.length<=1)return names[0]||'';
  if(names.length===2)return `${names[0]} & ${names[1]}`;
  return `${names.slice(0,-1).join(', ')} & ${names[names.length-1]}`;
}

// Availability is derived from the room's ACTIVE schedules in the semester open
// now, measured per school day against the configured daily class-hour limit
// (settings.dailyTargetHours, default 8):
//   Unavailable -> an admin manually disabled the room
//   Occupied    -> some school day already reaches the daily class-hour limit
//   Available   -> the room still has free time on its class days
function busiestDayMinutes(schedules){
  let max=0;
  for(const day of DAY_ORDER){
    const used=sumMergedMinutes(schedules.filter(s=>(s.weekdays||[]).includes(day)).map(s=>({start:minutes(s.startTime),end:minutes(s.endTime)})));
    if(used>max)max=used;
  }
  return max;
}
function availabilityOf(room,dailyLimitMinutes,activeSchedules){
  if(room.status==='Inactive') return 'Unavailable';
  return busiestDayMinutes(activeSchedules||[])>=dailyLimitMinutes?'Occupied':'Available';
}
function availabilityMeaning(availability,dailyLimitMinutes){
  if(availability==='Unavailable') return 'Manually disabled by an administrator.';
  if(availability==='Occupied') return `Its active schedules already fill the ${Math.round(dailyLimitMinutes/60)}-hour daily class limit on at least one day.`;
  return 'Its active schedules still leave free time on every class day.';
}

// 1. Room list - deliberately minimal. Only the columns the list needs.
// Occupancy is measured per school day inside the semester open now: a room is
// Occupied only when a class day is already full, otherwise it still has free
// time slots even when classes are assigned to it.
router.get('/',async(req,res,next)=>{try{
  const f={};
  if(req.query.status&&['Active','Inactive'].includes(req.query.status))f.status=req.query.status;
  if(req.query.type&&['Laboratory','Non-Laboratory'].includes(req.query.type))f.roomType=req.query.type;
  if(req.query.q){const rx=new RegExp('^'+escapeRegex(String(req.query.q).trim())+'$','i');f.$or=[{roomCode:rx},{roomName:rx}];}
  const rooms=await Room.find(f).sort({roomCode:1}).lean();

  const dailyLimitMinutes=dailyLimitMinutesFrom(await getSettings());
  const current=await getCurrentSemester();
  const semesterMatch=current?{$or:[{semester:current._id},{semester:null}]}:{};
  const schedulesByRoom=new Map();
  for(const s of await Schedule.find({status:'Active',...semesterMatch}).select('room weekdays startTime endTime').lean()){
    const key=String(s.room);if(!schedulesByRoom.has(key))schedulesByRoom.set(key,[]);schedulesByRoom.get(key).push(s);
  }

  res.json(rooms.map(r=>{
    const roomSchedules=schedulesByRoom.get(String(r._id))||[];
    return {
      _id:r._id,
      roomCode:r.roomCode,
      roomName:r.roomName,
      building:r.building||'',
      roomType:r.roomType,
      capacity:r.capacity,
      status:r.status,
      photoPath:r.photoPath||'',
      equipment:r.equipment||[],
      activeScheduleCount:roomSchedules.length,
      availability:availabilityOf(r,dailyLimitMinutes,roomSchedules)
    };
  }));
}catch(e){next(e);}});

// 2. Room conflict pre-flight check. Called while the admin is assigning a subject
//    to a room, so the warning appears before the form is submitted.
router.post('/:id/conflicts',csrfProtect,async(req,res,next)=>{try{
  if(!mongoose.Types.ObjectId.isValid(req.params.id))throw httpError(400,'Invalid room.');
  const room=await Room.findById(req.params.id).lean(); if(!room) throw httpError(404,'Room not found.');
  const {weekdays,startTime,endTime,excludeScheduleId}=req.body||{};
  const days=Array.isArray(weekdays)?weekdays.filter(d=>DAY_ORDER.includes(d)):[];
  if(!days.length) throw httpError(400,'Choose at least one class day.');
  if(!startTime||!endTime||minutes(startTime)>=minutes(endTime)) throw httpError(400,'End time must be after start time.');
  if(room.status==='Inactive'){
    return res.json({conflict:true,roomUnavailable:true,roomCode:room.roomCode,
      message:`Room Conflict: ${room.roomCode} is marked Unavailable and cannot accept a class schedule.`});
  }

  // Same room + semester scope the save path and the room list already use: only
  // the term open now (plus legacy rows with no semester) blocks a room, so this
  // pre-flight can never warn about a class those checks would ignore.
  const current=await getCurrentSemester();
  const filter={room:room._id,status:'Active'};
  if(current)filter.$or=[{semester:current._id},{semester:null}];
  if(excludeScheduleId&&mongoose.Types.ObjectId.isValid(String(excludeScheduleId)))filter._id={$ne:excludeScheduleId};
  const existing=await Schedule.find(filter)
    .populate('subject','subjectCode subjectName')
    .populate('semester','academicYear term')
    .lean();

  // 1. A real time clash on a shared day. Adjacency is never a clash: a class
  // ending at 09:00 still leaves 09:00 free for the next one.
  const clash=existing.find(s=>sameDay(days,s.weekdays)&&overlaps(startTime,endTime,s.startTime,s.endTime));
  if(clash){
    const when=`${dayPhrase(clash.weekdays)} ${time12(clash.startTime)} - ${time12(clash.endTime)}`;
    return res.json({
      conflict:true,
      reason:'time',
      room:room.roomCode,roomName:room.roomName,roomType:room.roomType,
      subject:clash.subject?clash.subject.subjectCode:'',
      subjectName:clash.subject?clash.subject.subjectName:'',
      day:clash.weekdays.join(', '),
      time:`${clash.startTime} - ${clash.endTime}`,
      semester:clash.semester?`${clash.semester.academicYear} ${clash.semester.term}`:'',
      message:`Room Conflict: ${room.roomCode} is already assigned on ${when}.`
    });
  }

  // 2. The slot itself is free, so the only rule left that can refuse it is the
  // daily class-hour limit (settings.dailyTargetHours, default 8 hours). It is
  // evaluated through the same helper POST /assign and PATCH / use, so a room
  // whose day is already full - or would be pushed past the limit by this class
  // - is reported here exactly the way the save would refuse it.
  const usage=evaluateRoomTimeWindow(existing,days,startTime,endTime,dailyLimitMinutesFrom(await getSettings()));
  if(!usage.ok){
    return res.json({
      conflict:true,
      reason:'daily-limit',
      room:room.roomCode,roomName:room.roomName,roomType:room.roomType,
      day:days.join(', '),
      time:`${startTime} - ${endTime}`,
      message:`Room Conflict: ${room.roomCode} - ${usage.reason}`
    });
  }
  res.json({conflict:false});
}catch(e){next(e);}});

// 3. Timetable - every class, on every day it actually meets.
//
// The old version placed each class on `weekdays[0]` only, so an MWF class
// appeared on Monday and vanished from Wednesday and Friday, and it guessed the
// end time by adding a flat 30 minutes. Sessions now expand across all of their
// days and take their length from the day-pattern rule in Settings.
router.get('/timetable',async(req,res,next)=>{try{
  const now=await getCurrentSemester();
  const settings=await getSettings();
  const dayStart=toMinutes(settings.dayStart), dayEnd=toMinutes(settings.dayEnd);
  const pick=v=>String(v||'').trim();
  const hex=v=>/^[a-f0-9]{24}$/i.test(v);

  const semesterId=hex(pick(req.query.semester))?pick(req.query.semester):(now?String(now._id):null);
  const filter={status:'Active'};
  if(semesterId) filter.$or=[{semester:semesterId},{semester:null},{semester:{$exists:false}}];
  if(hex(pick(req.query.instructor))) filter.instructor=pick(req.query.instructor);
  if(hex(pick(req.query.subject))) filter.subject=pick(req.query.subject);
  if(hex(pick(req.query.room))) filter.room=pick(req.query.room);
  if(hex(pick(req.query.course))) filter.course=pick(req.query.course);
  if(/^\d+$/.test(pick(req.query.yearLevel))) filter.yearLevel=Number(pick(req.query.yearLevel));

  const [classes, instructors, subjects, rooms, courses]=await Promise.all([
    Schedule.find(filter)
      .populate('subject','subjectCode subjectName units laboratoryRequired')
      .populate('room','roomCode roomName roomType capacity')
      .populate('course','code name')
      .populate({path:'instructor',select:'firstName lastName instructorId'})
      .sort({startTime:1,weekdays:1}).lean(),
    Instructor.find({status:'Active'}).sort({lastName:1,firstName:1}).select('firstName lastName instructorId department').lean(),
    Subject.find({status:'Active'}).sort({subjectCode:1}).select('subjectCode subjectName').lean(),
    Room.find({status:'Active'}).sort({roomCode:1}).select('roomCode roomName roomType capacity').lean(),
    Course.find({status:'Active'}).sort({code:1}).select('code name').lean()
  ]);

  const name=p=>p?`${p.firstName||''} ${p.lastName||''}`.trim():'TBA';
  const span=t=>`${time12(minutesToHHMM(t))}`;

  // Expand each schedule onto every weekday it meets on.
  const sessions=[];
  for(const s of classes){
    const start=toMinutes(s.startTime), end=toMinutes(s.endTime);
    const pattern=patternKeyFor(s.weekdays||[]);
    const expected=sessionMinutesFor(settings,pattern,s.subject?s.subject.units:0,(s.weekdays||[]).length);
    for(const day of (s.weekdays||[])){
      sessions.push({
        schedule:String(s._id), day,
        start, end, duration:end-start, pattern,
        expectedMinutes: expected.error?null:expected.minutes,
        durationOk: expected.error?true:(end-start)===expected.minutes,
        inWindow: start>=dayStart && end<=dayEnd,
        subject:s.subject||null, room:s.room||null, course:s.course||null, instructor:s.instructor||null,
        yearLevel:s.yearLevel, sectionType:s.sectionType, blockLabel:s.blockLabel, status:s.status,
        conflict:false, conflictReason:''
      });
    }
  }

  // Conflicts inside the displayed set, flagged on both classes so the grid
  // marks them instead of quietly leaving one of them out.
  const conflicts=[];
  for(let i=0;i<sessions.length;i++){
    for(let j=i+1;j<sessions.length;j++){
      const a=sessions[i], b=sessions[j];
      if(a.day!==b.day||a.start>=b.end||b.start>=a.end) continue;
      const reasons=[];
      if(a.room&&b.room&&String(a.room._id)===String(b.room._id)) reasons.push(`Room ${a.room.roomCode} is booked for both.`);
      if(a.instructor&&b.instructor&&String(a.instructor._id)===String(b.instructor._id)) reasons.push(`${name(a.instructor)} is assigned to both.`);
      const sameSection=a.course&&b.course&&String(a.course._id)===String(b.course._id)
        &&Number(a.yearLevel)===Number(b.yearLevel)&&a.sectionType===b.sectionType
        &&String(a.blockLabel||'').toUpperCase()===String(b.blockLabel||'').toUpperCase();
      if(sameSection) reasons.push('Two classes for the same section at the same time.');
      if(!reasons.length) continue;
      const text=reasons.join(' ');
      a.conflict=b.conflict=true;
      a.conflictReason=a.conflictReason?`${a.conflictReason} ${text}`:text;
      b.conflictReason=b.conflictReason?`${b.conflictReason} ${text}`:text;
      const brief=x=>({schedule:x.schedule,subject:x.subject?x.subject.subjectCode:' - ',room:x.room?x.room.roomCode:' - ',instructor:name(x.instructor),time:`${span(x.start)} - ${span(x.end)}`});
      conflicts.push({day:a.day,message:text,a:brief(a),b:brief(b)});
    }
  }

  // Workload totals for the same filtered set, so the timetable and the
  // numbers underneath it can never disagree.
  const perDay={}, perInstructor=new Map(), perRoom=new Map();
  for(const s of sessions){
    const d=perDay[s.day]=perDay[s.day]||{day:s.day,classes:0,minutes:0};
    d.classes++; d.minutes+=s.duration;
    const ik=s.instructor?String(s.instructor._id):'tba';
    const ir=perInstructor.get(ik)||{key:ik,name:name(s.instructor),unassigned:!s.instructor,classes:0,minutes:0,days:new Set()};
    ir.classes++; ir.minutes+=s.duration; ir.days.add(s.day); perInstructor.set(ik,ir);
    const rk=s.room?String(s.room._id):'none';
    const rr=perRoom.get(rk)||{key:rk,roomCode:s.room?s.room.roomCode:' - ',classes:0,minutes:0,days:new Set()};
    rr.classes++; rr.minutes+=s.duration; rr.days.add(s.day); perRoom.set(rk,rr);
  }

  // Half-hour rows across the configured school day.
  const timeSlots=[];
  for(let t=dayStart;t<dayEnd;t+=30){
    const to=Math.min(t+30,dayEnd);
    timeSlots.push({start:t,end:to,label:`${span(t)} - ${span(to)}`});
  }

  res.json({
    semester: now?`${now.academicYear} ${now.term}`:'',
    settings:{dayStart:settings.dayStart,dayEnd:settings.dayEnd,dailyTargetHours:settings.dailyTargetHours,sessionRules:settings.sessionRules},
    filters:{instructor:pick(req.query.instructor),subject:pick(req.query.subject),room:pick(req.query.room),course:pick(req.query.course),yearLevel:pick(req.query.yearLevel)},
    days:DAY_ORDER,
    timeSlots,
    sessions,
    conflicts,
    totals:{
      perDay:Object.values(perDay).sort((a,b)=>DAY_ORDER.indexOf(a.day)-DAY_ORDER.indexOf(b.day)),
      perInstructor:[...perInstructor.values()].map(r=>({...r,days:[...r.days]})).sort((a,b)=>b.minutes-a.minutes),
      perRoom:[...perRoom.values()].map(r=>({...r,days:[...r.days]})).sort((a,b)=>b.minutes-a.minutes)
    },
    options:{
      instructors:instructors.map(i=>({_id:String(i._id),label:name(i),instructorId:i.instructorId||''})),
      subjects:subjects.map(s=>({_id:String(s._id),label:`${s.subjectCode} - ${s.subjectName}`})),
      rooms:rooms.map(r=>({_id:String(r._id),label:r.roomCode,capacity:r.capacity})),
      courses:courses.map(c=>({_id:String(c._id),label:c.code}))
    }
  });
}catch(e){next(e);}});

// 3. Add a room. The directory is maintained by the Admin portal when a new
//    laboratory or lecture room becomes available.
router.post('/',csrfProtect,async(req,res,next)=>{try{
  const roomCode=required(req.body.roomCode,'Room code',40).toUpperCase();
  if(await Room.exists({roomCode}))throw httpError(409,'Room code already exists.');
  const roomName=required(req.body.roomName,'Room name',120);
  await ensureUniqueRoomName(roomName);
  const roomType=req.body.roomType==='Laboratory'?'Laboratory':'Non-Laboratory';
  const capacity=Number(req.body.capacity);
  if(!Number.isInteger(capacity)||capacity<1||capacity>500)throw httpError(400,'Capacity must be between 1 and 500.');
  const room=await Room.create({
    roomCode,
    roomName,
    building:clean(req.body.building,120)||'Main Building',
    roomType,
    capacity,
    equipment:Array.isArray(req.body.equipment)?req.body.equipment.map(x=>clean(x,100)).filter(Boolean):String(req.body.equipment||'').split(',').map(x=>clean(x,100)).filter(Boolean),
    status:roomStatus(req.body.status)
  });
  await logActivity({performedBy:req.user._id,category:'Room',action:'Room created',description:'Created room '+roomCode+'.'});
  res.status(201).json(room);
}catch(e){if(e.code===11000)return next(httpError(409,'Room code already exists.'));next(e);}});

// 4. Room detail page - the room record plus every schedule assigned to it.
router.get('/:id',async(req,res,next)=>{try{
  if(!mongoose.Types.ObjectId.isValid(req.params.id))throw httpError(400,'Invalid room.');
  const room=await Room.findById(req.params.id).lean(); if(!room) throw httpError(404,'Room not found.');
  const schedules=await Schedule.find({room:room._id})
    .populate('subject','subjectCode subjectName units laboratoryRequired')
    .populate('course','code name')
    .populate('semester','academicYear term')
    .populate({path:'instructor',populate:{path:'user',select:'username email'}})
    .sort({status:1,startTime:1,weekdays:1}).lean();
  const activeScheduleCount=schedules.filter(s=>s.status==='Active').length;
  // Occupancy is judged per school day in the semester open now: the room reads
  // Occupied only when a class day already fills the daily class-hour limit.
  const dailyLimitMinutes=dailyLimitMinutesFrom(await getSettings());
  const current=await getCurrentSemester();
  const activeThisSemester=schedules.filter(s=>s.status==='Active'&&(!current||!s.semester||String(s.semester._id||s.semester)===String(current._id)));
  const availability=availabilityOf(room,dailyLimitMinutes,activeThisSemester);
  res.json({
    room,
    schedules,
    availability,
    availabilityMeaning:availabilityMeaning(availability,dailyLimitMinutes),
    activeScheduleCount
  });
}catch(e){next(e);}});

router.patch('/:id',csrfProtect,async(req,res,next)=>{try{
  const room=await Room.findById(req.params.id); if(!room) throw httpError(404,'Room not found.');
  const old=room.roomCode;
  if(req.body.roomCode!==undefined)room.roomCode=required(req.body.roomCode,'Room code',40).toUpperCase();
  if(req.body.roomName!==undefined){const name=required(req.body.roomName,'Room name',120);await ensureUniqueRoomName(name,room._id);room.roomName=name;}
  if(req.body.building!==undefined)room.building=clean(req.body.building,120)||room.building||'Main Building';
  if(req.body.roomType!==undefined){
    if(!['Laboratory','Non-Laboratory'].includes(req.body.roomType))throw httpError(400,'Invalid room type.');
    if(req.body.roomType==='Non-Laboratory'&&room.roomType==='Laboratory'){
      const Subject=require('../models/Subject'); const labSubjects=await Subject.find({laboratoryRequired:true}).distinct('_id');
      if(await Schedule.exists({room:room._id,subject:{$in:labSubjects}}))throw httpError(409,'This room is used by laboratory subject schedules. Move those schedules before changing the room type.');
    }
    room.roomType=req.body.roomType;
  }
  if(req.body.capacity!==undefined){
    const c=Number(req.body.capacity); if(!Number.isInteger(c)||c<1||c>500)throw httpError(400,'Capacity must be between 1 and 500.');
    const activeScheduleIds=await Schedule.find({room:room._id,status:'Active'}).distinct('_id');
    if(activeScheduleIds.length){
      const Enrollment=require('../models/Enrollment'); const max=await Promise.all(activeScheduleIds.map(id=>Enrollment.countDocuments({schedule:id,status:'Active'})));
      if(Math.max(...max)>c)throw httpError(409,'Capacity cannot be lower than current active enrollment.');
    }
    room.capacity=c;
  }
  if(req.body.equipment!==undefined){
    room.equipment=Array.isArray(req.body.equipment)?req.body.equipment.map(x=>clean(x,100)).filter(Boolean):String(req.body.equipment).split(',').map(x=>clean(x,100)).filter(Boolean);
  }
  if(req.body.status!==undefined){
    const nextStatus=roomStatus(req.body.status);
    if(nextStatus==='Inactive'&&await Schedule.exists({room:room._id,status:'Active'}))throw httpError(409,'Deactivate or move active schedules before making this room inactive.');
    room.status=nextStatus;
  }
  await room.save(); await logActivity({performedBy:req.user._id,category:'Room',action:'Room updated',description:'Updated room '+old+'.'});
  res.json({message:'Room updated successfully.'});
}catch(e){if(e.code===11000)return next(httpError(409,'Room code already exists.'));next(e);}});

router.post('/:id/photo',csrfProtect,upload.single('photo'),async(req,res,next)=>{try{
  if(!req.file)throw httpError(400,'Choose a JPG, PNG, or WebP image.');
  const type=detectImage(req.file.buffer); if(!type)throw httpError(400,'Only valid JPG, PNG, or WebP images are allowed.');
  const room=await Room.findById(req.params.id); if(!room)throw httpError(404,'Room not found.');
  const filename='-'+Date.now()+'.'+type.ext;
  const dir=path.join(__dirname,'..','public','uploads','rooms');
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,filename),req.file.buffer);
  room.photoPath='/uploads/rooms/'+filename; room.photoIsPlaceholder=false;
  await room.save(); await logActivity({performedBy:req.user._id,category:'Room',action:'Room photo updated',description:'Updated photo for '+room.roomCode+'.'});
  res.json({message:'Room photo uploaded.',photoPath:room.photoPath});
}catch(e){next(e);}});

module.exports=router;
