const express = require('express');
const Instructor = require('../models/Instructor');
const Schedule = require('../models/Schedule');
const Enrollment = require('../models/Enrollment');
const ClassRecord = require('../models/ClassRecord');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { httpError } = require('../utils/validation');
const { logActivity } = require('../services/logService');
const { getCurrentSemester } = require('../services/semesterService');
const { getSettings, seatsFor } = require('../services/settingsService');

const router = express.Router();
// This whole router is the Instructor Portal. Nothing here is reachable by any other role.
router.use(requireAuth, requireRole('Instructor'));

async function myInstructor(userId) {
  const instructor = await Instructor.findOne({ user: userId }).lean();
  if (!instructor) throw httpError(404, 'Instructor profile not found.');
  return instructor;
}

const DAY_INDEX = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5 };

// Total times a class actually meets: walks every day of the semester and counts
// the ones that fall on this schedule's class days. Used as attendanceTotal.
function countClassDays(weekdays, startDate, endDate) {
  if (!startDate || !endDate || !(weekdays || []).length) return 0;
  const wanted = new Set(weekdays.map(day => DAY_INDEX[day]).filter(Boolean));
  if (!wanted.size) return 0;
  let total = 0;
  const cursor = new Date(startDate);
  cursor.setUTCHours(0, 0, 0, 0);
  const last = new Date(endDate);
  last.setUTCHours(23, 59, 59, 999);
  // Guard against a malformed semester range turning this into a long loop.
  const hardStop = 400;
  for (let i = 0; cursor <= last && i < hardStop; i += 1) {
    if (wanted.has(cursor.getUTCDay())) total += 1;
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  return total;
}

const sectionLabel = schedule => schedule?.sectionType === 'Block'
  ? `Block ${schedule.blockLabel || ''}`.trim()
  : 'Open Section';

const DAY_FULL = { Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday' };

// "Monday, Wednesday & Friday"
function daysLabel(weekdays) {
  const words = (weekdays || []).map(day => DAY_FULL[day] || day).filter(Boolean);
  if (words.length <= 1) return words[0] || '';
  if (words.length === 2) return `${words[0]} & ${words[1]}`;
  return `${words.slice(0, -1).join(', ')} & ${words[words.length - 1]}`;
}

// Resolve the schedule behind a URL id and prove it belongs to this instructor.
// Returning 404 (not 403) keeps other instructors' schedule ids unguessable.
async function ownSchedule(scheduleId, instructorId) {
  const schedule = await Schedule.findOne({ _id: scheduleId, instructor: instructorId })
    .populate('subject', 'subjectCode subjectName units laboratoryRequired description status')
    .populate('room', 'roomCode roomName roomType capacity building')
    .populate('course', 'code name')
    .populate('instructor', 'instructorId firstName middleName lastName department')
    // Without these, semesterWindow() gets a bare ObjectId and
    // countClassDays() silently returns 0 sessions for every assigned section.
    .populate('semester', 'academicYear term startDate endDate isCurrent')
    .lean();
  if (!schedule) throw httpError(404, 'That class is not assigned to you.');
  return schedule;
}

function semesterWindow(schedule, current) {
  // Offerings recorded before they were tied to a semester still belong to the
  // current period, so they are treated as current rather than hidden.
  if (schedule.semester) return { semesterId: String(schedule.semester._id || schedule.semester), semester: schedule.semester };
  if (current) return { semesterId: String(current._id), semester: current };
  return { semesterId: null, semester: null };
}

// The students enrolled in one section, with their class record merged in.
async function rosterFor(schedule, current, instructorId) {
  const { semesterId, semester } = semesterWindow(schedule, current);
  const filter = { schedule: schedule._id, status: 'Active' };
  if (semesterId) filter.semester = semesterId;

  const [enrollments, records] = await Promise.all([
    Enrollment.find(filter)
      .populate({ path: 'student', select: 'studentId firstName middleName lastName yearLevel course', populate: { path: 'course', select: 'code name' } })
      .sort({ createdAt: 1 })
      .lean(),
    ClassRecord.find({ schedule: schedule._id }).lean()
  ]);

  const recordByEnrollment = new Map(records.map(record => [String(record.enrollment), record]));
  const total = countClassDays(schedule.weekdays, semester && semester.startDate, semester && semester.endDate);

  return {
    semesterLabel: semester ? `${semester.academicYear} ${semester.term}` : '',
    semesterId,
    attendanceTotal: total,
    students: enrollments.map(enrollment => {
      const record = recordByEnrollment.get(String(enrollment._id)) || null;
      // Only attendance, assignments and activities are recorded here.
      // There is no grade to mirror onto the enrollment.
      return {
        enrollment: enrollment._id,
        student: enrollment.student,
        status: enrollment.enrollmentDisplayStatus || enrollment.result || enrollment.status,
        record: record ? {
          attendancePresent: record.attendancePresent,
          attendanceTotal: record.attendanceTotal ?? total,
          assignments: record.assignments,
          activities: record.activities,
          updatedAt: record.updatedAt
        } : null
      };
    })
  };
}

function toNumberOrNull(value, label, { min, max = Infinity }) {
  if (value === '' || value == null) return null;
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) throw httpError(400, `${label} must be a number.`);
  if (parsed < min || parsed > max) {
    throw httpError(400, Number.isFinite(max)
      ? `${label} must be between ${min} and ${max}.`
      : `${label} must be ${min} or more.`);
  }
  return parsed;
}

// ---------------------------------------------------------------- My Subjects

router.get('/subjects', async (req, res, next) => {
  try {
    const instructor = await myInstructor(req.user._id);
    const current = await getCurrentSemester();
    // Only the current term is shown - that is the set the instructor is actually teaching.
    const filter = { instructor: instructor._id, status: 'Active' };
    if (current) filter.semester = current._id;

    const schedules = await Schedule.find(filter)
      .populate('subject', 'subjectCode subjectName units status')
      .populate('room', 'roomCode roomName roomType capacity')
      .populate('course', 'code name')
      .sort({ startTime: 1 })
      .lean();

    // One grouped count beats a query per row.
    const counts = schedules.length
      ? await Enrollment.aggregate([
        { $match: { schedule: { $in: schedules.map(s => s._id) }, status: 'Active' } },
        { $group: { _id: '$schedule', n: { $sum: 1 } } }
      ])
      : [];
    const bySchedule = new Map(counts.map(row => [String(row._id), row.n]));
    // Section size is configurable, so the instructor sees the same seat count
    // the registrar and the student see - not the raw room capacity.
    const settings = await getSettings();

    res.json({
      semester: current ? `${current.academicYear} ${current.term}` : '',
      instructor: {
        instructorId: instructor.instructorId,
        name: `${instructor.firstName || ''} ${instructor.lastName || ''}`.trim(),
        department: instructor.department
      },
      subjects: schedules.map(schedule => ({
        _id: schedule._id,
        subject: schedule.subject,
        course: schedule.course,
        section: sectionLabel(schedule),
        sectionType: schedule.sectionType,
        blockLabel: schedule.blockLabel,
        yearLevel: schedule.yearLevel,
        days: schedule.weekdays,
        daysLabel: daysLabel(schedule.weekdays),
        startTime: schedule.startTime,
        endTime: schedule.endTime,
        room: schedule.room,
        capacity: seatsFor(schedule.room && schedule.room.capacity, settings),
        studentCount: bySchedule.get(String(schedule._id)) || 0
      }))
    });
  } catch (err) { next(err); }
});

// ------------------------------------------------------------ Subject Details

router.get('/subjects/:scheduleId', async (req, res, next) => {
  try {
    const instructor = await myInstructor(req.user._id);
    const current = await getCurrentSemester();
    const schedule = await ownSchedule(req.params.scheduleId, instructor._id);
    const roster = await rosterFor(schedule, current, instructor._id);

    res.json({
      semester: roster.semesterLabel,
      instructor: {
        instructorId: instructor.instructorId,
        name: `${instructor.firstName || ''} ${instructor.lastName || ''}`.trim(),
        department: instructor.department
      },
      subject: schedule.subject,
      course: schedule.course,
      schedule: {
        _id: schedule._id,
        section: sectionLabel(schedule),
        sectionType: schedule.sectionType,
        blockLabel: schedule.blockLabel,
        yearLevel: schedule.yearLevel,
        days: schedule.weekdays,
        daysLabel: daysLabel(schedule.weekdays),
        startTime: schedule.startTime,
        endTime: schedule.endTime,
        status: schedule.status
      },
      room: schedule.room,
      studentCount: roster.students.length,
      capacity: seatsFor(schedule.room && schedule.room.capacity, await getSettings()),
      attendanceTotal: roster.attendanceTotal
    });
  } catch (err) { next(err); }
});

// ------------------------------------------------- Class Management (roster)

router.get('/subjects/:scheduleId/students', async (req, res, next) => {
  try {
    const instructor = await myInstructor(req.user._id);
    const current = await getCurrentSemester();
    const schedule = await ownSchedule(req.params.scheduleId, instructor._id);
    const roster = await rosterFor(schedule, current, instructor._id);
    res.json({
      semester: roster.semesterLabel,
      subject: schedule.subject,
      course: schedule.course,
      section: sectionLabel(schedule),
      room: schedule.room,
      studentCount: roster.students.length,
      students: roster.students
    });
  } catch (err) { next(err); }
});

// ------------------------------------------------------------- Class Records

router.get('/subjects/:scheduleId/records', async (req, res, next) => {
  try {
    const instructor = await myInstructor(req.user._id);
    const current = await getCurrentSemester();
    const schedule = await ownSchedule(req.params.scheduleId, instructor._id);
    const roster = await rosterFor(schedule, current, instructor._id);
    res.json({
      semester: roster.semesterLabel,
      subject: schedule.subject,
      course: schedule.course,
      section: sectionLabel(schedule),
      room: schedule.room,
      attendanceTotal: roster.attendanceTotal,
      studentCount: roster.students.length,
      students: roster.students
    });
  } catch (err) { next(err); }
});

// Save / update grades for a section. Replaces the whole sheet in one pass,
// so the instructor can edit many students before saving once.
router.post('/subjects/:scheduleId/records', csrfProtect, async (req, res, next) => {
  try {
    const instructor = await myInstructor(req.user._id);
    const current = await getCurrentSemester();
    const schedule = await ownSchedule(req.params.scheduleId, instructor._id);
    const roster = await rosterFor(schedule, current, instructor._id);

    const rows = Array.isArray(req.body.rows) ? req.body.rows : null;
    if (!rows) throw httpError(400, 'No class records were submitted. Refresh the page and try again.');

    // Only students actually enrolled in this section can be recorded here.
    const allowed = new Map(roster.students.map(row => [String(row.enrollment), row]));
    const seen = new Set();

    // This module holds attendance, assignments and activities only. A row that
    // still carries a grade field is refused rather than silently dropped, so a
    // stale client cannot think it saved something it did not.
    const GRADE_FIELDS = ['finalGrade', 'quizzes', 'exams', 'isIncomplete', 'grade', 'result'];

    const updates = [];
    for (const row of rows) {
      const enrollmentId = String(row.enrollment || '');
      const existing = allowed.get(enrollmentId);
      if (!existing) throw httpError(400, 'One of the students is not enrolled in this class.');
      if (seen.has(enrollmentId)) throw httpError(400, 'A student appears twice in this class list.');
      seen.add(enrollmentId);

      const stray = GRADE_FIELDS.find(key => row[key] !== undefined && row[key] !== null && row[key] !== '');
      if (stray) {
        throw httpError(400, 'Class records only hold attendance, assignments and activities. Remove the grade value and save again.');
      }

      // Only bound attendance by the calendar when it is known. A legacy or
      // not-yet-started section reports 0 sessions, and capping at 0 here would
      // make attendance permanently un-enterable on those sections ("between 0
      // and 0"). A 0/blank total means "no calendar to check against", not
      // "zero attendance allowed", so the explicit check below is the only bound.
      const present = toNumberOrNull(row.attendancePresent, 'Attendance', { min: 0 });
      if (present != null && roster.attendanceTotal && present > roster.attendanceTotal) {
        throw httpError(400, `Attendance cannot exceed ${roster.attendanceTotal} sessions.`);
      }

      updates.push({
        studentId: existing.student && existing.student._id,
        values: {
          schedule: schedule._id,
          student: existing.student && existing.student._id,
          enrollment: enrollmentId,
          semester: roster.semesterId,
          attendancePresent: present,
          attendanceTotal: roster.attendanceTotal || null,
          assignments: toNumberOrNull(row.assignments, 'Assignments', { min: 0, max: 100 }),
          activities: toNumberOrNull(row.activities, 'Activities', { min: 0, max: 100 }),
          updatedBy: req.user._id
        }
      });
    }

    for (const update of updates) {
      await ClassRecord.updateOne(
        { schedule: schedule._id, student: update.studentId },
        { $set: update.values },
        { upsert: true }
      );
    }

    const subjectLabel = schedule.subject ? `${schedule.subject.subjectCode} - ${schedule.subject.subjectName}` : 'this class';
    await logActivity({
      performedBy: req.user._id,
      category: 'Class Records',
      action: 'Class records updated',
      description: `Updated attendance, assignments and activities for ${updates.length} student${updates.length === 1 ? '' : 's'} in ${subjectLabel} (${sectionLabel(schedule)}).`
    });

    // Return the refreshed sheet so the UI always shows stored values, not typed ones.
    const refreshed = await rosterFor(schedule, current, instructor._id);
    res.json({ message: `Class records saved for ${updates.length} student${updates.length === 1 ? '' : 's'}.`, students: refreshed.students });
  } catch (err) { next(err); }
});

module.exports = router;
