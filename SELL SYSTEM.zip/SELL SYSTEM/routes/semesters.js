const express = require('express');
const Semester = require('../models/Semester');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { httpError } = require('../utils/validation');
const { getCurrentSemester, listSemesters } = require('../services/semesterService');
const { logActivity } = require('../services/logService');

// The current term follows the calendar automatically (semesterService picks
// whichever term's start date arrived most recently), so these admin routes
// never set isCurrent by hand: they add missing terms and correct the date
// ranges, and the calendar logic does the rest.
const router = express.Router();
router.use(requireAuth);

const present = s => ({
  _id: s._id,
  academicYear: s.academicYear,
  term: s.term,
  label: `${s.academicYear} ${s.term}`,
  startDate: s.startDate,
  endDate: s.endDate,
  isCurrent: !!s.isCurrent
});

router.get('/current', async (req, res, next) => {
  try {
    const s = await getCurrentSemester();
    res.json({ semester: s ? present(s) : null });
  } catch (err) { next(err); }
});

router.get('/', requireRole('Admin'), async (req, res, next) => {
  try {
    res.json((await listSemesters()).map(present));
  } catch (err) { next(err); }
});

function readDates(body) {
  const startDate = body.startDate ? new Date(body.startDate) : null;
  const endDate = body.endDate ? new Date(body.endDate) : null;
  if (!startDate || isNaN(startDate) || !endDate || isNaN(endDate)) {
    throw httpError(400, 'Choose valid start and end dates.');
  }
  if (endDate <= startDate) throw httpError(400, 'End date must be after the start date.');
  return { startDate, endDate };
}

// Adds a term the auto-calendar does not create on its own (a special term, or
// a school year further ahead). The model still validates the year format and
// the (academicYear, term) uniqueness.
router.post('/', requireRole('Admin'), csrfProtect, async (req, res, next) => {
  try {
    const academicYear = String(req.body.academicYear || '').trim();
    if (!/^\d{4}-\d{4}$/.test(academicYear)) throw httpError(400, 'Academic year must look like 2026-2027.');
    const term = String(req.body.term || '').trim();
    if (!Semester.schema.path('term').enumValues.includes(term)) throw httpError(400, 'Choose a valid term.');
    const { startDate, endDate } = readDates(req.body);
    if (await Semester.exists({ academicYear, term })) throw httpError(409, 'That academic year and term already exists.');
    const created = await Semester.create({ academicYear, term, startDate, endDate });
    await logActivity({
      performedBy: req.user._id, category: 'Settings', action: 'Semester created',
      description: `Created ${academicYear} ${term} (${startDate.toDateString()} - ${endDate.toDateString()}).`
    });
    res.status(201).json(present(created));
  } catch (err) { next(err); }
});

// Corrects a term's date ranges (e.g. the real school calendar differs from
// the defaults). Year and term stay immutable because schedules, enrollments
// and offerings all reference this record. Moving a start date into the past
// is how an admin advances the current term - the calendar re-derives it.
router.patch('/:id', requireRole('Admin'), csrfProtect, async (req, res, next) => {
  try {
    const semester = await Semester.findById(req.params.id);
    if (!semester) throw httpError(404, 'Semester not found.');
    const { startDate, endDate } = readDates(req.body);
    semester.startDate = startDate;
    semester.endDate = endDate;
    await semester.save();
    const current = await getCurrentSemester();
    await logActivity({
      performedBy: req.user._id, category: 'Settings', action: 'Semester updated',
      description: `Updated ${semester.academicYear} ${semester.term} dates (${startDate.toDateString()} - ${endDate.toDateString()}).`
    });
    res.json({ semester: present(semester), current: current ? present(current) : null });
  } catch (err) { next(err); }
});

module.exports = router;