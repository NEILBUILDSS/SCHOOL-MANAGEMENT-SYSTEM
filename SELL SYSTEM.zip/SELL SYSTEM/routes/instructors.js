const express = require('express');
const bcrypt = require('bcryptjs');
const Instructor = require('../models/Instructor');
const Schedule = require('../models/Schedule');
const User = require('../models/User');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { createPersonAccount } = require('../services/accountService');
const { logActivity } = require('../services/logService');
const { escapeRegex, httpError, required, clean, validateEmail, validatePassword } = require('../utils/validation');

const router = express.Router();
router.use(requireAuth, requireRole('Admin'));

router.get('/', async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.status && ['Active','Inactive'].includes(req.query.status)) filter.status = req.query.status;
    if (req.query.q) {
      const rx = new RegExp(escapeRegex(req.query.q.trim()), 'i');
      filter.$or = [{ instructorId: rx }, { firstName: rx }, { middleName: rx }, { lastName: rx }, { department: rx }];
    }
    const instructors = await Instructor.find(filter).populate('user', 'email username status').sort({ lastName: 1, firstName: 1 }).lean();
    res.json(instructors);
  } catch (err) { next(err); }
});

router.post('/', csrfProtect, async (req, res, next) => {
  try {
    const user = await createPersonAccount({ role: 'Instructor', data: req.body, actorUserId: req.user._id });
    const instructor = await Instructor.findOne({ user: user._id }).populate('user', 'email username').lean();
    res.status(201).json(instructor);
  } catch (err) { next(err); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const instructor = await Instructor.findById(req.params.id).populate('user', 'email username status createdAt').lean();
    if (!instructor) throw httpError(404, 'Instructor not found.');
    const schedules = await Schedule.find({ instructor: instructor._id })
      .populate('subject course room').sort({ updatedAt: -1 }).lean();
    res.json({ instructor, schedules });
  } catch (err) { next(err); }
});

router.patch('/:id', csrfProtect, async (req, res, next) => {
  try {
    const instructor = await Instructor.findById(req.params.id);
    if (!instructor) throw httpError(404, 'Instructor not found.');
    const user = await User.findById(instructor.user);
    if (!user) throw httpError(404, 'Instructor account not found.');

    if (req.body.instructorId !== undefined) {
      const instructorId = required(req.body.instructorId, 'Instructor ID', 50).toUpperCase();
      if (await Instructor.exists({ instructorId, _id: { $ne: instructor._id } })) throw httpError(409, 'Instructor ID is already in use.');
      instructor.instructorId = instructorId;
    }
    if (req.body.firstName !== undefined) instructor.firstName = required(req.body.firstName, 'First name', 80);
    if (req.body.middleName !== undefined) instructor.middleName = clean(req.body.middleName, 80);
    if (req.body.lastName !== undefined) instructor.lastName = required(req.body.lastName, 'Last name', 80);
    if (req.body.contactNumber !== undefined) instructor.contactNumber = required(req.body.contactNumber, 'Contact number', 40);
    if (req.body.department !== undefined) instructor.department = required(req.body.department, 'Department', 120);
    if (req.body.status !== undefined) {
      if (!['Active', 'Inactive'].includes(req.body.status)) throw httpError(400, 'Status must be Active or Inactive.');
      if (req.body.status === 'Inactive' && await Schedule.exists({ instructor: instructor._id, status: 'Active' })) {
        throw httpError(409, 'Deactivate or reassign this instructor\'s active schedules first.');
      }
      instructor.status = req.body.status;
      user.status = req.body.status;
    }
    if (req.body.email !== undefined) user.email = validateEmail(req.body.email);
    if (req.body.password) user.passwordHash = await bcrypt.hash(validatePassword(req.body.password), 12);

    await instructor.save();
    await user.save();
    await logActivity({
      performedBy: req.user._id,
      category: 'Instructor',
      action: 'Instructor updated',
      description: `Updated instructor ${instructor.instructorId}.`
    });
    res.json({ message: 'Instructor updated successfully.' });
  } catch (err) {
    if (err.code === 11000) return next(httpError(409, 'That instructor ID or email is already in use.'));
    next(err);
  }
});

module.exports = router;
