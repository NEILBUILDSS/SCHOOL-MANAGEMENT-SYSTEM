const express = require('express');
const SubjectOffering = require('../models/SubjectOffering');
const Subject = require('../models/Subject');
const Course = require('../models/Course');
const Semester = require('../models/Semester');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { httpError } = require('../utils/validation');
const { logActivity } = require('../services/logService');

const router = express.Router();
router.use(requireAuth, requireRole('Admin'));

function present(o) {
  return {
    _id: o._id,
    semester: o.semester ? { _id: o.semester._id, label: `${o.semester.academicYear} ${o.semester.term}` } : null,
    course: o.course ? { _id: o.course._id, code: o.course.code, name: o.course.name } : null,
    yearLevel: o.yearLevel,
    sectionType: o.sectionType,
    blockLabel: o.blockLabel,
    sectionKey: o.sectionKey,
    subject: o.subject ? { _id: o.subject._id, subjectCode: o.subject.subjectCode, subjectName: o.subject.subjectName, units: o.subject.units } : null,
    offered: o.offered,
    updatedBy: o.updatedBy
  };
}

// List subject offerings for a semester (optionally filtered by course and year level)
router.get('/', async (req, res, next) => {
  try {
    const { semesterId, courseId, yearLevel } = req.query;
    const filter = {};
    if (semesterId) filter.semester = semesterId;
    if (courseId) filter.course = courseId;
    if (yearLevel) filter.yearLevel = Number(yearLevel);

    const offerings = await SubjectOffering.find(filter)
      .populate('course', 'code name')
      .populate('subject', 'subjectCode subjectName units')
      .populate('semester', 'academicYear term')
      .sort({ 'course.code': 1, yearLevel: 1, 'subject.subjectCode': 1 });

    res.json(offerings.map(present));
  } catch (err) { next(err); }
});

// Create or update a subject offering (upsert by semester + course + sectionKey + subject)
router.post('/', csrfProtect, async (req, res, next) => {
  try {
    const { semesterId, courseId, yearLevel, sectionType = 'Open', blockLabel = '', subjectId, offered = true } = req.body;

    if (!semesterId || !courseId || !subjectId || yearLevel === undefined) {
      throw httpError(400, 'Semester, course, subject, and year level are required.');
    }

    const year = Number(yearLevel);
    if (!Number.isInteger(year) || year < 1 || year > 4) {
      throw httpError(400, 'Year level must be 1 to 4.');
    }

    // Verify references exist
    const [semester, course, subject] = await Promise.all([
      Semester.findById(semesterId),
      Course.findById(courseId),
      Subject.findById(subjectId)
    ]);

    if (!semester) throw httpError(404, 'Semester not found.');
    if (!course) throw httpError(404, 'Course not found.');
    if (!subject) throw httpError(404, 'Subject not found.');
    if (String(subject.course) !== String(course._id)) {
      throw httpError(400, 'Subject does not belong to this course.');
    }

    // Generate section key
    let sectionKey;
    if (sectionType === 'Block') {
      const label = String(blockLabel || '').trim().toUpperCase();
      sectionKey = `B:${year}:${label || 'UNLABELED'}`;
    } else {
      sectionKey = `O:${year}`;
    }

    const offering = await SubjectOffering.findOneAndUpdate(
      { semester: semesterId, course: courseId, sectionKey, subject: subjectId },
      { yearLevel: year, sectionType, blockLabel, offered, updatedBy: req.user._id },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    )
      .populate('course', 'code name')
      .populate('subject', 'subjectCode subjectName units')
      .populate('semester', 'academicYear term');

    await logActivity({
      performedBy: req.user._id,
      category: 'Subject Offering',
      action: offered ? 'Subject offered' : 'Subject withdrawn',
      description: `${subject.subjectCode} (${subject.subjectName}) ${offered ? 'offered' : 'withdrawn'} for ${semester.academicYear} ${semester.term}, Year ${year}.`
    });

    res.status(201).json(present(offering));
  } catch (err) { next(err); }
});

// Toggle offered status on an existing offering
router.patch('/:id/toggle', csrfProtect, async (req, res, next) => {
  try {
    const { offered } = req.body;
    if (typeof offered !== 'boolean') {
      throw httpError(400, 'offered must be a boolean.');
    }

    const offering = await SubjectOffering.findById(req.params.id)
      .populate('course', 'code name')
      .populate('subject', 'subjectCode subjectName')
      .populate('semester', 'academicYear term');

    if (!offering) throw httpError(404, 'Subject offering not found.');

    offering.offered = offered;
    offering.updatedBy = req.user._id;
    await offering.save();

    await logActivity({
      performedBy: req.user._id,
      category: 'Subject Offering',
      action: offered ? 'Subject offered' : 'Subject withdrawn',
      description: `${offering.subject.subjectCode} (${offering.subject.subjectName}) ${offered ? 'offered' : 'withdrawn'} for ${offering.semester.academicYear} ${offering.semester.term}, Year ${offering.yearLevel}.`
    });

    res.json({ message: `Subject ${offered ? 'offered' : 'withdrawn'} successfully.`, offering: present(offering) });
  } catch (err) { next(err); }
});

module.exports = router;