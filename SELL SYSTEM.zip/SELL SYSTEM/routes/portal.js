const express=require('express');
const Student=require('../models/Student');
const Instructor=require('../models/Instructor');
const Enrollment=require('../models/Enrollment');
const Schedule=require('../models/Schedule');
const {requireAuth,requireRole}=require('../middleware/auth');
const {httpError}=require('../utils/validation');
const {getSettings}=require('../services/settingsService');
const router=express.Router();router.use(requireAuth,requireRole('Student','Instructor'));

async function studentProfile(userId){const s=await Student.findOne({user:userId}).populate('course').lean();if(!s)throw httpError(404,'Student profile not found.');return s;}
async function instructorProfile(userId){const i=await Instructor.findOne({user:userId}).lean();if(!i)throw httpError(404,'Instructor profile not found.');return i;}

async function studentEnrollments(studentId){return Enrollment.find({student:studentId,status:'Active'}).populate('subject').populate({path:'schedule',populate:[{path:'subject'},{path:'room'},{path:'course'},{path:'instructor',populate:{path:'user',select:'username'}}]}).sort({createdAt:1}).lean();}
async function instructorSchedules(instructorId){return Schedule.find({instructor:instructorId,status:'Active'}).populate('subject room course').populate({path:'instructor',populate:{path:'user',select:'username'}}).sort({startTime:1}).lean();}

router.get('/dashboard',async(req,res,next)=>{try{
  const settings=await getSettings();
  const ui={dayStart:settings.dayStart,dayEnd:settings.dayEnd};
  if(req.user.role==='Student'){
    const student=await studentProfile(req.user._id);const enrollments=await studentEnrollments(student._id);return res.json({role:'Student',profile:student,totalSubjects:enrollments.length,schedules:enrollments.map(e=>e.schedule).filter(Boolean).slice(0,8),settings:ui});
  }
  const instructor=await instructorProfile(req.user._id);const schedules=await instructorSchedules(instructor._id);const ids=schedules.map(s=>s._id);const totalStudents=(await Enrollment.distinct('student',{schedule:{$in:ids},status:'Active'})).length;res.json({role:'Instructor',profile:instructor,totalSubjects:new Set(schedules.map(s=>String(s.subject._id))).size,totalSchedules:schedules.length,totalStudents,schedules:schedules.slice(0,8),settings:ui});
}catch(e){next(e);}});

router.get('/my-subjects',async(req,res,next)=>{try{
  if(req.user.role==='Student'){const s=await studentProfile(req.user._id);return res.json(await studentEnrollments(s._id));}
  const i=await instructorProfile(req.user._id);const schedules=await instructorSchedules(i._id);res.json(schedules);
}catch(e){next(e);}});

router.get('/my-schedule',async(req,res,next)=>{try{
  if(req.user.role==='Student'){const s=await studentProfile(req.user._id);const rows=await studentEnrollments(s._id);return res.json(rows.map(e=>e.schedule).filter(Boolean));}
  const i=await instructorProfile(req.user._id);res.json(await instructorSchedules(i._id));
}catch(e){next(e);}});

module.exports=router;
