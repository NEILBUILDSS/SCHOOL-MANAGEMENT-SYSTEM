﻿const express = require('express');
const bcrypt = require('bcryptjs');
const Student = require('../models/Student');
const Enrollment = require('../models/Enrollment');
const User = require('../models/User');
const Course = require('../models/Course');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { createPersonAccount } = require('../services/accountService');
const { logActivity } = require('../services/logService');
const {
  escapeRegex,
  httpError,
  required,
  clean,
  validateEmail,
  validatePassword
} = require('../utils/validation');

const router = express.Router();

router.use(requireAuth, requireRole('Admin'));


// =========================================================
// GET ALL STUDENTS
// =========================================================

router.get('/', async (req, res, next) => {
  try {
    const filter = {};

    if (
      req.query.status &&
      ['Active', 'Inactive'].includes(req.query.status)
    ) {
      filter.status = req.query.status;
    }

    if (
      req.query.year &&
      [1, 2, 3, 4].includes(Number(req.query.year))
    ) {
      filter.yearLevel = Number(req.query.year);
    }

    if (req.query.course) {
      const course = await Course.findOne({
        code: String(req.query.course).toUpperCase()
      }).lean();

      if (course) {
        filter.course = course._id;
      } else {
        filter.course = null;
      }
    }

    if (req.query.semester && /^[a-f\d]{24}$/i.test(String(req.query.semester))) {
      // Students who have an enrollment in the chosen semester.
      filter._id = { $in: await Enrollment.distinct('student', { semester: req.query.semester }) };
    }

    if (req.query.q) {
      const rx = new RegExp(
        escapeRegex(req.query.q.trim()),
        'i'
      );

      filter.$or = [
        { studentId: rx },
        { firstName: rx },
        { middleName: rx },
        { lastName: rx }
      ];
    }

    const sort =
      req.query.sort === 'lastname'
        ? {
            lastName: 1,
            firstName: 1,
            yearLevel: 1
          }
        : {
            yearLevel: 1,
            lastName: 1,
            firstName: 1
          };

    const students = await Student.find(filter)
      .populate('user', 'email username status')
      .populate('course', 'code name')
      .sort(sort)
      .lean();

    res.json(students);
  } catch (err) {
    next(err);
  }
});


// =========================================================
// CREATE STUDENT
// =========================================================

router.post('/', csrfProtect, async (req, res, next) => {
  try {
    const user = await createPersonAccount({
      role: 'Student',
      data: req.body,
      actorUserId: req.user._id
    });

    const student = await Student.findOne({
      user: user._id
    })
      .populate('user', 'email username')
      .populate('course')
      .lean();

    res.status(201).json(student);
  } catch (err) {
    next(err);
  }
});


// =========================================================
// GET ONE STUDENT + ENROLLMENTS
// =========================================================

router.get('/:id', async (req, res, next) => {
  try {
    const student = await Student.findById(req.params.id)
      .populate(
        'user',
        'email username status createdAt'
      )
      .populate('course')
      .lean();

    if (!student) {
      throw httpError(404, 'Student not found.');
    }

    const enrollments = await Enrollment.find({
      student: student._id
    })
      .populate('subject')
      .populate('semester')
      .populate({
        path: 'schedule',
        populate: [
          { path: 'subject' },
          { path: 'room' },
          { path: 'course' },
          {
            path: 'instructor',
            populate: {
              path: 'user',
              select: 'email username'
            }
          }
        ]
      })
      .sort({ updatedAt: -1 })
      .lean();

    res.json({
      student,
      enrollments
    });
  } catch (err) {
    next(err);
  }
});


// =========================================================
// UPDATE STUDENT (Admin)
// =========================================================

router.patch('/:id', csrfProtect, async (req, res, next) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) throw httpError(404, 'Student not found.');
    const user = await User.findById(student.user);
    if (!user) throw httpError(404, 'Student account not found.');

    if (req.body.studentId !== undefined) {
      const studentId = required(req.body.studentId, 'Student ID', 50).toUpperCase();
      if (await Student.exists({ studentId, _id: { $ne: student._id } })) throw httpError(409, 'Student ID is already in use.');
      student.studentId = studentId;
    }
    if (req.body.firstName !== undefined) student.firstName = required(req.body.firstName, 'First name', 80);
    if (req.body.middleName !== undefined) student.middleName = clean(req.body.middleName, 80);
    if (req.body.lastName !== undefined) student.lastName = required(req.body.lastName, 'Last name', 80);
    if (req.body.contactNumber !== undefined) student.contactNumber = required(req.body.contactNumber, 'Contact number', 40);
    if (req.body.course !== undefined) {
      const course = await Course.findOne({ code: String(req.body.course).toUpperCase(), status: 'Active' });
      if (!course) throw httpError(400, 'Select a valid active course.');
      if (await Enrollment.exists({ student: student._id, status: 'Active' }) && String(student.course) !== String(course._id)) {
        throw httpError(409, 'Drop or complete the student\'s active enrollments before changing the course.');
      }
      student.course = course._id;
    }
    if (req.body.yearLevel !== undefined) {
      const year = Number(req.body.yearLevel);
      if (![1, 2, 3, 4].includes(year)) throw httpError(400, 'Year level must be 1 to 4.');
      if (await Enrollment.exists({ student: student._id, status: 'Active' }) && Number(student.yearLevel) !== year) {
        throw httpError(409, 'Drop or complete the student\'s active enrollments before changing the year level.');
      }
      student.yearLevel = year;
    }
    if (req.body.status !== undefined) {
      if (!['Active', 'Inactive'].includes(req.body.status)) throw httpError(400, 'Status must be Active or Inactive.');
      student.status = req.body.status;
      user.status = req.body.status;
    }
    if (req.body.email !== undefined) user.email = validateEmail(req.body.email);
    if (req.body.password) user.passwordHash = await bcrypt.hash(validatePassword(req.body.password), 12);

    await student.save();
    await user.save();
    await logActivity({
      performedBy: req.user._id,
      category: 'Student',
      action: 'Student updated',
      description: `Updated student ${student.studentId}.`
    });
    res.json({ message: 'Student updated successfully.' });
  } catch (err) {
    if (err.code === 11000) return next(httpError(409, 'That student ID or email is already in use.'));
    next(err);
  }
});

module.exports = router;
