const express = require('express');
const Schedule = require('../models/Schedule');
const Subject = require('../models/Subject');
const SubjectOffering = require('../models/SubjectOffering');
const Room = require('../models/Room');
const Course = require('../models/Course');
const Semester = require('../models/Semester');
const Prospectus = require('../models/Prospectus');
const Instructor = require('../models/Instructor');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { httpError, validateTime } = require('../utils/validation');
const { withSchedulingLock, minutes, overlaps, sameDay, evaluateRoomTimeWindow, dailyLimitMinutesFrom, loadRoomSemesterSchedules } = require('../services/schedulingService');
// schedulingModule.js already declares its own time12() helper below, so only
// the settings helpers are imported here.
const { getSettings, sessionMinutesFor, breakCollision, patternKeyFor, plannedSectionSize } = require('../services/settingsService');
const { instructorWorkloads, roomDemand } = require('../services/workloadService');
const { suggestions } = require('../services/optimizerService');
const { logActivity } = require('../services/logService');
const { getCurrentSemester, listSemesters } = require('../services/semesterService');

// Schedule plotting lives inside the Rooms module.
// Rooms > Schedule Plotting: pick subject / course / section / day / time, the API
// lists the rooms free for that slot and POST /assign writes the schedule. A
// successful assignment also marks the subject as offered for that section, so
// plotting is the single scheduling step - there is no separate offering page.

const router = express.Router();
router.use(requireAuth, requireRole('Admin'));

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const DAY_FULL = { Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday' };
// The day options the plotting form offers. A pattern expands to its weekday list
// so one dropdown value can still mean "Monday, Wednesday & Friday".
const DAY_PATTERNS = {
  MWF: ['Mon', 'Wed', 'Fri'],
  TTH: ['Tue', 'Thu'],
  F: ['Fri'],
  SATURDAY: ['Sat'],
  SUNDAY: ['Sun']
};

// Accepts a pattern key ("MWF"), a full-name list ("Monday, Wednesday, Friday"),
// a short list ("Mon,Wed,Fri") or a single day ("Sat"). Every accepted spelling
// is normalized to the stored three-letter day. Returns [] when nothing in it
// names a real class day.
const DAY_ALIASES = { Monday: 'Mon', Tuesday: 'Tue', Wednesday: 'Wed', Thursday: 'Thu', Friday: 'Fri', Saturday: 'Sat', Sunday: 'Sun' };
function resolveDays(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return [];
  const pattern = DAY_PATTERNS[raw.toUpperCase()];
  if (pattern) return [...pattern];
  const parts = [...new Set(raw.split(',').map(part => part.trim()).filter(Boolean))];
  const mapped = parts.map(part =>
    (DAYS.includes(part) ? part : null)
      || DAY_ALIASES[part.charAt(0).toUpperCase() + part.slice(1).toLowerCase()]
      || DAYS.find(d => d.toUpperCase() === part.toUpperCase())
      || null
  );
  if (mapped.length && mapped.every(Boolean)) return [...new Set(mapped)];
  return [];
}

const sectionKeyOf = SubjectOffering.sectionKeyOf;
const parseSectionKey = SubjectOffering.parseSectionKey;
const sectionLabel = SubjectOffering.sectionLabel;

function oid(value, label) {
  const v = String(value ?? '').trim();
  if (!/^[a-f0-9]{24}$/i.test(v)) throw httpError(400, `Choose a valid ${label}.`);
  return v;
}

function semesterTag(semester) {
  return semester ? `${semester.academicYear} ${semester.term}` : '';
}

function time12(value) {
  if (!value) return ' - ';
  const [h, m] = String(value).split(':').map(Number);
  const suffix = h >= 12 ? 'PM' : 'AM';
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${suffix}`;
}

// Accepts "HH:MM" (24-hour), a bare "7:30", or forms like "10:30 AM" / "7:30pm"
// and returns strict "HH:MM", so every comparison downstream works on minutes
// instead of on strings.
function normalizeTime(value, label) {
  const raw = String(value ?? '').trim();
  const ampm = raw.match(/^(\d{1,2}):(\d{2})\s*([AaPp])\.?[Mm]\.?$/);
  if (ampm) {
    let h = Number(ampm[1]) % 12;
    if (ampm[3].toLowerCase() === 'p') h += 12;
    return validateTime(`${String(h).padStart(2, '0')}:${ampm[2]}`, label);
  }
  const padded = /^\d{1,2}:\d{2}$/.test(raw) ? raw.padStart(5, '0') : raw;
  return validateTime(padded, label);
}

function personName(p) {
  if (!p) return '';
  return [p.firstName, p.middleName, p.lastName].filter(Boolean).join(' ');
}

// Reads the shared planning context (school year + semester + program + section)
// and rebuilds sectionKey on the server so the client cannot forge one.
function readContext(src) {
  const semester = oid(src.semester, 'school year and semester');
  const course = oid(src.course, 'program');
  const parsed = parseSectionKey(src.sectionKey);
  if (!parsed) throw httpError(400, 'Choose a valid section.');
  return {
    semester,
    course,
    ...parsed,
    sectionKey: sectionKeyOf(parsed.sectionType, parsed.blockLabel, parsed.yearLevel),
    label: sectionLabel(parsed.sectionType, parsed.blockLabel, parsed.yearLevel)
  };
}

// A Schedule carries course / room / instructor either as a raw id or, once
// populated, as a document. Normalise both shapes so a comparison never depends
// on which side happened to be populated - treating a raw id as a document
// silently stringifies to "undefined" and the match never fires.
const refId = value => (value && typeof value === 'object' && value._id ? String(value._id) : String(value ?? ''));

// Section identity as stored on a Schedule. Legacy rows predate the sectionType
// field, so a missing value is the schema's own default ('Open') rather than a
// section of its own. Without this those classes stay invisible to every
// conflict check while still occupying rooms and time.
const normSectionType = value => (value === 'Block' ? 'Block' : 'Open');
const normBlockLabel = value => String(value || '').trim().toUpperCase();

function isSameSection(a, b) {
  return refId(a.course) === refId(b.course)
    && Number(a.yearLevel) === Number(b.yearLevel)
    && normSectionType(a.sectionType) === normSectionType(b.sectionType)
    && normBlockLabel(a.blockLabel) === normBlockLabel(b.blockLabel);
}

function hhmm(total) {
  const t = Math.round(total);
  return `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`;
}

// Session length for a subject on a day pattern. Split out from planSession so
// the availability probe can learn the length before it has chosen a start time.
function sessionLengthFor(subject, settings, weekdays) {
  const pattern = patternKeyFor(weekdays);
  const session = sessionMinutesFor(settings, pattern, subject.units, weekdays.length);
  if (session.error) return { error: session.error };
  return { pattern, minutes: session.minutes, source: session.source };
}

// Session shape for one plotted class: its length, its end time and whether the
// start time is legal at all under the window, break and duration rules.
//
// This is the single source of truth for those rules. POST /assign, the room
// availability probe and the schedule editor all route through it, so a slot the
// registrar is offered is by construction a slot the writer will accept.
function planSession(subject, settings, startTime, weekdays) {
  const len = sessionLengthFor(subject, settings, weekdays);
  if (len.error) return len;

  const start = minutes(startTime);
  const end = start + len.minutes;
  if (start < minutes(settings.dayStart) || end > minutes(settings.dayEnd)) {
    return { error: `Classes must run between ${time12(settings.dayStart)} and ${time12(settings.dayEnd)}. Choose an earlier start time.` };
  }
  const endTime = hhmm(end);

  const breakHit = breakCollision(settings, startTime, endTime);
  if (breakHit) {
    return { error: `This class would run through the ${breakHit.label} break (${time12(breakHit.startTime)} - ${time12(breakHit.endTime)}). Choose a start time that clears the break.` };
  }

  if (subject.laboratoryRequired) {
    if (len.minutes < 60 || len.minutes > 180) {
      return { error: 'Laboratory classes must last 60 to 180 minutes in 30-minute increments.' };
    }
  } else if (len.minutes < 30 || len.minutes > 360) {
    return { error: 'Class sessions must last 30 to 360 minutes.' };
  }

  return { pattern: len.pattern, minutes: len.minutes, source: len.source, start, end, endTime };
}

// Schedules without a semester belong to the period they were made for, so they
// only block rooms while the registrar is planning for the current semester.
async function semesterScheduleFilter(semesterId) {
  const current = await getCurrentSemester();
  if (current && String(current._id) === String(semesterId)) return { $or: [{ semester: semesterId }, { semester: null }] };
  return { semester: semesterId };
}

// ---------------------------------------------------------------- shared meta
router.get('/meta', async (req, res, next) => { try {
  const [semesters, courses, rooms, instructors] = await Promise.all([
    listSemesters(),
    Course.find({ status: 'Active' }).sort({ code: 1 }).lean(),
    Room.find({ status: 'Active' }).sort({ roomCode: 1 }).lean(),
    Instructor.find({ status: 'Active' }).select('firstName middleName lastName').sort({ lastName: 1, firstName: 1 }).lean()
  ]);
  res.json({
    semesters: semesters.map(s => ({ _id: s._id, academicYear: s.academicYear, term: s.term, label: semesterTag(s), isCurrent: !!s.isCurrent })),
    courses: courses.map(c => ({ _id: c._id, code: c.code, name: c.name })),
    rooms: rooms.map(r => ({ _id: r._id, roomCode: r.roomCode, roomName: r.roomName, roomType: r.roomType, capacity: r.capacity })),
    instructors: instructors.map(i => ({ _id: i._id, name: personName(i) }))
  });
} catch (e) { next(e); } });

// ------------------------------------------------------------- section picker
router.get('/sections', async (req, res, next) => { try {
  const semesterId = oid(req.query.semester, 'semester');
  const courseId = oid(req.query.course, 'program');
  const semester = await Semester.findById(semesterId).lean();
  if (!semester) throw httpError(404, 'Semester not found.');
  if (!await Course.exists({ _id: courseId })) throw httpError(404, 'Program not found.');

  const [schedules, offerings] = await Promise.all([
    Schedule.find({ course: courseId, semester: semesterId }).select('yearLevel sectionType blockLabel').lean(),
    SubjectOffering.find({ course: courseId, semester: semesterId }).select('yearLevel sectionType blockLabel').lean()
  ]);

  const map = new Map();
  const add = (yearLevel, sectionType, blockLabel) => {
    const year = Number(yearLevel);
    if (![1, 2, 3, 4].includes(year)) return;
    const label = sectionType === 'Block' ? String(blockLabel || '').trim() : '';
    const key = sectionKeyOf(sectionType, label, year);
    if (map.has(key)) return;
    map.set(key, { key, yearLevel: year, sectionType, blockLabel: label, label: sectionLabel(sectionType, label, year) });
  };

  [1, 2, 3, 4].forEach(y => add(y, 'Open', ''));
  [...schedules, ...offerings].forEach(x => add(x.yearLevel, x.sectionType, x.blockLabel));

  const sections = [...map.values()].sort((a, b) => a.yearLevel - b.yearLevel || a.label.localeCompare(b.label));
  res.json({ semester: { _id: semester._id, label: semesterTag(semester) }, sections });
} catch (e) { next(e); } });

// --------------------------------------------------------- 1. Subject Offering
router.get('/offerings', async (req, res, next) => { try {
  const ctx = readContext(req.query);
  const semester = await Semester.findById(ctx.semester).lean();
  if (!semester) throw httpError(404, 'Semester not found.');
  if (!await Course.exists({ _id: ctx.course })) throw httpError(404, 'Program not found.');

  // Subjects come from the course prospectus for this year level and term so the
  // registrar only ever sees the subjects that belong in this section.
  let subjects = [];
  let source = 'course';
  const prospectus = await Prospectus.findOne({ course: ctx.course, status: 'Active' }).lean();
  if (prospectus) {
    const ids = prospectus.items
      .filter(item => Number(item.yearLevel) === ctx.yearLevel && item.term === semester.term)
      .map(item => item.subject);
    if (ids.length) {
      subjects = await Subject.find({ _id: { $in: ids }, course: ctx.course, status: 'Active' }).sort({ subjectCode: 1 }).lean();
      source = 'prospectus';
    }
  }
  if (!subjects.length) subjects = await Subject.find({ course: ctx.course, status: 'Active' }).sort({ subjectCode: 1 }).lean();

  const rows = await SubjectOffering.find({ semester: ctx.semester, course: ctx.course, sectionKey: ctx.sectionKey }).lean();
  const flags = new Map(rows.map(r => [String(r.subject), !!r.offered]));

  res.json({
    section: { key: ctx.sectionKey, yearLevel: ctx.yearLevel, sectionType: ctx.sectionType, blockLabel: ctx.blockLabel, label: ctx.label },
    semester: { _id: semester._id, label: semesterTag(semester) },
    source,
    subjects: subjects.map(s => ({
      _id: s._id,
      subjectCode: s.subjectCode,
      subjectName: s.subjectName,
      units: s.units,
      laboratoryRequired: !!s.laboratoryRequired,
      offered: flags.has(String(s._id)) ? flags.get(String(s._id)) : false
    }))
  });
} catch (e) { next(e); } });

// Every Active schedule that could possibly collide with a candidate on these
// days in this semester. The query narrows, and classification happens in
// memory, so a whole availability sweep costs one round trip.
async function blockingSchedules(candidate) {
  const filter = { status: 'Active', weekdays: { $in: candidate.weekdays }, ...await semesterScheduleFilter(candidate.semester) };
  return Schedule.find(filter)
    .populate('subject', 'subjectCode subjectName')
    .populate('room', 'roomCode roomName')
    .populate('course', 'code name')
    .populate({ path: 'instructor', select: 'firstName middleName lastName' })
    .lean();
}

// Detailed conflicts so the UI can show the exact "Room Conflict" warning the
// registrar needs: room, instructor and section are checked separately.
// `excludeId` lets an update ignore the schedule it is editing.
//
// Split out from detectConflicts so the availability probe can classify a whole
// day's worth of candidate slots against one pre-fetched list instead of
// re-querying per slot - the rules stay identical by construction.
function classifyConflicts(candidate, others, excludeId) {
  const found = [];
  for (const other of others) {
    if (excludeId && String(other._id) === String(excludeId)) continue;
    if (!sameDay(candidate.weekdays, other.weekdays)) continue;
    if (!overlaps(candidate.startTime, candidate.endTime, other.startTime, other.endTime)) continue;

    const shared = candidate.weekdays.filter(d => other.weekdays.includes(d));
    const detail = {
      scheduleId: other._id,
      subject: other.subject ? `${other.subject.subjectCode} - ${other.subject.subjectName}` : ' - ',
      room: other.room ? other.room.roomCode : ' - ',
      roomName: other.room ? other.room.roomName : '',
      section: sectionLabel(normSectionType(other.sectionType), other.blockLabel, other.yearLevel),
      program: other.course ? `${other.course.code} - ${other.course.name}` : ' - ',
      instructor: personName(other.instructor) || 'TBA',
      days: shared.map(d => DAY_FULL[d]).join(', '),
      time: `${time12(other.startTime)} - ${time12(other.endTime)}`
    };

    if (refId(other.room) === refId(candidate.room)) {
      found.push({ type: 'room', title: 'Room Conflict', message: `${detail.room} is already occupied.`, detail });
    }
    if (candidate.instructor && other.instructor && refId(other.instructor) === refId(candidate.instructor)) {
      found.push({ type: 'instructor', title: 'Instructor Conflict', message: `${detail.instructor} already teaches at that time.`, detail });
    }
    if (isSameSection(candidate, other)) {
      found.push({ type: 'section', title: 'Section Conflict', message: `${detail.section} already has a class at that time.`, detail });
    }
  }
  return found;
}

async function detectConflicts(candidate, excludeId) {
  return classifyConflicts(candidate, await blockingSchedules(candidate), excludeId);
}

// Shared write path for creating and editing a plotted assignment.
// `opts.excludeId` switches the function into update mode: the stored schedule
// supplies any field the caller did not send, and it is skipped by the conflict
// check so a schedule never collides with itself.
async function createPlottedSchedule(body, userId, opts) {
  const options = opts || {};
  const excludeId = options.excludeId || null;
  const base = excludeId ? await Schedule.findById(excludeId).lean() : null;
  if (excludeId && !base) throw httpError(404, 'Schedule not found.');
  const merged = Object.assign({}, base ? {
    semester: base.semester,
    course: base.course,
    yearLevel: base.yearLevel,
    sectionType: base.sectionType,
    blockLabel: base.blockLabel,
    subject: base.subject,
    room: base.room,
    weekdays: base.weekdays,
    startTime: base.startTime,
    instructor: base.instructor
  } : {}, body || {});
  // A Schedule row stores the section as yearLevel + sectionType + blockLabel,
  // while readContext expects the offering's sectionKey, so rebuild it whenever
  // the caller did not send one.
  if (!merged.sectionKey) {
    merged.sectionKey = sectionKeyOf(merged.sectionType, merged.blockLabel, merged.yearLevel);
  }

  const ctx = readContext(merged);
  const subjectId = oid(merged.subject, 'subject');
  const roomId = oid(merged.room, 'room');

  const weekdays = Array.isArray(merged.weekdays) ? [...new Set(merged.weekdays.map(d => String(d).trim()))] : [];
  if (!weekdays.length || weekdays.some(d => !DAYS.includes(d))) {
    throw httpError(400, 'Choose at least one class day.');
  }
  const startTime = validateTime(merged.startTime, 'Start time');

  const [subject, room] = await Promise.all([Subject.findById(subjectId).lean(), Room.findById(roomId).lean()]);
  if (!subject || subject.status !== 'Active') throw httpError(400, 'Select a valid active subject.');
  if (String(subject.course) !== String(ctx.course)) throw httpError(400, 'That subject does not belong to the selected program.');
  if (!room) throw httpError(404, 'Room not found.');
  if (room.status !== 'Active') throw httpError(400, 'Select a valid active room.');

  // The timetable is derived, not typed: the day pattern fixes the session
  // length (MWF = 1 hour, TTh = 1.5 hours) and the end time follows the start.
  // planSession owns the window, break and duration rules, so the plotting
  // screen can never offer a slot the writer would then reject.
  const settings = await getSettings();
  const requiredSeats = plannedSectionSize(settings);
  if (subject.laboratoryRequired && room.roomType !== 'Laboratory') {
    throw httpError(400, 'Laboratory subjects must use a laboratory room.');
  }
  if (room.capacity < requiredSeats) {
    throw httpError(400, `Room ${room.roomCode} has only ${room.capacity} seats; this section is planned for ${requiredSeats}.`);
  }
  const plan = planSession(subject, settings, startTime, weekdays);
  if (plan.error) throw httpError(400, plan.error);
  const duration = plan.minutes;
  const endTime = plan.endTime;

  let instructor = null;
  if (merged.instructor) {
    const found = await Instructor.findById(oid(merged.instructor, 'instructor')).lean();
    if (!found || found.status !== 'Active') throw httpError(400, 'Select a valid active instructor.');
    instructor = found._id;
  }

  const candidate = {
    subject: subject._id,
    room: room._id,
    instructor,
    weekdays,
    startTime,
    endTime,
    course: ctx.course,
    yearLevel: ctx.yearLevel,
    sectionType: ctx.sectionType,
    blockLabel: ctx.blockLabel,
    semester: ctx.semester,
    status: 'Active'
  };

  return withSchedulingLock(async () => {
    const conflicts = await detectConflicts(candidate, excludeId);
    if (conflicts.length) return { conflicts };
    // The room itself is re-checked HERE, inside the scheduling lock, against the
    // data as it is right now: it must still be Active, the slot must still be
    // free of overlapping classes in this semester, and the room's day must stay
    // inside the configured daily class-hour limit (settings.dailyTargetHours).
    // The availability answers in POST /assign and /rooms/available ran before
    // this lock was acquired, so only this recheck is authoritative.
    const freshRoom = await Room.findById(room._id).lean();
    if (!freshRoom || freshRoom.status !== 'Active') {
      throw httpError(409, `Room ${room.roomCode} is no longer available.`);
    }
    if (subject.laboratoryRequired && freshRoom.roomType !== 'Laboratory') {
      throw httpError(409, `Room ${freshRoom.roomCode} is no longer a laboratory room.`);
    }
    if (freshRoom.capacity < requiredSeats) {
      throw httpError(409, `Room ${freshRoom.roomCode} now has only ${freshRoom.capacity} seats; this section is planned for ${requiredSeats}.`);
    }
    const ownSchedules = await loadRoomSemesterSchedules(room._id, candidate.semester, excludeId);
    const usage = evaluateRoomTimeWindow(ownSchedules, weekdays, startTime, endTime, dailyLimitMinutesFrom(settings));
    if (!usage.ok) {
      throw httpError(409, `Room ${room.roomCode}: ${usage.reason}`);
    }
    if (excludeId) {
      await Schedule.updateOne({ _id: excludeId }, { $set: candidate });
      return { schedule: excludeId };
    }
    const created = await Schedule.create(candidate);
    // Plotting is the only scheduling step now, so a successful assignment also
    // records the subject as offered for this section. Failed attempts never
    // reach here, so nothing is marked offered by a rejected assignment.
    await SubjectOffering.updateOne(
      { semester: ctx.semester, course: ctx.course, sectionKey: ctx.sectionKey, subject: subject._id },
      { $set: { yearLevel: ctx.yearLevel, sectionType: ctx.sectionType, blockLabel: ctx.blockLabel, offered: true, updatedBy: userId } },
      { upsert: true }
    );
    return { schedule: created._id };
  });
}

router.post('/assign', csrfProtect, async (req, res, next) => { try {
  const result = await createPlottedSchedule(req.body || {}, req.user._id);
  if (result.conflicts) {
    return res.status(409).json({ message: result.conflicts[0].message, conflicts: result.conflicts });
  }
  const schedule = await hydratedSchedule(result.schedule);

  await logActivity({
    performedBy: req.user._id,
    category: 'Scheduling',
    action: 'Assign subject',
    description: `Plotted ${schedule.subject.subjectCode} in ${schedule.room.roomCode} on ${schedule.weekdays.map(d => DAY_FULL[d]).join(', ')} at ${time12(schedule.startTime)}.`
  });
  res.status(201).json({ schedule });
} catch (e) { next(e); } });

// Shared hydration used by the plotting response and the room record.
async function hydratedSchedule(id) {
  return Schedule.findById(id)
    .populate('subject', 'subjectCode subjectName units')
    .populate('room', 'roomCode roomName roomType')
    .populate('course', 'code name')
    .populate({ path: 'instructor', select: 'firstName middleName lastName' })
    .lean();
}

// Editing from the room record re-runs every check, so an edit can never sneak a
// conflict past the plotting screen.
router.patch('/schedules/:id', csrfProtect, async (req, res, next) => { try {
  const scheduleId = oid(req.params.id, 'schedule');
  const result = await createPlottedSchedule(req.body || {}, req.user._id, { excludeId: scheduleId });
  if (result.conflicts) {
    return res.status(409).json({ message: result.conflicts[0].message, conflicts: result.conflicts });
  }
  const schedule = await hydratedSchedule(scheduleId);
  await logActivity({
    performedBy: req.user._id,
    category: 'Scheduling',
    action: 'Update assignment',
    description: `Updated ${schedule.subject.subjectCode} in ${schedule.room.roomCode} on ${schedule.weekdays.map(d => DAY_FULL[d]).join(', ')} at ${time12(schedule.startTime)}.`
  });
  res.json({ schedule });
} catch (e) { next(e); } });

router.delete('/schedules/:id', csrfProtect, async (req, res, next) => { try {
  const scheduleId = oid(req.params.id, 'schedule');
  const schedule = await hydratedSchedule(scheduleId);
  if (!schedule) throw httpError(404, 'Schedule not found.');
  await Schedule.deleteOne({ _id: scheduleId });
  await logActivity({
    performedBy: req.user._id,
    category: 'Scheduling',
    action: 'Remove assignment',
    description: `Removed ${schedule.subject ? schedule.subject.subjectCode : 'a class'} from ${schedule.room ? schedule.room.roomCode : 'a room'}.`
  });
  res.json({ removed: scheduleId });
} catch (e) { next(e); } });

// --------------------------------------------------------- 3. Room Assignment
// Availability answers two questions: which start times fit the selected class,
// and which rooms are free for the chosen start. A room only drops off the list
// when it is occupied for an overlapping interval, is the wrong type for a
// laboratory subject, is smaller than the planned section, or would exceed the
// room's daily class-hour limit. Section and instructor clashes remove start
// times too, so the dropdown and the save path agree.
router.get('/rooms/available', async (req, res, next) => { try {
  const semesterId = oid(req.query.semester, 'semester');
  // The form sends a day pattern ("MWF", "SATURDAY"); expand it to the exact
  // weekdays it covers so day overlap is decided on real day names, not labels.
  const days = resolveDays(req.query.day);
  if (!days.length) throw httpError(400, 'Choose a valid class day.');
  const day = String(req.query.day || '').trim();
  const settings = await getSettings();

  // Optional planning context. Anything supplied is validated here, so a bad id
  // is a clear 400 instead of an availability answer about the wrong thing.
  const course = req.query.course ? oid(req.query.course, 'program') : null;
  let section = null;
  if (req.query.sectionKey || (req.query.sectionType && req.query.yearLevel)) {
    if (!course) throw httpError(400, 'Choose a program to check a section.');
    section = readContext({
      semester: semesterId,
      course,
      sectionKey: req.query.sectionKey || sectionKeyOf(req.query.sectionType, req.query.blockLabel, Number(req.query.yearLevel)),
      sectionType: req.query.sectionType,
      blockLabel: req.query.blockLabel,
      yearLevel: req.query.yearLevel
    });
  }
  const instructor = req.query.instructor ? oid(req.query.instructor, 'instructor') : null;
  const excludeId = req.query.excludeId ? oid(req.query.excludeId, 'schedule') : null;

  let subject = null;
  if (req.query.subject) {
    subject = await Subject.findById(oid(req.query.subject, 'subject')).lean();
    if (!subject) throw httpError(404, 'Subject not found.');
  }

  const startTime = req.query.startTime ? normalizeTime(req.query.startTime, 'Start time') : null;
  // Without a subject the session length cannot be derived, so an explicit end
  // time from a legacy caller is still honoured for the single-slot answer.
  const legacyEnd = req.query.endTime ? normalizeTime(req.query.endTime, 'End time') : null;

  const dayStart = minutes(settings.dayStart);
  const dayEnd = minutes(settings.dayEnd);

  // A section is planned for the configured number of seats, so a room that is
  // physically smaller than that section cannot be offered as a complete fit.
  const requiredSeats = plannedSectionSize(settings);

  // Session length for the chosen pattern. planSession owns the rule, and an
  // unusable pattern (a unit count that cannot be split across the days, say) is
  // reported rather than guessed.
  let duration = null;
  let lengthError = null;
  if (subject) {
    const len = sessionLengthFor(subject, settings, days);
    if (len.error) lengthError = len.error;
    else duration = len.minutes;
  }

  const [rooms, others] = await Promise.all([
    Room.find({ status: 'Active' }).sort({ roomCode: 1 }).lean(),
    blockingSchedules({ weekdays: days, semester: semesterId })
  ]);

  // A room is unavailable only when all three hold for some existing schedule:
  // it is that very room, the days overlap, and the windows overlap - minute
  // math on both sides, scoped to the semester being planned. Section and
  // instructor clashes are decided from the SAME list over the SAME overlap
  // test, which is what keeps this answer equal to what POST /assign enforces.
  const evaluate = (startMin, endMin) => {
    const startStr = hhmm(startMin);
    const endStr = hhmm(endMin);
    const issues = [];
    const busyRooms = new Map();

    const breakHit = breakCollision(settings, startStr, endStr);
    if (breakHit) {
      issues.push({
        type: 'break',
        title: 'Break Conflict',
        message: `This class would run through the ${breakHit.label} break (${time12(breakHit.startTime)} - ${time12(breakHit.endTime)}).`
      });
    }

    for (const other of others) {
      if (excludeId && String(other._id) === String(excludeId)) continue;
      if (!sameDay(days, other.weekdays)) continue;
      if (!overlaps(startStr, endStr, other.startTime, other.endTime)) continue;

      busyRooms.set(refId(other.room), other);

      if (section && !issues.some(i => i.type === 'section') && isSameSection(section, other)) {
        issues.push({
          type: 'section',
          title: 'Section Conflict',
          message: `${sectionLabel(section.sectionType, section.blockLabel, section.yearLevel)} already has ${other.subject ? other.subject.subjectCode : 'another subject'} at ${time12(other.startTime)} - ${time12(other.endTime)} on ${other.weekdays.map(d => DAY_FULL[d]).join(', ')}.`,
          detail: { scheduleId: other._id, days: other.weekdays.map(d => DAY_FULL[d]).join(', '), time: `${time12(other.startTime)} - ${time12(other.endTime)}` }
        });
      }
      if (instructor && other.instructor && String(other.instructor._id) === instructor && !issues.some(i => i.type === 'instructor')) {
        issues.push({
          type: 'instructor',
          title: 'Instructor Conflict',
          message: `${personName(other.instructor)} already teaches ${other.subject ? other.subject.subjectCode : 'another subject'} at ${time12(other.startTime)} - ${time12(other.endTime)}.`
        });
      }
    }
    return { startStr, endStr, issues, busyRooms };
  };

  // Every room must clear the same rules the writer will enforce. This is used
  // both for the day-wide start-time sweep and for the selected slot, so the
  // dropdown, the room cards and POST /assign cannot disagree.
  const roomCheck = (room, slot) => {
    const clash = slot.busyRooms.get(String(room._id));
    if (clash) {
      return {
        ok: false,
        reason: 'occupied',
        message: `Occupied by ${clash.subject ? clash.subject.subjectCode : 'another class'} at ${time12(clash.startTime)} - ${time12(clash.endTime)}.`
      };
    }
    if (subject && subject.laboratoryRequired && room.roomType !== 'Laboratory') {
      return { ok: false, reason: 'room-type', message: 'Laboratory subjects need a laboratory room.' };
    }
    if (room.capacity < requiredSeats) {
      return {
        ok: false,
        reason: 'capacity',
        message: `Only ${room.capacity} seats; this section is planned for ${requiredSeats}.`
      };
    }
    // Daily class-hour limit (settings.dailyTargetHours, default 8): a room
    // with a class at this time is busy, but a room whose day still has free
    // hours stays selectable - only a day that is already full, or one this
    // session would fill past the limit, is excluded.
    const ownSchedules = others.filter(s => refId(s.room) === String(room._id) && !(excludeId && String(s._id) === String(excludeId)));
    const usage = evaluateRoomTimeWindow(ownSchedules, days, slot.startStr, slot.endStr, dailyLimitMinutesFrom(settings));
    if (!usage.ok) {
      return { ok: false, reason: 'daily-limit', message: usage.reason };
    }
    return { ok: true };
  };

  const roomPayload = room => ({
    _id: room._id,
    roomCode: room.roomCode,
    roomName: room.roomName,
    roomType: room.roomType,
    capacity: room.capacity,
    building: room.building || '',
    equipment: Array.isArray(room.equipment) ? room.equipment : []
  });

  // A start time that touches an existing class of the same section (its end
  // equals this start, or its start equals this end) is a consecutive period.
  // Those are preferred over a slot that leaves an artificial gap in the day.
  const sectionAdjacent = (startMin, endMin) => Boolean(section && others.some(other => {
    if (excludeId && String(other._id) === String(excludeId)) return false;
    if (!isSameSection(section, other) || !sameDay(days, other.weekdays)) return false;
    return minutes(other.endTime) === startMin || minutes(other.startTime) === endMin;
  }));

  // Start times the registrar may actually pick, on a 30-minute grid inside the
  // school day. Each must clear the window, the breaks, the section and the
  // instructor AND still have a room left once capacity, room type and the
  // room's daily class-hour limit are applied. The list stays chronological;
  // `recommendedStart` points at the first consecutive period when one exists.
  const validTimes = [];
  const invalidTimes = [];
  if (duration) {
    for (let s = dayStart; s + duration <= dayEnd; s += 30) {
      const startStr = hhmm(s);
      const plan = planSession(subject, settings, startStr, days);
      if (plan.error) {
        invalidTimes.push({ start: startStr, end: hhmm(s + duration), label: time12(startStr), reason: plan.error });
        continue;
      }
      const slot = evaluate(s, s + plan.minutes);
      const label = `${time12(slot.startStr)} - ${time12(slot.endStr)}`;
      if (slot.issues.length) {
        invalidTimes.push({ start: slot.startStr, end: slot.endStr, label, reason: slot.issues[0].message });
        continue;
      }
      const free = rooms.filter(room => roomCheck(room, slot).ok).length;
      if (!free) {
        invalidTimes.push({ start: slot.startStr, end: slot.endStr, label, reason: 'No room is free and suitable at this time.' });
        continue;
      }
      validTimes.push({
        start: slot.startStr,
        end: slot.endStr,
        label,
        freeRooms: free,
        consecutive: sectionAdjacent(s, s + plan.minutes)
      });
    }
  }
  const recommended = validTimes.find(slot => slot.consecutive) || validTimes[0] || null;
  const recommendedStart = recommended ? recommended.start : null;
  validTimes.forEach(slot => { slot.recommended = slot.start === recommendedStart; });

  // The slot the caller selected, if any. Its end time is derived from the same
  // session length POST /assign will use - never from the client's guess.
  let slot = null;
  let slotPlanError = null;
  if (startTime) {
    const startMin = minutes(startTime);
    const endMin = duration ? startMin + duration : (legacyEnd ? minutes(legacyEnd) : startMin);
    if (endMin <= startMin) throw httpError(400, 'End time must be after the start time.');
    slot = evaluate(startMin, endMin);
    if (subject) {
      const plan = planSession(subject, settings, startTime, days);
      if (plan.error) slotPlanError = plan.error;
    }
  }

  let slotValid = null;
  const slotIssues = slot ? slot.issues.slice() : [];
  if (slotPlanError) slotIssues.unshift({ type: 'duration', title: 'Invalid class time', message: slotPlanError });
  if (slot) slotValid = slotIssues.length === 0;

  const available = [];
  const blocked = [];
  if (slot) {
    for (const room of rooms) {
      const check = roomCheck(room, slot);
      if (!check.ok) {
        blocked.push({
          ...roomPayload(room),
          reason: check.reason,
          message: check.message
        });
        continue;
      }
      // A blocked slot has no assignable room. Reporting rooms here would tell
      // the registrar to pick one that the save is guaranteed to reject.
      if (!slotValid) continue;
      available.push(roomPayload(room));
    }
  }

  res.json({
    day, days, pattern: patternKeyFor(days),
    dayStart: settings.dayStart, dayEnd: settings.dayEnd,
    sessionMinutes: duration,
    requiredSeats,
    startTime, endTime: slot ? slot.endStr : legacyEnd,
    slotValid, slotIssues, lengthError,
    recommendedStart,
    recommendedReason: recommended && recommended.consecutive
      ? 'This period is consecutive with an existing class in the section.'
      : (recommended ? 'No consecutive period is free; the earliest valid time is suggested.' : null),
    available, blocked,
    validTimes, invalidTimes
  });
} catch (e) { next(e); } });

// ------------------------------------------------------------ Instructor load
// Read-only. Load is computed live from Active schedules - there is no stored
// total to go stale, so an instructor can never be reported fully loaded on the
// strength of a number that stopped matching reality.
router.get('/workload', async (req, res, next) => { try {
  const semester = await getCurrentSemester();
  const semesterId = req.query.semester && /^[a-f0-9]{24}$/i.test(req.query.semester)
    ? req.query.semester
    : (semester ? semester._id : null);

  const [load, demand] = await Promise.all([
    instructorWorkloads({ semesterId }),
    roomDemand({ semesterId })
  ]);

  res.json({
    semester: semester ? semesterTag(semester) : null,
    ...load,
    roomDemand: demand
  });
} catch (e) { next(e); } });

// --------------------------------------------------------------- Suggestions
// Read-only. These are proposals, not actions: the service never writes, and
// every suggestion names the constraint that has to be cleared first.
router.get('/suggestions', async (req, res, next) => { try {
  const semester = await getCurrentSemester();
  const semesterId = req.query.semester && /^[a-f0-9]{24}$/i.test(req.query.semester)
    ? req.query.semester
    : (semester ? semester._id : null);
  const result = await suggestions({ semesterId });
  res.json({ semester: semester ? semesterTag(semester) : null, ...result });
} catch (e) { next(e); } });

module.exports = router;
