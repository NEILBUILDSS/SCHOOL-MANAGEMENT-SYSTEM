const express = require('express');
const Student = require('../models/Student');
const Prospectus = require('../models/Prospectus');
const Schedule = require('../models/Schedule');
const SubjectOffering = require('../models/SubjectOffering');
const Enrollment = require('../models/Enrollment');
const { requireAuth, requireRole, csrfProtect } = require('../middleware/auth');
const { httpError } = require('../utils/validation');
const { logActivity } = require('../services/logService');
const { withSchedulingLock, validateEnrollment, overlaps, sameDay } = require('../services/schedulingService');
const { getCurrentSemester } = require('../services/semesterService');
const settingsService = require('../services/settingsService');

const router = express.Router();
router.use(requireAuth, requireRole('Student'));

const instructorLabel = i => (i && (i.firstName || i.lastName))
  ? `${i.firstName || ''} ${i.lastName || ''}`.trim()
  : 'TBA';

async function myStudent(userId) {
  const student = await Student.findOne({ user: userId }).populate('course', 'code name').lean();
  if (!student) throw httpError(404, 'Student profile not found.');
  return student;
}

async function prospectusItems(student) {
  if (!student.course) {
    throw httpError(409, 'Your student profile is incomplete. Please contact the scheduling office to assign your course.');
  }
  const p = await Prospectus.findOne({ course: student.course._id })
    .populate({
      path: 'items.subject',
      select: 'subjectCode subjectName units status prerequisites',
      populate: { path: 'prerequisites', select: 'subjectCode subjectName' }
    })
    .lean();
  return ((p && p.items) || []).filter(i => i.subject);
}

async function offeredSubjectIds(student, semesterId) {
  const rows = await SubjectOffering.find({ semester: semesterId, course: student.course._id, offered: true })
    .select('subject yearLevel sectionKey')
    .lean();
  const ids = new Set();
  for (const row of rows) {
    const year = Number.isInteger(row.yearLevel)
      ? row.yearLevel
      : (SubjectOffering.parseSectionKey(row.sectionKey) || {}).yearLevel;
    if (Number(year) !== Number(student.yearLevel)) continue;
    ids.add(String(row.subject));
  }
  return ids;
}

function enrollmentIsOpen(semester, now = new Date()) {
  if (!semester) return false;
  const end = new Date(semester.endDate);
  end.setUTCHours(23, 59, 59, 999);
  return now >= semester.startDate && now <= end;
}

async function progressBySubject(studentId, subjectIds, currentId) {
  const rows = await Enrollment.find({ student: studentId, subject: { $in: subjectIds } })
    .populate({ path: 'schedule', populate: [{ path: 'room', select: 'roomCode' }] })
    .lean();
  const map = new Map();
  for (const id of subjectIds) {
    const mine = rows.filter(r => String(r.subject) === String(id));
    const active = mine.find(r => r.status === 'Active' && String(r.semester) === String(currentId));
    let progress = 'Upcoming';
    if (mine.some(r => ['Passed', 'Credited'].includes(r.result))) {
      progress = mine.some(r => r.result === 'Credited') ? 'Credited' : 'Passed';
    } else if (active) {
      progress = 'Enrolled';
    } else if (mine.some(r => r.result === 'Failed')) {
      progress = 'Failed';
    }
    map.set(String(id), { progress, active });
  }
  return map;
}

function enrollmentRow(row) {
  return {
    _id: row._id,
    subject: row.subject,
    semester: row.semester,
    status: row.status,
    result: row.result,
    grade: row.grade,
    schedule: row.schedule ? {
      _id: row.schedule._id,
      weekdays: row.schedule.weekdays,
      startTime: row.schedule.startTime,
      endTime: row.schedule.endTime,
      room: row.schedule.room?.roomCode || '',
      instructor: instructorLabel(row.schedule.instructor)
    } : null
  };
}

const enrollmentPopulate = [
  { path: 'subject', select: 'subjectCode subjectName units' },
  { path: 'semester', select: 'academicYear term startDate endDate' },
  {
    path: 'schedule',
    populate: [
      { path: 'room', select: 'roomCode' },
      { path: 'instructor', select: 'firstName lastName' }
    ]
  }
];

router.get('/enrollments', async (req, res, next) => {
  try {
    const student = await myStudent(req.user._id);
    const rows = await Enrollment.find({ student: student._id })
      .populate(enrollmentPopulate)
      .sort({ createdAt: -1 })
      .lean();
    res.json(rows.map(enrollmentRow));
  } catch (err) { next(err); }
});

router.get('/enrollments/:id', async (req, res, next) => {
  try {
    const student = await myStudent(req.user._id);
    const row = await Enrollment.findOne({ _id: req.params.id, student: student._id })
      .populate(enrollmentPopulate)
      .lean();
    if (!row) throw httpError(404, 'Enrollment not found.');
    res.json(enrollmentRow(row));
  } catch (err) { next(err); }
});

// Everything the Enrollment page needs in one call: the student's curriculum
// for this term, which subjects are offered, every plotted section with live
// seat counts, and the student's progress against prerequisites.
router.get('/enrollment-form', async (req, res, next) => {
  try {
    const student = await myStudent(req.user._id);
    const current = await getCurrentSemester();
    if (!current) throw httpError(409, 'No semester is available yet.');
    const term = current.term;

    const curriculum = await prospectusItems(student);
    const items = curriculum.filter(i => i.yearLevel === student.yearLevel && i.term === term);
    const ids = [...new Set(curriculum.flatMap(i => [i.subject._id, ...(i.subject.prerequisites || []).map(p => p._id)]))];
    const progress = await progressBySubject(student._id, ids, current._id);
    const offeredIds = await offeredSubjectIds(student, current._id);

    const sectionsBySubject = new Map();
    if (items.length) {
      const schedules = await Schedule.find({
        subject: { $in: items.map(i => i.subject._id) },
        course: student.course._id,
        yearLevel: student.yearLevel,
        $or: [{ semester: current._id }, { semester: null }, { semester: { $exists: false } }]
      })
        .populate('subject', 'status')
        .populate('room', 'roomCode capacity status')
        .populate('instructor', 'firstName lastName status')
        .sort({ startTime: 1 })
        .lean();

      const counts = await Enrollment.aggregate([
        { $match: { schedule: { $in: schedules.map(s => s._id) }, status: 'Active' } },
        { $group: { _id: '$schedule', n: { $sum: 1 } } }
      ]);
      const taken = new Map(counts.map(c => [String(c._id), c.n]));
      const settings = await settingsService.getSettings();

      for (const s of schedules) {
        const subjectId = String(s.subject && s.subject._id ? s.subject._id : s.subject);
        const list = sectionsBySubject.get(subjectId) || [];
        const seats = settingsService.seatsFor(s.room && s.room.capacity, settings);
        const seatsLeft = Math.max(0, seats - (taken.get(String(s._id)) || 0));
        list.push({
          _id: s._id,
          weekdays: s.weekdays,
          startTime: s.startTime,
          endTime: s.endTime,
          room: s.room ? s.room.roomCode : '—',
          instructor: instructorLabel(s.instructor),
          seats,
          seatsLeft,
          sectionType: s.sectionType || 'Open',
          blockLabel: s.blockLabel || '',
          status: s.status === 'Inactive' || s.subject?.status !== 'Active' || s.room?.status !== 'Active' || (s.instructor && s.instructor.status !== 'Active')
            ? 'Closed'
            : seatsLeft < 1 ? 'Full' : 'Open'
        });
        sectionsBySubject.set(subjectId, list);
      }
    }

    const alreadyEnrolled = new Set(
      (await Enrollment.find({ student: student._id, semester: current._id, status: 'Active' }).select('subject').lean())
        .map(e => String(e.subject))
    );

    res.json({
      student: {
        studentId: student.studentId,
        firstName: student.firstName,
        lastName: student.lastName,
        course: { _id: student.course._id, code: student.course.code, name: student.course.name },
        yearLevel: student.yearLevel
      },
      academicYear: current.academicYear,
      semesterId: current._id,
      term,
      state: enrollmentIsOpen(current) ? 'open' : 'closed',
      enrollmentStart: current.startDate,
      enrollmentEnd: current.endDate,
      hasProspectus: curriculum.length > 0,
      subjects: items.map(i => {
        const p = progress.get(String(i.subject._id));
        const offered = offeredIds.has(String(i.subject._id));
        const sections = sectionsBySubject.get(String(i.subject._id)) || [];
        const prerequisites = (i.subject.prerequisites || []).map(prerequisite => ({
          subject: { _id: prerequisite._id, subjectCode: prerequisite.subjectCode, subjectName: prerequisite.subjectName },
          progress: progress.get(String(prerequisite._id))?.progress || 'Upcoming'
        }));
        const missingPrerequisite = prerequisites.find(prerequisite => !['Passed', 'Credited'].includes(prerequisite.progress));
        let reason = '';
        if (p.progress === 'Passed' || p.progress === 'Credited') reason = 'Already passed or credited';
        else if (p.progress === 'Enrolled') reason = 'Currently enrolled';
        else if (missingPrerequisite) reason = `Prerequisite ${missingPrerequisite.subject.subjectCode} is not completed`;
        else if (i.subject.status !== 'Active') reason = 'Subject is inactive';
        else if (!offered) reason = 'Not offered this term';
        else if (!sections.length) reason = 'Offered, but no class schedule has been plotted yet';
        else if (!sections.some(section => section.status === 'Open')) reason = 'No available section';
        return {
          subject: {
            _id: i.subject._id,
            subjectCode: i.subject.subjectCode,
            subjectName: i.subject.subjectName,
            units: i.subject.units,
            status: i.subject.status
          },
          yearLevel: i.yearLevel,
          term: i.term,
          offered,
          progress: p.progress,
          prerequisites,
          enrolled: Boolean(alreadyEnrolled.has(String(i.subject._id))),
          canSelect: !reason,
          disabledReason: reason,
          sections
        };
      })
    });
  } catch (err) { next(err); }
});

// Direct enrollment. There is no payment step, no Dean evaluation and no
// Registrar finalization in this system; the server still enforces every
// academic and scheduling rule inside the scheduling lock.
router.post('/enroll', csrfProtect, async (req, res, next) => {
  try {
    const scheduleIds = Array.isArray(req.body.scheduleIds) ? req.body.scheduleIds.map(String) : [];
    const sectionType = req.body.sectionType || 'Open';
    if (!['Open', 'Block'].includes(sectionType)) throw httpError(400, 'Choose Open Section or Block Section.');
    const blockLabel = String(req.body.blockLabel || '').trim();
    if (!scheduleIds.length) throw httpError(400, 'Choose a section for at least one subject.');
    if (new Set(scheduleIds).size !== scheduleIds.length) throw httpError(400, 'A section can only be selected once.');
    if (sectionType === 'Block' && !blockLabel) throw httpError(400, 'Choose a block section.');

    const student = await myStudent(req.user._id);

    const created = await withSchedulingLock(async () => {
      const current = await getCurrentSemester();
      if (!current) throw httpError(409, 'No semester is currently open for enrollment.');
      if (!enrollmentIsOpen(current)) throw httpError(409, 'Enrollment is closed for this school year and semester.');

      const curriculum = await prospectusItems(student);
      const items = curriculum.filter(i => i.yearLevel === student.yearLevel && i.term === current.term);
      const allowed = new Map(items.filter(i => i.subject.status === 'Active').map(i => [String(i.subject._id), i.subject]));
      const offeredIds = await offeredSubjectIds(student, current._id);

      const schedules = await Schedule.find({ _id: { $in: scheduleIds } }).lean();
      if (schedules.length !== scheduleIds.length) throw httpError(400, 'One of the chosen sections no longer exists.');
      if (schedules.some(s => (s.sectionType || 'Open') !== sectionType)) throw httpError(400, 'Selected schedules do not match the chosen section type.');
      if (sectionType === 'Block' && schedules.some(s => s.blockLabel !== blockLabel)) throw httpError(400, 'Selected schedules do not match the chosen block.');

      const prerequisiteIds = [...new Set([...allowed.values()].flatMap(subject => (subject.prerequisites || []).map(prerequisite => String(prerequisite._id))))];
      const validatedPrerequisiteIds = new Set(
        (await Enrollment.find({ student: student._id, subject: { $in: prerequisiteIds }, result: { $in: ['Passed', 'Credited'] } })
          .distinct('subject')).map(String)
      );
      const takenSubjects = new Set(
        (await Enrollment.find({ student: student._id, status: 'Active' }).select('subject').lean()).map(e => String(e.subject))
      );

      const seen = new Set();
      const validatedSchedules = [];
      for (const s of schedules) {
        const subject = allowed.get(String(s.subject));
        if (!subject) throw httpError(400, 'You can only enroll in subjects from your prospectus for your current year level and semester.');
        if (!offeredIds.has(String(s.subject))) throw httpError(400, `${subject.subjectCode} is not offered this term.`);
        if (seen.has(String(s.subject))) throw httpError(400, `Choose only one section for ${subject.subjectCode}.`);
        seen.add(String(s.subject));

        if (await Enrollment.exists({ student: student._id, subject: s.subject, result: { $in: ['Passed', 'Credited'] } })) {
          throw httpError(409, `You already passed or received credit for ${subject.subjectCode}.`);
        }
        if (takenSubjects.has(String(s.subject))) throw httpError(409, `You are already enrolled in ${subject.subjectCode}.`);
        const missing = (subject.prerequisites || []).find(prerequisite => !validatedPrerequisiteIds.has(String(prerequisite._id)));
        if (missing) throw httpError(409, `Complete prerequisite ${missing.subjectCode} before enrolling in ${subject.subjectCode}.`);

        const { schedule } = await validateEnrollment({
          studentId: student._id,
          scheduleId: s._id,
          semesterId: current._id
        });
        for (const existing of validatedSchedules) {
          if (sameDay(schedule.weekdays, existing.weekdays) && overlaps(schedule.startTime, schedule.endTime, existing.startTime, existing.endTime)) {
            throw httpError(409, `Your selected sections have overlapping class times (${subject.subjectCode}).`);
          }
        }
        validatedSchedules.push(schedule);
      }

      if (sectionType === 'Block') {
        const blockSchedules = await Schedule.find({
          sectionType: 'Block', blockLabel, course: student.course._id, yearLevel: student.yearLevel,
          status: 'Active', subject: { $in: [...allowed.keys()] }
        }).select('_id subject').lean();
        const bySubject = new Map();
        for (const schedule of blockSchedules) {
          const key = String(schedule.subject);
          bySubject.set(key, (bySubject.get(key) || 0) + 1);
        }
        const expectedSubjects = [...bySubject.entries()].filter(([, count]) => count === 1).map(([subjectId]) => subjectId);
        if (blockSchedules.length !== expectedSubjects.length || expectedSubjects.length !== seen.size || expectedSubjects.some(subjectId => !seen.has(subjectId))) {
          throw httpError(409, 'The selected block is incomplete or contains a subject that is not available to you.');
        }
      }

      const docs = validatedSchedules.map(schedule => ({
        student: student._id,
        schedule: schedule._id,
        subject: schedule.subject && schedule.subject._id ? schedule.subject._id : schedule.subject,
        semester: current._id,
        result: 'Enrolled',
        status: 'Active'
      }));
      try {
        await Enrollment.insertMany(docs, { ordered: true });
      } catch (err) {
        if (err.code === 11000) throw httpError(409, 'You are already enrolled in one of the selected subjects.');
        throw err;
      }
      return {
        count: docs.length,
        semesterLabel: `${current.academicYear} ${current.term}`,
        subjects: validatedSchedules.map(s => `${s.subject?.subjectCode || ''} — ${(s.weekdays || []).join(', ')} ${s.startTime}-${s.endTime}`)
      };
    });

    await logActivity({
      performedBy: req.user._id,
      category: 'Enrollment',
      action: 'Enrollment submitted',
      description: `${student.studentId} enrolled in ${created.count} subject(s) for ${created.semesterLabel}.`
    });

    res.status(201).json({ message: `Enrolled in ${created.count} subject(s) for ${created.semesterLabel}.`, ...created });
  } catch (err) { next(err); }
});

router.post('/drop', csrfProtect, async (req, res, next) => {
  try {
    const student = await myStudent(req.user._id);
    const current = await getCurrentSemester();
    if (!current) throw httpError(409, 'No semester is currently open.');
    const enrollment = await Enrollment.findOne({ _id: req.body.enrollmentId, student: student._id, status: 'Active' });
    if (!enrollment) throw httpError(404, 'Active enrollment not found.');
    if (String(enrollment.semester) !== String(current._id)) throw httpError(409, 'Only an enrollment in the current semester can be dropped.');
    if (!enrollmentIsOpen(current)) throw httpError(409, 'Dropping is closed for this school year and semester.');

    enrollment.status = 'Inactive';
    enrollment.result = 'Dropped';
    await enrollment.save();

    await logActivity({
      performedBy: req.user._id,
      category: 'Enrollment',
      action: 'Subject dropped',
      description: `${student.studentId} dropped an enrolled subject for ${current.academicYear} ${current.term}.`
    });
    res.json({ message: 'Subject dropped.' });
  } catch (err) { next(err); }
});

router.get('/prospectus', async (req, res, next) => {
  try {
    const student = await myStudent(req.user._id);
    if (!student.course) {
      throw httpError(409, 'Your student profile is incomplete. Please contact the scheduling office to assign your course.');
    }
    const p = await Prospectus.findOne({ course: student.course._id })
      .populate({ path: 'items.subject', select: 'subjectCode subjectName units status prerequisites' })
      .lean();
    const items = ((p && p.items) || []).filter(i => i.subject);
    res.json({
      student: {
        studentId: student.studentId,
        course: { _id: student.course._id, code: student.course.code, name: student.course.name },
        yearLevel: student.yearLevel
      },
      items: items.map(i => ({
        yearLevel: i.yearLevel,
        term: i.term,
        subject: {
          _id: i.subject._id,
          subjectCode: i.subject.subjectCode,
          subjectName: i.subject.subjectName,
          units: i.subject.units,
          status: i.subject.status
        }
      }))
    });
  } catch (err) { next(err); }
});

module.exports = router;
