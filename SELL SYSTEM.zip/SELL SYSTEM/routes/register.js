const express = require('express');

const { csrfProtect } = require('../middleware/auth');
const { httpError } = require('../utils/validation');
const { registerAccount } = require('../services/registrationService');

const router = express.Router();

// Public registration creates Student or Instructor accounts. Admin accounts
// are created by the scheduling office, never through this endpoint.
router.post('/', csrfProtect, async (req, res, next) => {
  try {
    const data = req.body || {};
    const role = data.role ? String(data.role) : 'Student';
    if (!['Student', 'Instructor'].includes(role)) {
      throw httpError(400, 'Public registration is for Student and Instructor accounts only.');
    }

    const account = await registerAccount({
      role,
      username: data.username,
      password: data.password,
      confirmPassword: data.confirmPassword
    });

    const idLabel = account.role === 'Student' ? 'Student ID' : 'Instructor ID';
    res.status(201).json({
      message: account.publicId
        ? `Account created. Your ${idLabel} is ${account.publicId}. You can sign in now.`
        : 'Account created. You can sign in now.',
      role: account.role,
      studentId: account.role === 'Student' ? account.publicId : null,
      instructorId: account.role === 'Instructor' ? account.publicId : null
    });
  } catch (err) {
    if (err.code === 11000) return next(httpError(409, 'That username is already in use.'));
    next(err);
  }
});

module.exports = router;
