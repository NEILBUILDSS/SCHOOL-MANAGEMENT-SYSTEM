﻿const express = require('express');
const bcrypt = require('bcryptjs');

const User = require('../models/User');
const Student = require('../models/Student');
const Instructor = require('../models/Instructor');

const {
  requireAuth,
  csrfProtect
} = require('../middleware/auth');

const {
  validateEmail,
  validatePassword,
  required,
  clean,
  httpError
} = require('../utils/validation');

const {
  logActivity
} = require('../services/logService');

const router = express.Router();

router.use(requireAuth);


/* =========================================================
   HELPERS
   ========================================================= */

function setOptional(obj, key, body, bodyKey, max = 160) {

  if (body[bodyKey] !== undefined) {

    obj[key] = clean(
      body[bodyKey],
      max
    );

  }

}


function ensureStudentSections(student) {

  if (!student.currentAddress)
    student.currentAddress = {};

  if (!student.permanentAddress)
    student.permanentAddress = {};

  if (!student.father)
    student.father = {};

  if (!student.mother)
    student.mother = {};

  if (!student.guardian)
    student.guardian = {};

  if (!student.emergencyContact)
    student.emergencyContact = {};

  if (!student.education)
    student.education = {};

  if (!student.education.primary)
    student.education.primary = {};

  if (!student.education.secondary)
    student.education.secondary = {};

  if (!student.education.seniorHigh)
    student.education.seniorHigh = {};

  if (!student.education.lastAttended)
    student.education.lastAttended = {};

}


function updateStudentProfile(student, body) {

  ensureStudentSections(student);


  // PERSONAL / SECONDARY INFORMATION

  setOptional(
    student,
    'telephoneNumber',
    body,
    'telephoneNumber',
    40
  );

  setOptional(
    student,
    'birthPlace',
    body,
    'birthPlace',
    160
  );

  setOptional(
    student,
    'religion',
    body,
    'religion',
    100
  );

  setOptional(
    student,
    'citizenship',
    body,
    'citizenship',
    100
  );

  setOptional(
    student,
    'civilStatus',
    body,
    'civilStatus',
    60
  );


  // CURRENT ADDRESS

  setOptional(
    student.currentAddress,
    'houseNo',
    body,
    'currentHouseNo'
  );

  setOptional(
    student.currentAddress,
    'streetNo',
    body,
    'currentStreetNo'
  );

  setOptional(
    student.currentAddress,
    'barangay',
    body,
    'currentBarangay'
  );

  setOptional(
    student.currentAddress,
    'city',
    body,
    'currentCity'
  );

  setOptional(
    student.currentAddress,
    'province',
    body,
    'currentProvince'
  );

  setOptional(
    student.currentAddress,
    'zipCode',
    body,
    'currentZipCode',
    20
  );


  // PERMANENT ADDRESS

  setOptional(
    student.permanentAddress,
    'houseNo',
    body,
    'permanentHouseNo'
  );

  setOptional(
    student.permanentAddress,
    'streetNo',
    body,
    'permanentStreetNo'
  );

  setOptional(
    student.permanentAddress,
    'barangay',
    body,
    'permanentBarangay'
  );

  setOptional(
    student.permanentAddress,
    'city',
    body,
    'permanentCity'
  );

  setOptional(
    student.permanentAddress,
    'province',
    body,
    'permanentProvince'
  );

  setOptional(
    student.permanentAddress,
    'zipCode',
    body,
    'permanentZipCode',
    20
  );


  // FATHER

  setOptional(
    student.father,
    'name',
    body,
    'fatherName',
    180
  );

  setOptional(
    student.father,
    'occupation',
    body,
    'fatherOccupation',
    140
  );

  setOptional(
    student.father,
    'mobileNumber',
    body,
    'fatherMobileNumber',
    40
  );


  // MOTHER

  setOptional(
    student.mother,
    'name',
    body,
    'motherName',
    180
  );

  setOptional(
    student.mother,
    'occupation',
    body,
    'motherOccupation',
    140
  );

  setOptional(
    student.mother,
    'mobileNumber',
    body,
    'motherMobileNumber',
    40
  );


  // GUARDIAN

  setOptional(
    student.guardian,
    'name',
    body,
    'guardianName',
    180
  );

  setOptional(
    student.guardian,
    'occupation',
    body,
    'guardianOccupation',
    140
  );

  setOptional(
    student.guardian,
    'mobileNumber',
    body,
    'guardianMobileNumber',
    40
  );


  // EMERGENCY CONTACT

  setOptional(
    student.emergencyContact,
    'name',
    body,
    'emergencyName',
    180
  );

  setOptional(
    student.emergencyContact,
    'relationship',
    body,
    'emergencyRelationship',
    100
  );

  setOptional(
    student.emergencyContact,
    'mobileNumber',
    body,
    'emergencyMobileNumber',
    40
  );


  // PRIMARY SCHOOL

  setOptional(
    student.education.primary,
    'school',
    body,
    'primarySchool',
    220
  );

  setOptional(
    student.education.primary,
    'address',
    body,
    'primaryAddress',
    260
  );

  setOptional(
    student.education.primary,
    'schoolYear',
    body,
    'primarySchoolYear',
    40
  );


  // SECONDARY / JUNIOR HIGH

  setOptional(
    student.education.secondary,
    'school',
    body,
    'secondarySchool',
    220
  );

  setOptional(
    student.education.secondary,
    'address',
    body,
    'secondaryAddress',
    260
  );

  setOptional(
    student.education.secondary,
    'schoolYear',
    body,
    'secondarySchoolYear',
    40
  );


  // SENIOR HIGH

  setOptional(
    student.education.seniorHigh,
    'school',
    body,
    'seniorHighSchool',
    220
  );

  setOptional(
    student.education.seniorHigh,
    'address',
    body,
    'seniorHighAddress',
    260
  );

  setOptional(
    student.education.seniorHigh,
    'schoolYear',
    body,
    'seniorHighSchoolYear',
    40
  );


  // SCHOOL LAST ATTENDED

  setOptional(
    student.education.lastAttended,
    'school',
    body,
    'lastAttendedSchool',
    220
  );

  setOptional(
    student.education.lastAttended,
    'address',
    body,
    'lastAttendedAddress',
    260
  );

  setOptional(
    student.education.lastAttended,
    'schoolYear',
    body,
    'lastAttendedSchoolYear',
    40
  );

}


/* =========================================================
   GET PROFILE
   ========================================================= */

router.get('/', async (req, res, next) => {

  try {

    let profile = null;


    if (req.user.role === 'Student') {

      profile =
        await Student.findOne({
          user: req.user._id
        })
        .populate('course')
        .lean();

    }


    if (req.user.role === 'Instructor') {

      profile =
        await Instructor.findOne({
          user: req.user._id
        })
        .lean();

    }


    res.json({

      user: {
        username: req.user.username,
        email: req.user.email,
        role: req.user.role,
        status: req.user.status
      },

      profile

    });

  } catch (err) {

    next(err);

  }

});


/* =========================================================
   UPDATE OWN PROFILE
   ========================================================= */

router.patch('/', csrfProtect, async (req, res, next) => {

  try {

    const user =
      await User.findById(
        req.user._id
      );


    if (!user) {

      throw httpError(
        404,
        'Account not found.'
      );

    }


    // EMAIL

    if (req.body.email !== undefined) {

      user.email =
        validateEmail(
          req.body.email
        );

    }


    // ADMIN USERNAME ONLY

    if (
      user.role === 'Admin' &&
      req.body.username !== undefined
    ) {

      user.username =
        required(
          req.body.username,
          'Username',
          50
        ).toLowerCase();

    }


    let profile = null;


    if (user.role === 'Student') {

      profile =
        await Student.findOne({
          user: user._id
        });

    }


    if (user.role === 'Instructor') {

      profile =
        await Instructor.findOne({
          user: user._id
        });

    }


    // CONTACT NUMBER

    if (
      profile &&
      req.body.contactNumber !== undefined
    ) {

      profile.contactNumber =
        required(
          req.body.contactNumber,
          'Contact number',
          40
        );

    }


    // STUDENT MAY COMPLETE PERSONAL PROFILE,
    // BUT NOT SCHOOL IDENTITY / ACADEMIC DATA

    if (
      user.role === 'Student' &&
      profile
    ) {

      updateStudentProfile(
        profile,
        req.body
      );

    }


    // PASSWORD

    if (req.body.newPassword) {

      const current =
        String(
          req.body.currentPassword || ''
        );


      if (
        !current ||
        !(await bcrypt.compare(
          current,
          user.passwordHash
        ))
      ) {

        throw httpError(
          401,
          'Current password is incorrect.'
        );

      }


      const nextPassword =
        validatePassword(
          req.body.newPassword
        );


      if (
        nextPassword !==
        String(
          req.body.confirmPassword || ''
        )
      ) {

        throw httpError(
          400,
          'New password confirmation does not match.'
        );

      }


      user.passwordHash =
        await bcrypt.hash(
          nextPassword,
          12
        );

    }


    await user.save();


    if (profile) {

      await profile.save();

    }


    await logActivity({

      performedBy:
        user._id,

      category:
        'Profile',

      action:
        'Profile updated',

      description:
        `${user.role} profile ${user.username} was updated.`

    });


    res.json({

      message:
        'Profile updated successfully.'

    });


  } catch (err) {

    next(err);

  }

});


module.exports = router;
