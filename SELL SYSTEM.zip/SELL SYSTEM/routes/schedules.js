﻿const express=require('express');
const Schedule=require('../models/Schedule');
const Subject=require('../models/Subject');
const Room=require('../models/Room');
const Instructor=require('../models/Instructor');
const Course=require('../models/Course');
const Enrollment=require('../models/Enrollment');
const {requireAuth,requireRole,csrfProtect}=require('../middleware/auth');
const {httpError,escapeRegex}=require('../utils/validation');
const {logActivity}=require('../services/logService');
const {getCurrentSemester}=require('../services/semesterService');
const {withSchedulingLock,validateScheduleBasics,checkScheduleConflicts,checkExistingEnrollmentsForSchedule,checkRoomDailyLimit}=require('../services/schedulingService');
const {getSettings}=require('../services/settingsService');

const router=express.Router();
router.use(requireAuth,requireRole('Admin'));

function parseDays(value){
  if(Array.isArray(value)) return value;
  if(typeof value==='string') return value.split(',').map(x=>x.trim()).filter(Boolean);
  return [];
}

function parseSection(data){
  if(data.sectionType!==undefined&&!['Open','Block'].includes(data.sectionType))throw httpError(400,'Choose Open Section or Block Section.');
  const sectionType=data.sectionType==='Block'?'Block':'Open';
  const blockLabel=String(data.blockLabel||'').trim();
  if(sectionType==='Block'&&!blockLabel)throw httpError(400,'Enter a block label for block section schedules.');
  if(blockLabel.length>40)throw httpError(400,'Block label must be 40 characters or fewer.');
  return {sectionType,blockLabel:sectionType==='Block'?blockLabel:''};
}

async function hydrateOptions(){
  const [subjects,rooms,instructors,courses]=await Promise.all([
    Subject.find({status:'Active'}).populate('course').sort({subjectCode:1}).lean(),
    Room.find({status:'Active'}).sort({roomCode:1}).lean(),
    Instructor.find({status:'Active'}).populate('user','email username').sort({lastName:1,firstName:1}).lean(),
    Course.find({status:'Active'}).sort({code:1}).lean()
  ]);
  // Scheduling rules are configurable, so the editor is told the current
  // window and session lengths instead of hard-coding them in the browser.
  const settings=await getSettings();
  return {subjects,rooms,instructors,courses,settings};
}

router.get('/options',async(req,res,next)=>{try{res.json(await hydrateOptions());}catch(e){next(e);}});

router.get('/',async(req,res,next)=>{try{
  const f={};
  if(req.query.status&&['Active','Inactive'].includes(req.query.status))f.status=req.query.status;
  if(req.query.day)f.weekdays=req.query.day;
  if(req.query.course){const c=await Course.findOne({code:String(req.query.course).toUpperCase()});f.course=c?c._id:null;}
  if(req.query.room)f.room=req.query.room;
  if(req.query.instructor)f.instructor=req.query.instructor;
  if(req.query.q){const rx=new RegExp(escapeRegex(req.query.q),'i');const subjects=await Subject.find({$or:[{subjectCode:rx},{subjectName:rx}]}).distinct('_id');f.subject={$in:subjects};}
  const rows=await Schedule.find(f).populate('subject course room').populate({path:'instructor',populate:{path:'user',select:'email username'}}).sort({updatedAt:-1}).lean();
  res.json(rows);
}catch(e){next(e);}});

router.post('/',csrfProtect,async(req,res,next)=>{try{
  // Every subject offering belongs to the semester it was created in, so students only
  // ever see offerings for the period that is currently open for enrollment.
  const semester=await getCurrentSemester();
  if(!semester)throw httpError(409,'No current semester is available. Configure the semester before creating a schedule.');
  const created=await withSchedulingLock(async()=>{
    const candidate=await validateScheduleBasics({...req.body,weekdays:parseDays(req.body.weekdays)});
    const section=parseSection(req.body);
    candidate.sectionType=section.sectionType;
    candidate.blockLabel=section.blockLabel;
    await checkScheduleConflicts(candidate,null,semester._id);
    await checkRoomDailyLimit(candidate,null,semester._id);
    const schedule=await Schedule.create({subject:candidate.subject._id,instructor:candidate.instructor?candidate.instructor._id:null,room:candidate.room._id,weekdays:candidate.weekdays,startTime:candidate.startTime,endTime:candidate.endTime,course:candidate.course,yearLevel:candidate.yearLevel,...section,status:candidate.status,semester:semester._id});
    return schedule;
  });
  await logActivity({performedBy:req.user._id,category:'Schedule',action:'Schedule created',description:`Created schedule ${created._id}.`});
  res.status(201).json(created);
}catch(e){next(e);}});

router.get('/:id',async(req,res,next)=>{try{
  const schedule=await Schedule.findById(req.params.id).populate('subject course room').populate({path:'instructor',populate:{path:'user',select:'email username'}}).lean();
  if(!schedule)throw httpError(404,'Schedule not found.');
  const enrollments=await Enrollment.find({schedule:schedule._id}).populate({path:'student',populate:[{path:'course'},{path:'user',select:'email username'}]}).sort({status:1,createdAt:1}).lean();
  res.json({schedule,enrollments,options:await hydrateOptions()});
}catch(e){next(e);}});

router.patch('/:id',csrfProtect,async(req,res,next)=>{try{
  const result=await withSchedulingLock(async()=>{
    const current=await Schedule.findById(req.params.id);if(!current)throw httpError(404,'Schedule not found.');
    const merged={
      subject:req.body.subject??current.subject,
      instructor:req.body.instructor===undefined?current.instructor:(req.body.instructor||null),
      room:req.body.room??current.room,
      weekdays:req.body.weekdays===undefined?current.weekdays:parseDays(req.body.weekdays),
      startTime:req.body.startTime??current.startTime,
      endTime:req.body.endTime??current.endTime,
      course:req.body.course??current.course,
      yearLevel:req.body.yearLevel??current.yearLevel,
      sectionType:req.body.sectionType??current.sectionType,
      blockLabel:req.body.blockLabel??current.blockLabel,
      status:req.body.status??current.status
    };
    const candidate=await validateScheduleBasics(merged);
    const section=parseSection(merged);
    candidate.sectionType=section.sectionType;
    candidate.blockLabel=section.blockLabel;
    // semester must exist before the availability rechecks below - it was
    // referenced but never declared, so every schedule update threw a
    // ReferenceError ("semester is not defined") and answered 500.
    // An edit keeps the semester the offering was created in; only a legacy row
    // with no semester is adopted into the term open now (the rule POST / uses).
    const semester=current.semester||(await getCurrentSemester())?._id||null;
    await checkScheduleConflicts(candidate,current._id,semester);
    await checkRoomDailyLimit(candidate,current._id,semester);
    await checkExistingEnrollmentsForSchedule(candidate,current._id);
    Object.assign(current,{subject:candidate.subject._id,instructor:candidate.instructor?candidate.instructor._id:null,room:candidate.room._id,weekdays:candidate.weekdays,startTime:candidate.startTime,endTime:candidate.endTime,course:candidate.course,yearLevel:candidate.yearLevel,...section,status:candidate.status,semester});
    await current.save();return current;
  });
  await logActivity({performedBy:req.user._id,category:'Schedule',action:'Schedule updated',description:`Updated schedule ${result._id}.`});
  res.json({message:'Schedule updated successfully.'});
}catch(e){next(e);}});
module.exports=router;
