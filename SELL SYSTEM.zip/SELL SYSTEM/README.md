# Southern Canillo College — School Scheduling

A complete school scheduling management system with **exactly three portals**:

- **Admin** — academic operations, people, rooms, subjects, curriculum, scheduling, enrollment and settings.
- **Instructor** — assigned subjects on My Schedule, class rosters, class records and student lists.
- **Student** — immediate enrollment, current subjects, weekly schedule and prospectus.

The interface follows the supplied dashboard reference: floating navy sidebar, peach active pill, coral accents, white rounded cards and soft shadows. All assets (including Poppins fonts) are served locally — no CDNs are used.

The project is self-contained in this folder and installs, runs and tests independently. It does **not** modify or depend on the original project folder.

---

## 1. Technology

| Layer | Choice |
|---|---|
| Runtime | Node.js 18+ (tested with Node 24.21.0 on Windows 11) |
| Web framework | Express 5 |
| Database | MongoDB with Mongoose 8 |
| Sessions | `express-session` + `connect-mongo` |
| Passwords | `bcryptjs` (cost 12) |
| Security | Helmet CSP, CSRF tokens, role guards, login rate limit |
| Frontend | Vanilla JavaScript SPA, hash router, hand-built SVG charts and timetable |
| Styling | Local design system (`public/css/app.css`) with local Poppins fonts |

Default port: **3002**  
Default database: **`sell_system_scheduling`**  
Session cookie: **`sell.sid`**

---

## 2. Windows + VS Code setup

### Prerequisites

1. **Node.js 18 or newer** — install the LTS build from <https://nodejs.org>. Verify in a new terminal:
   ```powershell
   node --version
   npm --version
   ```
2. **MongoDB Community Server** — install from <https://www.mongodb.com/try/download/community>. The default Windows service is enough. Verify:
   ```powershell
   Get-Service MongoDB
   ```
   Status should be `Running`.
3. **VS Code** — <https://code.visualstudio.com>.

> If `node` or `npm` is not recognised after installation, close and reopen VS Code so it picks up the updated PATH.

### First run

1. In VS Code choose **File → Open Folder…** and select this folder:
   `...\Screenshots\SELL SYSTEM`
2. Open the integrated terminal with **Ctrl + `**.
3. Install dependencies:
   ```powershell
   npm install
   ```
4. Create the environment file from the included example:
   ```powershell
   Copy-Item .env.example .env
   ```
5. Open `.env` and set a private session secret of **at least 32 characters**. You can generate one in PowerShell:
   ```powershell
   -join ((48..57)+(65..90)+(97..122) | Get-Random -Count 48 | ForEach-Object {[char]$_})
   ```
   Example `.env`:
   ```dotenv
   PORT=3002
   MONGODB_URI=mongodb://127.0.0.1:27017/sell_system_scheduling
   SESSION_SECRET=paste-your-own-long-random-secret-here
   NODE_ENV=development
   ```
6. Start the server:
   ```powershell
   npm start
   ```
   On first start the server connects to MongoDB, creates the current school year/term, seeds base data (courses, subjects, rooms and sample schedule options), **and auto-creates demo users**, and creates demo users automatically.

**Default credentials (auto-created on first run):**

| Portal | Username | Password |
|--------|----------|----------|
| Admin | `admin` | `Admin@12345` |
| Student | `maria.santos` | `Student@12345` |
| Instructor | `daniel.cruz` | `Teacher@12345` |
8. Open <http://localhost:3002>.

For auto-restart while editing:
```powershell
npm run dev
```

### Running from VS Code without a terminal

The included `.vscode/launch.json` starts the server with the `.env` file loaded:

1. Open the **Run and Debug** panel (**Ctrl + Shift + D**).
2. Select **Southern Canillo College (server.js)**.
3. Press **F5**.

### First-start data

The server is safe to restart: the seed step is idempotent. It also recreates a missing current term and an empty prospectus.

- 3 courses: CS, IS, IT
- 7 sample subjects
- 30 rooms (20 lecture rooms + 10 laboratories) with local placeholder images
- 4 schedule options per initial subject (28 inactive options)
- No fictional people are part of the base seed

---

## 3. Demo Accounts

**These accounts are automatically created when the server starts for the first time:**

> ⚠️ **Security:** Change these passwords immediately before any real use!

| Portal | Username | Password |
|--------|----------|----------|
| Admin | `admin` | `Admin@12345` |
| Student | `maria.santos` | `Student@12345` |
| Instructor | `daniel.cruz` | `Teacher@12345` |

**To create additional admin accounts:**
```powershell
npm run create-admin
```

**Students and Instructors** can create their own accounts from the sign-in page.

---

## 4. What each portal can do

### Admin portal

- **Dashboard** — students, instructors, active sections, room totals, today's classes, room usage, enrollment load and recent activity.
- **Activity log** — every account, scheduling, enrollment, room and settings change with category filter and print.
- **Students** — searchable, view-only directory with clickable rows; the profile shows the avatar, ID, name, contact, course, year, section, account and enrollment status plus the student's current class schedule with days, times, rooms and instructors.
- **Instructors** — view-only directory with clickable rows; the profile shows the avatar, ID, contact, department, account status, teaching-load summary, assigned rooms, conflicts and every assigned subject/section with schedule details.
- **Subjects** — catalog cards, search, course, year-level and semester filters, detail modal, create/edit, units, laboratory flag, prerequisites and co-requisites.
- **Courses** — degree programs with clickable list rows that open a detailed course profile showing code, name, description, department, degree level, program duration, total units, status and summary counts for subjects, enrolled students and assigned instructors; add/edit remains available.
- **Room and Schedule** - one workspace with two tabs. **Room Directory** has searchable cards, availability, capacity, equipment, room type and photo upload inside **Edit room**. **Schedules & Rooms** has the weekly timetable, plot-a-class with automatic valid start times and live room cards, and edit/remove an assignment.
- **Prospectus** — place subjects into year level and semester, switch course, add/remove placements.
- **School Years** — term list with calendar status and editable start/end dates. The current term follows the calendar automatically.
- **Enrollments** — all enrollments, enroll a student into an offered section, drop with history retained.
- **Settings** — school day start/end, daily target hours, section capacity (maximum 10), active-room limit, session rules per day pattern, break setting.
- **Global search, quick action and notification bell** — header search appears on the searchable student, instructor, subject and room/schedule sections, and hides on the dashboard and non-search pages; quick action opens plotting; bell opens the activity log.
- **My Profile** — account details, contact update and password change.

### Instructor portal

- **My Schedule** — assigned subjects listed with subject code, subject name, section, day, time and room. This is the portal landing page; there is no separate My Subjects page, weekly timetable or print button.
- **Class details** — click any scheduled subject row to open its details and the official class list.
- **Class List** — only students with active enrollment records for that section appear; the list is hard-capped at 10 students.
- **Class Record** — attendance, assignments and activities only, per enrolled student, saved to the server and capped by the term's session count.
- **My Students** — every student across the instructor's sections with search.
- **My Profile** — contact and password update.

### Student portal

- **My Schedule** — table of enrolled sections with subject, section, day, time, room and instructor; click any row for class details and use Print if needed. This is the portal landing page.
- **Enrollment** — subjects from the student's own prospectus for the current year/term; choose one section per subject. Enrollment is **immediate** after server validation. Full and closed sections are disabled.
- **My Subjects** — current load and academic history, drop subject (record kept as Dropped), and re-enroll.
- **Prospectus** — the student's curriculum by year and semester, with the current term highlighted.
- **My Profile** — contact, personal fields and password update.

The Student sidebar uses the order **Enrollment → Prospectus → My Subjects → My Schedule → Profile → Logout** inside a light **Main Menu** panel. My Schedule remains the landing page.

There are **no Registrar, Dean, payment or assessment portals** and no approval queue. Public registration asks for an account type (**Student** or **Instructor**) plus **Username**, **Password** and **Confirm Password**; Admin accounts can never be created there. The existing User schema still requires a unique email, so each new account receives a private, non-deliverable alias derived from the username and signs in with the username. New Student records receive the next unique `YYYY-####` Student ID automatically, new Instructor records receive the next `INS-###` Instructor ID, and Admin-created records keep the same automatic-ID behavior. Existing IDs are preserved and never renumbered.

---

## 5. Scheduling and enrollment rules preserved

The existing scheduling rules are enforced in `services/schedulingService.js` and the routes, not only in the UI.

- Room double-booking is rejected (same room, overlapping time, overlapping day).
- Instructor double-booking is rejected.
- A section cannot take two classes at the same time.
- A room cannot exceed the configured **daily target hours** (default 8) on any class day.
- Room availability is scoped to the **current school year and semester**; historical and future terms do not block the current one.
- Session length must match the subject's units: total weekly minutes = units × 60, on a 30-minute grid and the configured day patterns (MWF, TTH, F, SATURDAY, SUNDAY).
- Classes must stay inside the configured school day.
- Room capacity and section capacity are checked during enrollment. The class list is hard-capped at **10 active enrollments per schedule**, independent of generated data or a larger room.
- Section conflicts are checked alongside room and instructor conflicts: an overlapping class for the same course, year level, section type and block label is rejected with a clear reason.
- Plotting prefers consecutive periods for the same section, so a new class fills the period next to an existing class instead of leaving avoidable gaps. Valid start times remain chronological, and every offered time is rechecked before saving.
- Prerequisites, duplicate subjects, already-passed/credited subjects and time conflicts are checked during enrollment.
- Writes are serialized through a scheduling lock, and availability is rechecked inside the lock. The automated tests include two concurrent requests that must not both succeed.
- Dropping a subject keeps the Enrollment row with status `Dropped` for history.
- Editing an assignment never conflicts with itself.

---

## 6. Project structure

```
SELL SYSTEM/
├─ config/                 MongoDB connection
├─ middleware/             auth, role guard, CSRF, error handling
├─ models/                 User, Student, Instructor, Course, Subject, Room,
│                          Schedule, Prospectus, Semester, Enrollment,
│                          ClassRecord, SubjectOffering, ActivityLog, Setting
├─ routes/                 auth, admin, students, instructors, subjects, courses,
│                          rooms, prospectus, semesters, schedules,
│                          enrollments, studentPortal, instructorPortal,
│                          portal, settings, profile
├─ services/               schedulingService, semesterService, seedService,
│                          settingsService, logService, accountService,
│                          registrationService, …
├─ scripts/                seed.js, createAdmin.js, reset-data.js
├─ public/
│  ├─ css/                 app.css (dashboard design system), login.css
│  ├─ js/                  core.js, admin.js, academics.js, scheduling.js,
│  │                       portals.js, app.js, login.js, register.js
│  ├─ images/              local Poppins fonts, room placeholders
│  ├─ uploads/rooms/       uploaded room photos
│  ├─ index.html           sign-in page
│  └─ register.html        public Student or Instructor registration
├─ views/dashboard.html    signed-in shell
├─ tests/                  5 test suites
├─ .env.example
├─ .vscode/launch.json
├─ README.md
└─ TESTING.md
```

---

## 7. Tests

```powershell
npm test
```

This runs five suites against separate throwaway MongoDB databases:

- `tests/roomAvailability.unit.test.js` — 16 unit checks
- `tests/roomAvailability.integration.test.js` — 6 database/service scenarios
- `tests/roomAvailability.api.test.js` — 13 HTTP API checks
- `tests/studentId.test.js` — automatic Student ID registration, concurrency and visibility
- `tests/registration.test.js` — credential-only Student/Instructor sign-up, role selection, uniqueness, bcrypt hashing, Admin rejection and login

Latest result: **37 passed, 0 failed**. The project database is never touched by the tests. See `TESTING.md` for the full manual test record and known limitations.

You can also syntax-check the server entry point:
```powershell
npm run check
```

---

## 8. Useful scripts

| Command | Purpose |
|---|---|
| `npm start` | Start on port 3002 |
| `npm run dev` | Start with Node watch mode |
| `npm run seed` | Run the idempotent base-data seed |
| `npm run create-admin` | Create an Admin account interactively |
| `npm run reset-data` | Destructive reset of people/schedules/enrollments, then reseed |
| `npm test` | Run all automated tests |
| `npm run check` | `node --check server.js` |

---

## 9. Security and deployment notes

- Change the demo passwords and the seeded Admin password before real use.
- Always set a unique `SESSION_SECRET` (32+ characters). The server refuses to start without one.
- `.env` and room uploads are excluded from Git by `.gitignore`.
- Cookies are `httpOnly`, `sameSite=lax`, and `secure` when `NODE_ENV=production` (serve over HTTPS behind a trusted reverse proxy in production).
- Login attempts are rate-limited; all state-changing APIs require a CSRF token.
- Content Security Policy allows only same-origin scripts, fonts and styles (inline style attributes are allowed for dynamically positioned timetable blocks and chart widths; inline scripts are not).
- The current scheduling lock is in-process. Run a single Node instance; multiple instances would need a shared lock or database transactions.
- This installation was tested on Windows with MongoDB running locally at `127.0.0.1:27017`.

---

## 10. Known limitations

- Class records store attendance/assignment/activity counts, not letter grades or weighted final grades.
- Printing uses the browser print dialog; there is no PDF generator or CSV export.
- Notifications are in-app only (activity log); no email or SMS.
- No bulk student import/export.
- Time values are stored as local `HH:MM` strings; there is no time-zone conversion.
- Schedule patterns are fixed to MWF, TTH, F, SATURDAY and SUNDAY with a 30-minute grid.
- Multi-campus support and multi-instance horizontal scaling are not implemented.
- Room photos accept JPEG, PNG and WebP up to 5 MB; seed rooms use local SVG placeholders.
- The database in this folder contains evaluation data (demo people, one demo room and one extra subject) as described in section 3.
