const mongoose = require('mongoose');

// A Subject Offering is the Registrar's "yes, teach this subject this term" flag.
// The Schedule Plotting board and the Room Assignment page only list subjects whose
// offering row exists with offered = true, so nothing can be plotted by accident.
//
// The section is identified by sectionKey so one offering row per subject per
// section per semester:  "O:1" (Open Section, Year 1) or "B:1:BSIT 1A" (Block).
function sectionKeyOf(sectionType, blockLabel, yearLevel) {
  const year = Number(yearLevel);
  if (sectionType === 'Block') {
    const label = String(blockLabel || '').trim().toUpperCase();
    return `B:${year}:${label || 'UNLABELED'}`;
  }
  return `O:${year}`;
}

function parseSectionKey(value) {
  const m = /^(O|B):(\d)(?::([\s\S]*))?$/.exec(String(value || '').trim());
  if (!m) return null;
  const yearLevel = Number(m[2]);
  if (yearLevel < 1 || yearLevel > 4) return null;
  return {
    sectionType: m[1] === 'B' ? 'Block' : 'Open',
    yearLevel,
    blockLabel: (m[3] || '').trim()
  };
}

function sectionLabel(sectionType, blockLabel, yearLevel) {
  if (sectionType === 'Block') {
    const label = String(blockLabel || '').trim();
    return label ? `Block ${label}` : `Block Section - Year ${yearLevel}`;
  }
  return `Open Section - Year ${yearLevel}`;
}

const subjectOfferingSchema = new mongoose.Schema({
  semester: { type: mongoose.Schema.Types.ObjectId, ref: 'Semester', required: true, index: true },
  course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
  yearLevel: { type: Number, min: 1, max: 4, required: true },
  sectionType: { type: String, enum: ['Open', 'Block'], default: 'Open', required: true },
  blockLabel: { type: String, trim: true, default: '' },
  sectionKey: { type: String, required: true, trim: true, uppercase: true },
  subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true, index: true },
  offered: { type: Boolean, default: false },
  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null }
}, { timestamps: true });

subjectOfferingSchema.index({ semester: 1, course: 1, sectionKey: 1, subject: 1 }, { unique: true });

const SubjectOffering = mongoose.model('SubjectOffering', subjectOfferingSchema);
SubjectOffering.sectionKeyOf = sectionKeyOf;
SubjectOffering.parseSectionKey = parseSectionKey;
SubjectOffering.sectionLabel = sectionLabel;
module.exports = SubjectOffering;
