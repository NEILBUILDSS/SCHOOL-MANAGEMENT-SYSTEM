const mongoose = require('mongoose');

// ---------------------------------------------------------------------------
// Scheduling settings
//
// One singleton document holds every scheduling value the registrar may tune.
// The defaults below reproduce the school's stated rules, so a database that
// has no settings row yet behaves exactly like the original hard-coded code:
//   - school day runs 7:30 AM to 5:00 PM
//   - MWF sessions last 1 hour, TTh sessions last 1.5 hours
//   - an instructor's daily teaching target is 8 hours
//   - a section holds 10 students
//   - 5 classrooms are planned for
// Nothing here deletes or rewrites existing records; every value is additive.
// ---------------------------------------------------------------------------

const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

function toMinutes(value) {
  const m = TIME_RE.exec(String(value || ''));
  if (!m) return NaN;
  return Number(m[1]) * 60 + Number(m[2]);
}

// Day-pattern keys match DAY_PATTERNS in public/js/app.js.
const PATTERN_KEYS = ['MWF', 'TTH', 'F', 'SATURDAY', 'SUNDAY'];

const breakSchema = new mongoose.Schema({
  label: { type: String, required: true, trim: true, maxlength: 60 },
  startTime: { type: String, required: true, match: [TIME_RE, 'Break start must use 24-hour HH:MM format.'] },
  endTime: { type: String, required: true, match: [TIME_RE, 'Break end must use 24-hour HH:MM format.'] }
}, { _id: false });

const sessionRuleSchema = new mongoose.Schema({
  pattern: { type: String, enum: PATTERN_KEYS, required: true },
  minutes: { type: Number, required: true, min: 30, max: 360 }
}, { _id: false });

const settingsSchema = new mongoose.Schema({
  // Fixed singleton key. The unique index is what actually guarantees one row.
  key: { type: String, default: 'scheduling', unique: true },

  // School day. Original code hard-coded 07:30-20:30; the school rule is 07:30-17:00.
  dayStart: { type: String, default: '07:30', match: [TIME_RE, 'Day start must use 24-hour HH:MM format.'] },
  dayEnd: { type: String, default: '17:00', match: [TIME_RE, 'Day end must use 24-hour HH:MM format.'] },

  // Breaks are opt-in. When enabled a class may not be plotted across a break.
  breaksEnabled: { type: Boolean, default: false },
  breaks: { type: [breakSchema], default: [] },

  // Daily teaching target shown on the instructor workload report.
  // It is a target, never a quota: nothing is forced to reach it and an
  // instructor is never reported as "fully loaded" without real hours behind it.
  dailyTargetHours: { type: Number, default: 8, min: 1, max: 24 },

  // Seats offered in one section. Room capacity still applies on top of this,
  // and the class list is hard-capped at ten students per subject/section.
  sectionCapacity: { type: Number, default: 10, min: 1, max: 10 },

  // How many classrooms the planner may draw from. 0 means "no limit".
  // The 33 stored room records are untouched; this only limits new plotting.
  activeRoomLimit: { type: Number, default: 5, min: 0, max: 500 },

  // When true a class day pattern fixes the session length (MWF = 60 minutes,
  // TTh = 90 minutes). When false the legacy rule applies: weekly minutes are
  // the subject's units times 60, split evenly across the chosen days.
  enforcePatternDuration: { type: Boolean, default: true },
  sessionRules: { type: [sessionRuleSchema], default: () => [
    { pattern: 'MWF', minutes: 60 },
    { pattern: 'TTH', minutes: 90 }
  ] }
}, { timestamps: true });

settingsSchema.pre('validate', function (next) {
  const start = toMinutes(this.dayStart);
  const end = toMinutes(this.dayEnd);
  if (!Number.isNaN(start) && !Number.isNaN(end) && end <= start) {
    this.invalidate('dayEnd', 'Day end must be after day start.');
  }

  // Breaks are always validated, even while they are switched off: settings
  // must never hold a break that could not be honoured once enabled.
  // breaksEnabled only controls whether the scheduler enforces them.
  for (const b of this.breaks) {
    const bs = toMinutes(b.startTime);
    const be = toMinutes(b.endTime);
    if (!Number.isNaN(bs) && !Number.isNaN(be) && be <= bs) {
      this.invalidate('breaks', `Break "${b.label}" must end after it starts.`);
    }
    if (!Number.isNaN(start) && !Number.isNaN(bs) && bs < start) {
      this.invalidate('breaks', `Break "${b.label}" starts before the school day.`);
    }
    if (!Number.isNaN(end) && !Number.isNaN(be) && be > end) {
      this.invalidate('breaks', `Break "${b.label}" ends after the school day.`);
    }
  }
  const sorted = this.breaks
    .map(b => ({ label: b.label, s: toMinutes(b.startTime), e: toMinutes(b.endTime) }))
    .sort((a, b) => a.s - b.s);
  for (let i = 1; i < sorted.length; i++) {
    if (sorted[i].s < sorted[i - 1].e) {
      this.invalidate('breaks', `Break "${sorted[i].label}" overlaps "${sorted[i - 1].label}".`);
    }
  }

  // One rule per day pattern, otherwise the planner would not know which wins.
  const patterns = (this.sessionRules || []).map(r => r.pattern);
  if (new Set(patterns).size !== patterns.length) {
    this.invalidate('sessionRules', 'Each day pattern can only have one session length.');
  }

  next();
});

// Every pattern the planner supports always has a rule, even one the admin
// never edited, so a missing entry can never fall through to a silent default.
settingsSchema.methods.ruleFor = function (pattern) {
  const hit = (this.sessionRules || []).find(r => r.pattern === pattern);
  return hit ? hit.minutes : null;
};

const Setting = mongoose.model('Setting', settingsSchema);
Setting.PATTERN_KEYS = PATTERN_KEYS;
module.exports = Setting;
