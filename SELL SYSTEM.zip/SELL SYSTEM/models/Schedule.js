const mongoose = require('mongoose');

const scheduleSchema = new mongoose.Schema({
  seedKey: { type: String, unique: true, sparse: true, immutable: true },
  subject: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true, index: true },
  instructor: { type: mongoose.Schema.Types.ObjectId, ref: 'Instructor', default: null, index: true },
  room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', required: true, index: true },
  // Weekend classes are legal: the day patterns and the conflict engine all
  // know Sat/Sun, so the enum must too (it previously rejected weekend saves).
  weekdays: [{ type: String, enum: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], required: true }],
  startTime: { type: String, required: true },
  endTime: { type: String, required: true },
  course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
  yearLevel: { type: Number, min: 1, max: 4, required: true, index: true },
  sectionType: { type: String, enum: ['Open', 'Block'], default: 'Open', required: true, index: true },
  blockLabel: { type: String, trim: true, default: '' },
  status: { type: String, enum: ['Active', 'Inactive'], default: 'Inactive', index: true },
  // The semester this subject offering belongs to. This is what decides whether a
  // Prospectus subject is actually open for enrollment in the current period.
  // null is kept for legacy rows created before offerings were tied to a semester.
  semester: { type: mongoose.Schema.Types.ObjectId, ref: 'Semester', default: null, index: true }
}, { timestamps: true });

scheduleSchema.index({ status: 1, room: 1 });
scheduleSchema.index({ status: 1, instructor: 1 });

module.exports = mongoose.model('Schedule', scheduleSchema);
