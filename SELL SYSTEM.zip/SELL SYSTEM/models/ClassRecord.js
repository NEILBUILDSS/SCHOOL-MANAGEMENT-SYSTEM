const mongoose = require('mongoose');

// A class record is one student's performance in one class section (schedule).
//
// It is deliberately limited to three things the instructor actually records
// during the term: attendance, assignments and activities. There are no
// quizzes, exams or posted final grade here - grading is not part of this
// module, so nothing in the enrollment workflow is derived from it either.
const classRecordSchema = new mongoose.Schema({
  schedule: { type: mongoose.Schema.Types.ObjectId, ref: 'Schedule', required: true, index: true },
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true, index: true },
  enrollment: { type: mongoose.Schema.Types.ObjectId, ref: 'Enrollment', required: true, unique: true, index: true },
  semester: { type: mongoose.Schema.Types.ObjectId, ref: 'Semester', default: null, index: true },

  // Sessions held vs sessions the student attended, e.g. 34/35.
  // attendanceTotal is derived from the schedule's class days and the semester
  // dates, so the instructor only ever types the attended count.
  attendancePresent: { type: Number, min: 0, default: null },
  attendanceTotal: { type: Number, min: 0, default: null },

  // Scores, 0-100. Left null until the instructor enters them.
  assignments: { type: Number, min: 0, max: 100, default: null },
  activities: { type: Number, min: 0, max: 100, default: null },

  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null }
}, { timestamps: true });

// One record per student per section - re-saving updates instead of duplicating.
classRecordSchema.index({ schedule: 1, student: 1 }, { unique: true });

module.exports = mongoose.model('ClassRecord', classRecordSchema);
