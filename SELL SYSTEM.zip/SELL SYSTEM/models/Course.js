const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  seedKey: { type: String, unique: true, sparse: true, immutable: true },
  code: { type: String, required: true, uppercase: true, trim: true, unique: true, index: true },
  name: { type: String, required: true, trim: true },
  description: { type: String, trim: true, default: '' },
  status: { type: String, enum: ['Active', 'Inactive'], default: 'Active', index: true },
  // Extended Add Course fields. Optional with defaults so seeded and legacy
  // course records remain valid; courseCode/courseName are stored as the
  // canonical code/name above so every existing reference (students, subjects,
  // prospectus, schedules) keeps working.
  abbreviation: { type: String, trim: true, default: '' },
  department: { type: String, trim: true, default: '' },
  degreeLevel: { type: String, trim: true, default: '' },
  duration: { type: String, trim: true, default: '' },
  years: { type: Number, default: null },
  totalUnits: { type: Number, default: null },
  curriculumYear: { type: String, trim: true, default: '' },
  major: { type: String, trim: true, default: '' }
}, { timestamps: true });

module.exports = mongoose.model('Course', courseSchema);
