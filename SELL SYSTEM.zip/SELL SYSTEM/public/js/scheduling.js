/* ============================================================
   SELL SYSTEM — Admin scheduling workspace
   Weekly timetable and plotting a class.
   ============================================================ */
(function () {
  'use strict';

  var P = App.pages = App.pages || {};

  var PATTERNS = {
    MWF: ['Mon', 'Wed', 'Fri'],
    TTH: ['Tue', 'Thu'],
    F: ['Fri'],
    SATURDAY: ['Sat'],
    SUNDAY: ['Sun']
  };

  function sectionText(s) {
    if (!s) return '—';
    return (s.sectionType || 'Open') === 'Block'
      ? 'Block ' + (s.blockLabel || '—') + ' · Year ' + s.yearLevel
      : 'Open Section · Year ' + s.yearLevel;
  }

  function timeRange(s) {
    return App.time12(s.startTime) + ' – ' + App.time12(s.endTime);
  }

  /* ============================== unified room + schedule page ============================== */

  function roomScheduleTabs(active) {
    return '<div class="tabs main-tabs" id="roomScheduleTabs" role="tablist" aria-label="Room and schedule sections">' +
      '<button class="tab' + (active === 'rooms' ? ' active' : '') + '" type="button" role="tab" aria-selected="' + (active === 'rooms') + '" aria-controls="roomSchedulePanel" data-section="rooms">' +
      App.icon('door') + '<span>Room Directory</span></button>' +
      '<button class="tab' + (active === 'schedules' ? ' active' : '') + '" type="button" role="tab" aria-selected="' + (active === 'schedules') + '" aria-controls="roomSchedulePanel" data-section="schedules">' +
      App.icon('calendar') + '<span>Schedules & Rooms</span></button>' +
      '</div>';
  }

  async function renderRoomSchedule(active, params, el) {
    el.innerHTML = roomScheduleTabs(active) + '<div id="roomSchedulePanel" role="tabpanel"></div>';

    document.getElementById('roomScheduleTabs').addEventListener('click', function (event) {
      var tab = event.target.closest('[data-section]');
      if (!tab) return;
      var section = tab.getAttribute('data-section');
      if (section === active) return;
      App.go(section === 'schedules' ? 'schedules' : 'rooms');
    });

    var panel = document.getElementById('roomSchedulePanel');
    if (active === 'schedules') await scheduleWorkspace(params, panel);
    else await App.renderRoomDirectory(params, panel);
  }

  P.rooms = function (params, el) {
    return renderRoomSchedule('rooms', params, el);
  };

  P.schedules = function (params, el) {
    return renderRoomSchedule('schedules', params, el);
  };

  /* ============================== summary / shell ============================== */

  async function scheduleWorkspace(params, el) {
    var results = await Promise.all([
      App.api('/api/scheduling/meta'),
      App.api('/api/schedules/options'),
      App.api('/api/schedules')
    ]);
    var meta = results[0];
    var options = results[1];
    var schedules = results[2];
    var currentSemester = meta.semesters.find(function (s) { return s.isCurrent; }) || meta.semesters[0] || null;

    var state = {
      tab: 'timetable',
      semester: currentSemester ? currentSemester._id : '',
      course: '',
      room: '',
      instructor: '',
      plotsemester: currentSemester ? currentSemester._id : '',
      plotcourse: meta.courses.length ? meta.courses[0]._id : '',
      plotyear: 1,
      plotsection: '',
      plotsubject: '',
      plotday: 'MWF',
      plotstart: '',
      plotinstructor: ''
    };

    var tabs = [
      { key: 'timetable', label: 'Weekly timetable' },
      { key: 'plot', label: 'Plot a class' }
    ];

    el.innerHTML = App.pageHead({
      eyebrow: 'Scheduling',
      title: 'Schedules & rooms',
      sub: 'One workspace for the weekly grid and conflict-free plotting.',
      actions: '<button class="btn coral" type="button" id="goPlot">' + App.icon('plus') + 'Plot a class</button>'
    }) +
      '<div class="tabs" id="scheduleTabs" style="margin-bottom:16px">' +
      tabs.map(function (t) {
        return '<button class="tab' + (t.key === 'timetable' ? ' active' : '') + '" type="button" data-tab="' + t.key + '">' + App.esc(t.label) + '</button>';
      }).join('') + '</div>' +
      '<div id="schedPanel"></div>';

    var panel = document.getElementById('schedPanel');

    function setTab(tab) {
      state.tab = tab;
      document.querySelectorAll('#scheduleTabs .tab').forEach(function (b) {
        b.classList.toggle('active', b.getAttribute('data-tab') === tab);
      });
      render();
    }

    function render() {
      if (state.tab === 'plot') renderPlot();
      else renderTimetable();
    }

    document.getElementById('scheduleTabs').addEventListener('click', function (event) {
      var tab = event.target.closest('[data-tab]');
      if (tab) setTab(tab.getAttribute('data-tab'));
    });
    document.getElementById('goPlot').addEventListener('click', function () { setTab('plot'); });

    async function reloadSchedules() {
      schedules = await App.api('/api/schedules');
    }

    /* ------------------------------ timetable ------------------------------ */

    function renderTimetable() {
      var filtered = schedules.filter(function (s) {
        if (String(s.semester || '') !== String(state.semester || '')) return false;
        if (state.course && (!s.course || s.course._id !== state.course)) return false;
        if (state.room && (!s.room || s.room._id !== state.room)) return false;
        if (state.instructor && (!s.instructor || s.instructor._id !== state.instructor)) return false;
        return s.status === 'Active';
      }).sort(function (a, b) { return String(a.startTime).localeCompare(String(b.startTime)); });

      var sessions = App.normalizeSessions(filtered);
      var days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      if (sessions.some(function (s) { return (s.weekdays || []).indexOf('Sun') !== -1; })) days.push('Sun');

      panel.innerHTML = '<section class="card">' +
        '<div class="toolbar">' +
        '<select class="input" id="ttSemester" style="width:auto" aria-label="Semester">' +
        meta.semesters.map(function (s) {
          return '<option value="' + s._id + '"' + (s._id === state.semester ? ' selected' : '') + '>' + App.esc(s.label) + (s.isCurrent ? ' · current' : '') + '</option>';
        }).join('') + '</select>' +
        '<select class="input" id="ttCourse" style="width:auto" aria-label="Course"><option value="">All courses</option>' +
        meta.courses.map(function (c) { return '<option value="' + c._id + '"' + (c._id === state.course ? ' selected' : '') + '>' + App.esc(c.code) + '</option>'; }).join('') + '</select>' +
        '<select class="input" id="ttRoom" style="width:auto" aria-label="Room"><option value="">All rooms</option>' +
        meta.rooms.map(function (r) { return '<option value="' + r._id + '"' + (r._id === state.room ? ' selected' : '') + '>' + App.esc(r.roomCode) + '</option>'; }).join('') + '</select>' +
        '<select class="input" id="ttInstructor" style="width:auto" aria-label="Instructor"><option value="">All instructors</option>' +
        meta.instructors.map(function (i) { return '<option value="' + i._id + '"' + (i._id === state.instructor ? ' selected' : '') + '>' + App.esc(i.name) + '</option>'; }).join('') + '</select>' +
        '<span class="spacer"></span><span class="cell-sub">' + sessions.length + ' active section' + (sessions.length === 1 ? '' : 's') + '</span>' +
        '</div>' +
        (sessions.length
          ? App.timetable(sessions, { days: days, start: options.settings.dayStart, end: options.settings.dayEnd })
          : App.empty('No classes in this view', 'Change the filters or plot a new class.', 'calendar')) +
        '<div class="tt-legend"><span><i style="background:#f26a5a"></i>Class block — click for details</span>' +
        '<span><i style="background:#1c2a6b"></i>Room / instructor filters apply immediately</span></div>' +
        '</section>';

      ['ttSemester', 'ttCourse', 'ttRoom', 'ttInstructor'].forEach(function (id) {
        var map = { ttSemester: 'semester', ttCourse: 'course', ttRoom: 'room', ttInstructor: 'instructor' };
        document.getElementById(id).addEventListener('change', function (event) {
          state[map[id]] = event.target.value;
          renderTimetable();
        });
      });

      App.bindTimetable(panel, sessions, function (session) {
        var row = schedules.find(function (s) { return String(s._id) === String(session._id); });
        if (row) openSchedule(row);
      });
    }

    function openSchedule(schedule) {
      var subject = schedule.subject || {};
      var room = schedule.room || {};
      var instructor = schedule.instructor;
      var course = schedule.course || {};
      var semesterLabel = meta.semesters.find(function (s) { return s._id === String(schedule.semester); });
      App.modal({
        title: (subject.subjectCode || 'Class') + ' — ' + (subject.subjectName || ''),
        sub: sectionText(schedule) + ' · ' + (course.code || ''),
        wide: true,
        body: '<div class="grid-2" style="margin-bottom:0">' +
          '<div class="info-grid">' +
          '<div class="info-item"><span>Room</span><strong>' + App.esc(room.roomCode || '—') + ' · ' + App.esc(room.roomName || '') + '</strong></div>' +
          '<div class="info-item"><span>Instructor</span><strong>' + App.esc(instructor ? App.personName(instructor) : 'TBA') + '</strong></div>' +
          '<div class="info-item"><span>Days</span><strong>' + App.esc(App.daysInline(schedule.weekdays)) + '</strong></div>' +
          '<div class="info-item"><span>Time</span><strong>' + timeRange(schedule) + '</strong></div>' +
          '<div class="info-item"><span>Term</span><strong>' + App.esc(semesterLabel ? semesterLabel.label : '—') + '</strong></div>' +
          '<div class="info-item"><span>Status</span><strong>' + App.esc(schedule.status) + '</strong></div>' +
          '</div>' +
          '<div><div class="next-class"><div class="bar-accent"></div><div class="nc-text"><strong>' + App.esc(subject.subjectCode || '') + '</strong>' +
          '<span>' + (subject.units || 0) + ' units · ' + (subject.laboratoryRequired ? 'Laboratory' : 'Lecture') + '</span></div></div>' +
          '<p class="small muted" style="margin:12px 0 0">Editing re-runs every room, instructor and section conflict check on the server.</p></div>' +
          '</div>',
        footer: '<button class="btn ghost" type="button" data-close>Close</button>' +
          '<button class="btn danger" type="button" id="removeClass">Remove class</button>' +
          '<button class="btn coral" type="button" id="editClass">' + App.icon('edit') + 'Edit assignment</button>',
        onMount: function (wrap) {
          wrap.querySelector('#editClass').addEventListener('click', function () {
            App.closeModal();
            openAssignmentEditor(schedule);
          });
          wrap.querySelector('#removeClass').addEventListener('click', async function () {
            var ok = await App.confirm({
              title: 'Remove this class?',
              message: 'The schedule row is deleted. Any students already enrolled in this section will lose their class; the server refuses if enrollments exist.',
              okLabel: 'Remove class',
              danger: true
            });
            if (!ok) return;
            try {
              await App.api('/api/scheduling/schedules/' + schedule._id, { method: 'DELETE' });
              App.toast('Class removed from the timetable.');
              await reloadSchedules();
              renderTimetable();
            } catch (e) { App.toast(e.message, 'error'); }
          });
        }
      });
    }

    function openAssignmentEditor(schedule) {
      var subject = schedule.subject || {};
      var currentRoom = schedule.room && (schedule.room._id || schedule.room);
      var currentInstructor = schedule.instructor && (schedule.instructor._id || schedule.instructor);
      var days = schedule.weekdays || [];

      App.modal({
        title: 'Edit assignment',
        sub: subject.subjectCode + ' — ' + (subject.subjectName || '') + ' · ' + sectionText(schedule),
        wide: true,
        body: '<form id="assignmentForm"><div class="form-grid">' +
          '<label class="field span-2"><span>Class days</span><div style="display:flex;gap:8px;flex-wrap:wrap">' +
          ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(function (d) {
            return '<label class="chip" style="cursor:pointer"><input type="checkbox" name="days" value="' + d + '"' + (days.indexOf(d) !== -1 ? ' checked' : '') + ' style="margin-right:5px;accent-color:var(--navy)">' + App.dayNames[d].slice(0, 3) + '</label>';
          }).join('') + '</div></label>' +
          '<label class="field"><span>Start time</span><input type="time" name="startTime" required value="' + App.esc(schedule.startTime) + '"></label>' +
          '<label class="field"><span>Room</span><select name="room" required>' +
          meta.rooms.map(function (r) {
            return '<option value="' + r._id + '"' + (String(currentRoom) === r._id ? ' selected' : '') + '>' + App.esc(r.roomCode + ' — ' + r.roomName + ' (' + r.roomType + ', ' + r.capacity + ')') + '</option>';
          }).join('') + '</select></label>' +
          '<label class="field span-2"><span>Instructor</span><select name="instructor"><option value="">TBA</option>' +
          meta.instructors.map(function (i) {
            return '<option value="' + i._id + '"' + (String(currentInstructor) === i._id ? ' selected' : '') + '>' + App.esc(i.name) + '</option>';
          }).join('') + '</select></label>' +
          '<div class="form-error span-2" role="alert"></div></div>' +
          '<p class="small muted" style="margin:10px 0 0">End time is derived from the day pattern and subject units, so the session length rule stays enforced.</p></form>',
        footer: '<button class="btn ghost" type="button" data-close>Cancel</button><button class="btn coral" type="submit" form="assignmentForm">Save assignment</button>',
        onMount: function (wrap) {
          wrap.querySelector('#assignmentForm').addEventListener('submit', async function (event) {
            event.preventDefault();
            var form = event.currentTarget;
            var err = form.querySelector('.form-error');
            err.textContent = '';
            var picked = Array.prototype.filter.call(form.querySelectorAll('[name="days"]'), function (cb) { return cb.checked; })
              .map(function (cb) { return cb.value; });
            if (!picked.length) { err.textContent = 'Choose at least one class day.'; return; }
            try {
              await App.api('/api/scheduling/schedules/' + schedule._id, {
                method: 'PATCH',
                body: {
                  room: form.elements.room.value,
                  instructor: form.elements.instructor.value || null,
                  weekdays: picked,
                  startTime: form.elements.startTime.value
                }
              });
              App.toast('Assignment updated.');
              App.closeModal();
              await reloadSchedules();
              renderTimetable();
            } catch (e) { err.textContent = e.message; }
          });
        }
      });
    }

    /* ------------------------------ plotting ------------------------------ */

    function renderPlot() {
      panel.innerHTML = '<div class="grid-2">' +
        '<section class="card"><div class="card-head"><div><h2>Plot a class</h2><div class="card-sub">Only valid start times and rooms are offered</div></div></div>' +
        '<div class="form-grid">' +
        '<label class="field span-2"><span>Term</span><select id="plotSemester">' +
        meta.semesters.map(function (s) { return '<option value="' + s._id + '"' + (s._id === state.plotsemester ? ' selected' : '') + '>' + App.esc(s.label) + (s.isCurrent ? ' · current' : '') + '</option>'; }).join('') +
        '</select></label>' +
        '<label class="field"><span>Course</span><select id="plotCourse">' +
        meta.courses.map(function (c) { return '<option value="' + c._id + '"' + (c._id === state.plotcourse ? ' selected' : '') + '>' + App.esc(c.code) + '</option>'; }).join('') +
        '</select></label>' +
        '<label class="field"><span>Year level</span><select id="plotYear">' +
        [1, 2, 3, 4].map(function (y) { return '<option value="' + y + '"' + (y === Number(state.plotyear) ? ' selected' : '') + '>Year ' + y + '</option>'; }).join('') +
        '</select></label>' +
        '<label class="field"><span>Section</span><select id="plotSection" disabled><option value="">Loading sections…</option></select></label>' +
        '<label class="field"><span>Instructor (optional)</span><select id="plotInstructor"><option value="">TBA</option>' +
        meta.instructors.map(function (i) { return '<option value="' + i._id + '"' + (i._id === state.plotinstructor ? ' selected' : '') + '>' + App.esc(i.name) + '</option>'; }).join('') +
        '</select></label>' +
        '<label class="field span-2"><span>Subject</span><select id="plotSubject" disabled><option value="">Choose a section first</option></select></label>' +
        '<label class="field"><span>Day pattern</span><select id="plotDay">' +
        Object.keys(PATTERNS).map(function (key) {
          return '<option value="' + key + '"' + (key === state.plotday ? ' selected' : '') + '>' + App.esc(key) + ' — ' + PATTERNS[key].map(function (d) { return App.dayNames[d].slice(0, 3); }).join(', ') + '</option>';
        }).join('') + '</select></label>' +
        '<label class="field"><span>Start time</span><select id="plotStart" disabled><option value="">Choose a section and subject first</option></select></label>' +
        '</div>' +
        '<div class="divider"></div>' +
        '<div id="offeringHint" class="small muted">Choose a section to load the subject offerings.</div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">' +
        '<button class="btn ghost" type="button" id="toggleOffer" disabled>Mark offered</button>' +
        '</div>' +
        '<p class="small muted" style="margin:12px 0 0">Start times update automatically from the section, subject, instructor, day pattern and existing timetable. Rooms are checked for the full class duration.</p>' +
        '</section>' +
        '<section class="card"><div class="card-head"><div><h2>Room availability</h2><div class="card-sub" id="availabilitySub">Waiting for class details</div></div></div>' +
        '<div id="roomResults">' + App.empty('Choose a start time', 'Valid rooms will appear here automatically.', 'door') + '</div>' +
        '</section></div>';

      var sectionSelect = document.getElementById('plotSection');
      var subjectSelect = document.getElementById('plotSubject');
      var yearSelect = document.getElementById('plotYear');
      var startSelect = document.getElementById('plotStart');
      var offeringHint = document.getElementById('offeringHint');
      var toggleOffer = document.getElementById('toggleOffer');
      var availabilitySub = document.getElementById('availabilitySub');
      var roomResults = document.getElementById('roomResults');
      var offerings = [];
      var allSections = [];
      var sectionRequest = 0;
      var offeringRequest = 0;
      var availabilityRequest = 0;
      var assignInFlight = false;
      var assignmentError = '';

      function selectedSection() {
        var key = sectionSelect.value;
        if (!key) return null;
        var parts = key.split(':');
        if (parts[0] === 'B') return { key: key, sectionType: 'Block', blockLabel: parts.slice(2).join(':'), yearLevel: Number(parts[1]) };
        return { key: key, sectionType: 'Open', blockLabel: '', yearLevel: Number(parts[1]) };
      }

      function currentOffering() {
        return offerings.find(function (s) { return s._id === subjectSelect.value; });
      }

      function refreshOfferingHint() {
        var offering = currentOffering();
        if (!offering) {
          offeringHint.textContent = 'Choose a subject to see its offering state.';
          toggleOffer.disabled = true;
          return;
        }
        offeringHint.innerHTML = '<span class="status ' + (offering.offered ? '' : 'warn') + '">' + (offering.offered ? 'Offered' : 'Not offered') + '</span> ' +
          App.esc(offering.subjectCode) + ' · ' + offering.units + ' units' + (offering.laboratoryRequired ? ' · needs a laboratory room' : '') +
          ' <span class="muted">— plotting marks it offered automatically.</span>';
        toggleOffer.disabled = false;
        toggleOffer.textContent = offering.offered ? 'Withdraw offering' : 'Mark offered';
      }

      function startPlaceholder(text) {
        startSelect.innerHTML = '<option value="">' + App.esc(text) + '</option>';
        startSelect.disabled = true;
      }

      function resetRoomPanel(title, detail, icon) {
        availabilitySub.textContent = 'Waiting for a valid start time';
        roomResults.innerHTML = App.empty(title || 'Choose a start time', detail || 'Valid rooms will appear here automatically.', icon || 'door');
      }

      function invalidateAvailability() {
        availabilityRequest += 1;
      }

      function clearStartAndRooms(title, detail) {
        state.plotstart = '';
        assignmentError = '';
        invalidateAvailability();
        startPlaceholder('Choose a section and subject first');
        resetRoomPanel(title || 'Choose a section and subject', detail || 'Valid start times will load automatically.', 'clock');
      }

      function buildAvailabilityUrl(start) {
        var section = selectedSection();
        var offering = currentOffering();
        if (!section || !offering) return '';
        var url = '/api/scheduling/rooms/available?semester=' + encodeURIComponent(state.plotsemester) +
          '&course=' + encodeURIComponent(state.plotcourse) +
          '&sectionKey=' + encodeURIComponent(section.key) +
          '&day=' + encodeURIComponent(state.plotday) +
          '&subject=' + encodeURIComponent(offering._id);
        if (state.plotinstructor) url += '&instructor=' + encodeURIComponent(state.plotinstructor);
        if (start) url += '&startTime=' + encodeURIComponent(start);
        return url;
      }

      function loadSections() {
        var req = ++sectionRequest;
        offeringRequest += 1;
        sectionSelect.disabled = true;
        sectionSelect.innerHTML = '<option value="">Loading sections…</option>';
        subjectSelect.disabled = true;
        subjectSelect.innerHTML = '<option value="">Choose a section first</option>';
        offeringHint.textContent = 'Loading sections…';
        allSections = [];
        offerings = [];
        toggleOffer.disabled = true;
        clearStartAndRooms();
        return App.api('/api/scheduling/sections?semester=' + encodeURIComponent(state.plotsemester) + '&course=' + encodeURIComponent(state.plotcourse)).then(function (data) {
          if (req !== sectionRequest) return;
          allSections = data.sections || [];
          renderSectionOptions();
        }).catch(function (e) {
          if (req !== sectionRequest) return;
          sectionSelect.innerHTML = '<option value="">' + App.esc(e.message) + '</option>';
          subjectSelect.innerHTML = '<option value="">Choose a section first</option>';
          offeringHint.textContent = 'Could not load sections.';
          startPlaceholder('Choose a section and subject first');
          availabilitySub.textContent = 'Section lookup failed';
          roomResults.innerHTML = App.empty('Could not load sections', e.message, 'alert');
        });
      }

      function renderSectionOptions() {
        var year = Number(state.plotyear) || 1;
        var options = allSections.filter(function (s) { return Number(s.yearLevel) === year; });
        if (!options.length) {
          sectionSelect.disabled = true;
          sectionSelect.innerHTML = '<option value="">No sections for Year ' + year + '</option>';
          state.plotsection = '';
          state.plotsubject = '';
          offeringRequest += 1;
          offerings = [];
          subjectSelect.disabled = true;
          subjectSelect.innerHTML = '<option value="">No sections available</option>';
          refreshOfferingHint();
          clearStartAndRooms('No sections available', 'Choose another year level or term.', 'users');
          return;
        }
        sectionSelect.disabled = false;
        sectionSelect.innerHTML = options.map(function (s) {
          return '<option value="' + App.esc(s.key) + '">' + App.esc(s.label) + '</option>';
        }).join('');
        var keep = options.some(function (s) { return s.key === state.plotsection; });
        sectionSelect.value = keep ? state.plotsection : options[0].key;
        state.plotsection = sectionSelect.value;
        loadOfferings();
      }

      function loadOfferings() {
        var req = ++offeringRequest;
        var section = selectedSection();
        state.plotsubject = '';
        state.plotstart = '';
        assignmentError = '';
        invalidateAvailability();
        subjectSelect.disabled = true;
        subjectSelect.innerHTML = '<option value="">Loading subjects…</option>';
        offeringHint.textContent = 'Loading subject offerings…';
        startPlaceholder('Choose a subject to load valid start times');
        resetRoomPanel('Choose a subject', 'Valid start times load after a subject is selected.', 'clock');
        if (!section) return Promise.resolve();

        return App.api('/api/scheduling/offerings?semester=' + encodeURIComponent(state.plotsemester) + '&course=' + encodeURIComponent(state.plotcourse) + '&sectionKey=' + encodeURIComponent(section.key)).then(function (data) {
          if (req !== offeringRequest) return;
          offerings = data.subjects || [];
          if (!offerings.length) {
            subjectSelect.innerHTML = '<option value="">No subjects in this section</option>';
            offeringHint.textContent = 'Add subjects to the course prospectus for this year level and term.';
            toggleOffer.disabled = true;
            return;
          }
          subjectSelect.innerHTML = offerings.map(function (s) {
            return '<option value="' + s._id + '">' + App.esc(s.subjectCode + ' — ' + s.subjectName) + (s.offered ? ' · offered' : '') + (s.laboratoryRequired ? ' · lab' : '') + '</option>';
          }).join('');
          subjectSelect.disabled = false;
          state.plotsubject = offerings[0]._id;
          subjectSelect.value = state.plotsubject;
          refreshOfferingHint();
          loadValidTimes();
        }).catch(function (e) {
          if (req !== offeringRequest) return;
          subjectSelect.innerHTML = '<option value="">' + App.esc(e.message) + '</option>';
          offeringHint.textContent = 'Could not load subjects.';
          startPlaceholder('Choose a section and subject first');
          availabilitySub.textContent = 'Subject lookup failed';
          roomResults.innerHTML = App.empty('Could not load subjects', e.message, 'alert');
        });
      }

      async function loadValidTimes() {
        var section = selectedSection();
        var offering = currentOffering();
        var req = ++availabilityRequest;
        state.plotstart = '';
        assignmentError = '';
        if (!section || !offering) {
          startPlaceholder('Choose a section and subject first');
          resetRoomPanel();
          return;
        }
        startSelect.disabled = true;
        startSelect.innerHTML = '<option value="">Checking valid start times…</option>';
        availabilitySub.textContent = 'Checking the schedule rules…';
        roomResults.innerHTML = App.loading();
        try {
          var data = await App.api(buildAvailabilityUrl(''));
          if (req !== availabilityRequest) return;
          var times = data.validTimes || [];
          if (!times.length) {
            var reason = data.lengthError || (data.invalidTimes && data.invalidTimes[0] && data.invalidTimes[0].reason) || 'No start time can fit this class on the selected day.';
            startSelect.innerHTML = '<option value="">No valid start times</option>';
            startSelect.disabled = true;
            availabilitySub.textContent = (data.sessionMinutes ? data.sessionMinutes + ' minutes · ' : '') + 'No valid starts';
            roomResults.innerHTML = App.empty('No valid start times', reason, 'clock');
            return;
          }
          startSelect.innerHTML = '<option value="">Select a valid start time</option>' + times.map(function (t) {
            return '<option value="' + App.esc(t.start) + '">' + App.esc(t.label) + ' · ' + t.freeRooms + ' room' + (t.freeRooms === 1 ? '' : 's') + (t.recommended ? ' · recommended' : '') + '</option>';
          }).join('');
          startSelect.disabled = false;
          availabilitySub.textContent = (data.sessionMinutes ? data.sessionMinutes + ' minutes · ' : '') +
            times.length + ' valid start' + (times.length === 1 ? '' : 's') +
            (data.requiredSeats ? ' · ' + data.requiredSeats + ' planned seats' : '');
          if (data.recommendedStart) {
            // Consecutive periods are preferred automatically, but every
            // other valid start stays selectable and the save path rechecks it.
            availabilitySub.textContent += ' · recommended ' + App.time12(data.recommendedStart);
            await loadRooms(data.recommendedStart);
          } else {
            roomResults.innerHTML = App.empty('Choose a start time', 'Only rooms that pass every scheduling rule will be shown.', 'clock');
          }
        } catch (e) {
          if (req !== availabilityRequest) return;
          startSelect.innerHTML = '<option value="">Could not load start times</option>';
          startSelect.disabled = true;
          availabilitySub.textContent = 'Start time check failed';
          roomResults.innerHTML = App.empty('Could not load valid start times', e.message, 'alert');
        }
      }

      async function loadRooms(start, keepError) {
        var section = selectedSection();
        var offering = currentOffering();
        if (!section || !offering || !start) {
          resetRoomPanel();
          return;
        }
        var req = ++availabilityRequest;
        if (!keepError) assignmentError = '';
        state.plotstart = start;
        startSelect.value = start;
        availabilitySub.textContent = 'Checking rooms for the full class duration…';
        roomResults.innerHTML = App.loading();
        try {
          var data = await App.api(buildAvailabilityUrl(start));
          if (req !== availabilityRequest) return;
          startSelect.disabled = false;
          renderRoomResults(data, offering);
        } catch (e) {
          if (req !== availabilityRequest) return;
          startSelect.disabled = false;
          availabilitySub.textContent = 'Room check failed';
          roomResults.innerHTML = App.empty('Room availability failed', e.message, 'alert');
        }
      }

      function issueBox(title, detail) {
        return '<div class="next-class" style="background:var(--danger-soft)"><div class="bar-accent" style="background:var(--danger)"></div><div class="nc-text"><strong>' +
          App.esc(title) + '</strong><span>' + App.esc(detail) + '</span></div></div>';
      }

      function roomMeta(room) {
        var equipment = (room.equipment || []).filter(Boolean);
        return '<div class="info-grid">' +
          '<div class="info-item"><span>Room type</span><strong>' + App.esc(room.roomType) + '</strong></div>' +
          '<div class="info-item"><span>Capacity</span><strong>' + room.capacity + ' seats</strong></div>' +
          '<div class="info-item"><span>Building</span><strong>' + App.esc(room.building || 'Not set') + '</strong></div>' +
          '<div class="info-item"><span>Equipment</span><strong>' + App.esc(equipment.length ? equipment.join(', ') : 'No equipment listed') + '</strong></div>' +
          '</div>';
      }

      function renderRoomResults(data, offering) {
        var parts = [];
        if (data.sessionMinutes) parts.push(data.sessionMinutes + ' minutes');
        if (data.startTime && data.endTime) parts.push(App.time12(data.startTime) + '–' + App.time12(data.endTime));
        parts.push((data.available || []).length + ' room' + ((data.available || []).length === 1 ? '' : 's'));
        if (data.requiredSeats) parts.push(data.requiredSeats + ' planned seats');
        availabilitySub.textContent = parts.join(' · ') + (data.slotValid === false ? ' · blocked' : '');

        var head = '';
        if (assignmentError) head += issueBox('Could not plot the class', assignmentError);
        if (data.slotValid === false) {
          head += issueBox('This slot cannot be used', (data.slotIssues || []).map(function (i) { return i.message || i; }).join(' '));
        }

        var available = (data.available || []).map(function (r) {
          return '<details class="room-option" data-room-card="' + r._id + '">' +
            '<summary>' +
            '<span class="room-option-icon">' + App.icon('door') + '</span>' +
            '<span class="room-option-main"><strong>' + App.esc(r.roomCode + ' — ' + r.roomName) + '</strong>' +
            '<span class="sr-sub">' + App.esc(r.roomType) + (r.building ? ' · ' + App.esc(r.building) : '') + ' · ' + r.capacity + ' seats</span></span>' +
            '<span class="status">Available</span>' +
            '</summary>' +
            '<div class="room-option-body">' + roomMeta(r) +
            '<div class="room-option-actions">' +
            '<span class="small muted">' + App.esc((data.sessionMinutes || '') + ' minutes · ' + App.time12(data.startTime) + '–' + App.time12(data.endTime)) + '</span>' +
            '<button class="btn coral" type="button" data-confirm-room="' + r._id + '">' + App.icon('check') + 'Confirm &amp; Plot Class</button>' +
            '</div></div></details>';
        }).join('');

        var blocked = (data.blocked || []).map(function (r) {
          return '<div class="section-row full"><span><span class="sr-main">' + App.esc(r.roomCode + (r.roomName ? ' — ' + r.roomName : '')) + '</span><span class="sr-sub">' + App.esc(r.message) + '</span></span></div>';
        }).join('');

        roomResults.innerHTML = head +
          '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><strong style="font-size:12px">Available rooms</strong><span class="cell-sub">' + (data.available || []).length + ' free</span></div>' +
          (available ? '<div class="room-options">' + available + '</div>' : App.empty('No available rooms', 'Try another start time or day pattern.', 'door')) +
          (blocked ? '<details class="accordion" style="margin-top:14px"><summary>Unavailable rooms<span class="count">' + (data.blocked || []).length + '</span></summary><div class="accordion-body">' + blocked + '</div></details>' : '');

        roomResults.querySelectorAll('[data-confirm-room]').forEach(function (button) {
          button.addEventListener('click', function () { assignRoom(button.getAttribute('data-confirm-room'), button); });
        });
      }

      async function assignRoom(roomId, button) {
        if (assignInFlight) return;
        var section = selectedSection();
        var offering = currentOffering();
        if (!section || !offering || !state.plotstart) {
          App.toast('Choose a valid start time first.', 'warn');
          return;
        }
        assignInFlight = true;
        assignmentError = '';
        startSelect.disabled = true;
        roomResults.querySelectorAll('[data-confirm-room]').forEach(function (b) {
          b.disabled = true;
          if (b === button) b.innerHTML = 'Saving…';
        });
        try {
          await App.api('/api/scheduling/assign', {
            method: 'POST',
            body: {
              semester: state.plotsemester,
              course: state.plotcourse,
              sectionKey: section.key,
              yearLevel: section.yearLevel,
              sectionType: section.sectionType,
              blockLabel: section.blockLabel,
              subject: offering._id,
              room: roomId,
              weekdays: PATTERNS[state.plotday],
              startTime: state.plotstart,
              instructor: state.plotinstructor || null
            }
          });
        } catch (e) {
          assignmentError = e.message || 'Could not plot the class.';
          App.toast(assignmentError, 'error');
          assignInFlight = false;
          await loadRooms(state.plotstart, true);
          return;
        }

        var refreshError = null;
        try { await reloadSchedules(); } catch (e) { refreshError = e; }
        offering.offered = true;
        refreshOfferingHint();
        state.plotstart = '';
        assignmentError = '';
        assignInFlight = false;
        if (refreshError) App.toast('Class plotted, but the timetable could not refresh: ' + refreshError.message, 'warn');
        else App.toast('Class plotted and room reserved. Timetable updated.');
        await loadValidTimes();
      }

      document.getElementById('plotSemester').addEventListener('change', function (e) {
        state.plotsemester = e.target.value;
        state.plotsection = '';
        state.plotsubject = '';
        clearStartAndRooms();
        loadSections();
      });
      document.getElementById('plotCourse').addEventListener('change', function (e) {
        state.plotcourse = e.target.value;
        state.plotsection = '';
        state.plotsubject = '';
        clearStartAndRooms();
        loadSections();
      });
      yearSelect.addEventListener('change', function (e) {
        state.plotyear = Number(e.target.value) || 1;
        state.plotsection = '';
        state.plotsubject = '';
        offerings = [];
        clearStartAndRooms();
        renderSectionOptions();
      });
      sectionSelect.addEventListener('change', function () {
        state.plotsection = sectionSelect.value;
        loadOfferings();
      });
      subjectSelect.addEventListener('change', function () {
        state.plotsubject = subjectSelect.value;
        refreshOfferingHint();
        loadValidTimes();
      });
      document.getElementById('plotDay').addEventListener('change', function (e) {
        state.plotday = e.target.value;
        loadValidTimes();
      });
      startSelect.addEventListener('change', function (e) {
        var start = e.target.value;
        if (!start) {
          state.plotstart = '';
          assignmentError = '';
          invalidateAvailability();
          resetRoomPanel();
          return;
        }
        loadRooms(start);
      });
      document.getElementById('plotInstructor').addEventListener('change', function (e) {
        state.plotinstructor = e.target.value;
        loadValidTimes();
      });

      toggleOffer.addEventListener('click', async function () {
        var offering = currentOffering();
        if (!offering) return;
        var section = selectedSection();
        if (!section) return;
        toggleOffer.disabled = true;
        try {
          await App.api('/api/subject-offerings', {
            method: 'POST',
            body: {
              semesterId: state.plotsemester,
              courseId: state.plotcourse,
              yearLevel: section.yearLevel,
              sectionType: section.sectionType,
              blockLabel: section.blockLabel,
              subjectId: offering._id,
              offered: !offering.offered
            }
          });
          offering.offered = !offering.offered;
          refreshOfferingHint();
          App.toast(offering.offered ? 'Subject marked as offered.' : 'Subject withdrawn from this term.');
        } catch (e) { App.toast(e.message, 'error'); toggleOffer.disabled = false; }
      });

      resetRoomPanel('Choose a section and subject', 'Valid start times will load automatically.', 'clock');
      loadSections();
    }

    render();
  };

  function timeOptions(start, end, selected) {
    var s = App.toMinutes(start);
    var e = App.toMinutes(end);
    var options = [];
    for (var t = s; t < e; t += 30) {
      var value = String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0');
      options.push('<option value="' + value + '"' + (value === selected ? ' selected' : '') + '>' + App.time12(value) + '</option>');
    }
    return options.join('');
  }
})();
