(function () {
  'use strict';

  var form = document.getElementById('loginForm');
  var errorBox = document.getElementById('formError');
  var submit = document.getElementById('submitBtn');
  var toggle = document.getElementById('togglePassword');
  var password = document.getElementById('password');

  if (toggle && password) {
    toggle.addEventListener('click', function () {
      var showing = password.type === 'text';
      password.type = showing ? 'password' : 'text';
      toggle.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
      password.focus();
    });
  }

  function showError(message) {
    errorBox.textContent = message || '';
  }

  function portalHome(user) {
    return user && user.role === 'Admin' ? '/dashboard' : '/dashboard#/schedule';
  }

  // Already signed in? Go straight to the portal landing page.
  fetch('/api/auth/me', { credentials: 'same-origin' })
    .then(function (res) { return res.ok ? res.json() : null; })
    .then(function (data) { if (data && data.user) window.location.replace(portalHome(data.user)); })
    .catch(function () {});

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    showError('');
    var login = document.getElementById('login').value.trim();
    var pass = password.value;
    if (!login || !pass) {
      showError('Enter your email or username and password.');
      return;
    }

    submit.disabled = true;
    submit.textContent = 'Signing in…';

    fetch('/api/auth/csrf', { credentials: 'same-origin' })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        return fetch('/api/auth/login', {
          method: 'POST',
          credentials: 'same-origin',
          headers: {
            'Content-Type': 'application/json',
            'x-csrf-token': data.csrfToken
          },
          body: JSON.stringify({ login: login, password: pass })
        });
      })
      .then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (body) {
          if (!res.ok) throw new Error(body.message || 'Sign in failed. Please try again.');
          window.location.replace(portalHome({ role: body.role }));
        });
      })
      .catch(function (err) {
        showError(err.message);
        submit.disabled = false;
        submit.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/></svg> Sign in';
        password.focus();
      });
  });
})();
