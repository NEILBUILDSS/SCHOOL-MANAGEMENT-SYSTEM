/* ============================================================
   SELL SYSTEM — Student and Instructor portals
   ============================================================ */
(function () {
  'use strict';

  var P = App.pages = App.pages || {};
  var adminDashboard = P.dashboard;
  var adminSubjects = P.subjects;
  var adminStudentsPage = P.students;
  var adminStudentPage = P.student;
  var adminProspectusPage = P.prospectus;

  function role() { return App.state.me && App.state.me.role; }

  function greeting() {
    var h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 18) return 'Good afternoon';
    return 'Good evening';
  }

  function activeSchedules(rows) {
    return (rows || []).filter(function (s) { return s && s.status === 'Active'; });
  }

  function minutes(value) { return App.toMinutes(value); }

  function weeklyHours(schedules) {
    var total = 0;
    schedules.forEach(function (s) {
      var days = (s.weekdays || []).length;
      total += ((minutes(s.endTime) - minutes(s.startTime)) / 60) * days;
    });
    return Math.round(total * 10) / 10;
  }

  function nextClass(schedules) {
    var now = new Date();
    var todayIndex = now.getDay();
    var dayKeys = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    var nowMinutes = now.getHours() * 60 + now.getMinutes();
    var candidates = [];
    schedules.forEach(function (s) {
      (s.weekdays || []).forEach(function (day) {
        var index = dayKeys.indexOf(day);
        if (index === -1) return;
        var offset = (index - todayIndex + 7) % 7;
        var start = minutes(s.startTime);
        if (offset === 0 && start < nowMinutes) offset = 7;
        candidates.push({ schedule: s, offset: offset, start: start });
      });
    });
    candidates.sort(function (a, b) { return a.offset - b.offset || a.start - b.start; });
    return candidates[0] || null;
  }

  function todayClasses(schedules) {
    var day = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][new Date().getDay()];
    return schedules.filter(function (s) { return (s.weekdays || []).indexOf(day) !== -1; })
      .sort(function (a, b) { return minutes(a.startTime) - minutes(b.startTime); });
  }

  function settingsOf(data) {
    return data.settings || { dayStart: '07:30', dayEnd: '17:00' };
  }

  /* ============================== router by role ============================== */

  P.dashboard = function (params, el) {
    if (role() === 'Admin') return adminDashboard(params, el);
    // Student and Instructor portals do not have a dashboard; their landing
    // page is the weekly schedule.
    App.go('schedule');
  };

  P.subjects = function (params, el) {
    if (role() === 'Admin') return adminSubjects(params, el);
    if (role() === 'Student') return studentSubjects(params, el);
    // Instructors manage their subjects from the assigned list on My Schedule.
    App.go('schedule');
  };

  /* ============================== student dashboard ============================== */

  async function studentDashboard(params, el) {
    var results = await Promise.all([
      App.api('/api/portal/dashboard'),
      App.api('/api/student-portal/enrollments')
    ]);
    var data = results[0];
    var enrollments = results[1];
    var active = enrollments.filter(function (e) { return e.status === 'Active'; });
    var schedules = active.map(function (e) {
      if (e.schedule) e.schedule.subject = e.schedule.subject || e.subject;
      return e.schedule;
    }).filter(Boolean);
    var settings = settingsOf(data);
    var units = active.reduce(function (sum, e) { return sum + (e.subject ? e.subject.units : 0); }, 0);
    var instructors = {};
    schedules.forEach(function (s) { if (s.instructor) instructors[s.instructor] = true; });
    var next = nextClass(schedules);
    var today = todayClasses(schedules);
    var semesterLabel = App.state.semester ? App.state.semester.label : 'Current term';

    var subjectRows = active.length ? active.map(function (e) {
      return '<div class="list-row"><span class="badge-soft coral">' + App.esc(e.subject ? e.subject.subjectCode : '—') + '</span>' +
        '<div style="min-width:0"><div class="cell-main">' + App.esc(e.subject ? e.subject.subjectName : '') + '</div>' +
        '<div class="cell-sub">' + (e.schedule ? App.daysInline(e.schedule.weekdays) + ' · ' + App.time12(e.schedule.startTime) + '–' + App.time12(e.schedule.endTime) + ' · ' + App.esc(e.schedule.room) : '') + '</div></div>' +
        '<span class="badge-soft" style="margin-left:auto">' + (e.subject ? e.subject.units : 0) + 'u</span></div>';
    }).join('') : App.empty('Not enrolled yet', 'Open Enrollment to choose your sections for this term.', 'clipboard');

    el.innerHTML = App.pageHead({
      eyebrow: 'Student portal',
      title: greeting() + ', ' + (data.profile ? data.profile.firstName : 'student'),
      sub: semesterLabel + ' · ' + (data.profile && data.profile.course ? data.profile.course.code + ' — ' + data.profile.course.name : '') + ' · Year ' + (data.profile ? data.profile.yearLevel : '—'),
      actions: '<a class="btn ghost" href="#/schedule">' + App.icon('calendar') + 'My schedule</a><a class="btn coral" href="#/enrollment">' + App.icon('clipboard') + 'Open enrollment</a>'
    }) +
      '<div class="kpi-grid">' +
      '<div class="kpi"><div class="kpi-icon coral">' + App.icon('book') + '</div><div><div class="kpi-value">' + active.length + '</div><div class="kpi-label">Enrolled subjects</div></div></div>' +
      '<div class="kpi"><div class="kpi-icon">' + App.icon('chart') + '</div><div><div class="kpi-value">' + units + '</div><div class="kpi-label">Total units</div></div></div>' +
      '<div class="kpi"><div class="kpi-icon soft">' + App.icon('calendar') + '</div><div><div class="kpi-value">' + today.length + '</div><div class="kpi-label">Classes today</div></div></div>' +
      '<div class="kpi"><div class="kpi-icon">' + App.icon('teacher') + '</div><div><div class="kpi-value">' + Object.keys(instructors).length + '</div><div class="kpi-label">Instructors this term</div></div></div>' +
      '</div>' +
      '<div class="grid-2">' +
      '<section class="card"><div class="card-head"><div><h2>This week</h2><div class="card-sub">Your plotted classes for ' + App.esc(semesterLabel) + '</div></div>' +
      '<a class="card-link" href="#/schedule">Full schedule ' + App.icon('arrow') + '</a></div>' +
      (schedules.length
        ? App.timetable(App.normalizeSessions(schedules), { start: settings.dayStart, end: settings.dayEnd })
        : App.empty('No classes yet', 'Your enrolled subjects will appear here once sections are plotted.', 'calendar')) +
      '</section>' +
      '<div class="stack">' +
      '<section class="card"><div class="card-head"><div><h2>Next class</h2><div class="card-sub">Based on the stored timetable</div></div></div>' +
      (next
        ? '<div class="next-class" style="margin-top:0"><div class="bar-accent"></div><div class="nc-text"><strong>' + App.esc(next.schedule.subject ? next.schedule.subject.subjectCode + ' — ' + next.schedule.subject.subjectName : 'Class') + '</strong>' +
        '<span>' + App.esc(App.daysInline(next.schedule.weekdays)) + ' · ' + App.esc(next.schedule.room || '') + ' · ' + App.esc(next.schedule.instructor ? App.personName(next.schedule.instructor) : 'TBA') + '</span></div>' +
        '<div class="nc-time">' + App.time12(next.schedule.startTime) + '</div></div>'
        : '<div class="empty">' + App.icon('sun') + '<strong>No upcoming class</strong><span>Enjoy the break.</span></div>') +
      (today.length ? '<div class="divider"></div><div class="cell-sub" style="margin-bottom:8px">Today\'s classes</div>' +
        today.map(function (s) {
          return '<div class="list-row"><span class="badge-soft">' + App.time12(s.startTime) + '</span><div><div class="cell-main">' + App.esc(s.subject ? s.subject.subjectCode : '') + '</div><div class="cell-sub">' + App.esc(s.room || '') + '</div></div></div>';
        }).join('') : '') +
      '</section>' +
      '<section class="card"><div class="card-head"><div><h2>Enrolled subjects</h2><div class="card-sub">' + active.length + ' active</div></div></div>' + subjectRows + '</section>' +
      '</div></div>';
  }

  /* ============================== student enrollment ============================== */

  async function enrollmentPage(params, el) {
    var data = await App.api('/api/student-portal/enrollment-form');
    var selected = {};

    if (!data.hasProspectus) {
      el.innerHTML = App.pageHead({ eyebrow: 'Student portal', title: 'Enrollment', sub: data.academicYear + ' ' + data.term }) +
        '<div class="card">' + App.empty('No prospectus for your course', 'Ask the scheduling office to build the prospectus before enrolling.', 'list') + '</div>';
      return;
    }

    var isOpen = data.state === 'open';
    var totalSubjects = data.subjects.length;
    var selectable = data.subjects.filter(function (s) { return s.canSelect; });

    function sectionRow(subject, section) {
      var tone = section.status === 'Open' ? '' : ' full';
      return '<label class="section-row' + tone + '" data-subject="' + subject._id + '">' +
        '<input type="radio" name="subject_' + subject._id + '" value="' + section._id + '"' +
        (section.status === 'Open' ? '' : ' disabled') +
        ' data-subject="' + subject._id + '" data-type="' + App.esc(section.sectionType) + '" data-block="' + App.esc(section.blockLabel || '') + '" data-units="' + subject.units + '" data-code="' + App.esc(subject.subjectCode) + '">' +
        '<span><span class="sr-main">' + App.esc(App.daysInline(section.weekdays)) + ' · ' + App.time12(section.startTime) + '–' + App.time12(section.endTime) + '</span>' +
        '<span class="sr-sub">' + App.esc(section.room) + ' · ' + App.esc(section.instructor) + (section.sectionType === 'Block' ? ' · Block ' + App.esc(section.blockLabel) : '') + '</span></span>' +
        '<span class="sr-seats">' + (section.status === 'Open' ? section.seatsLeft + ' seat' + (section.seatsLeft === 1 ? '' : 's') : App.esc(section.status)) + '</span>' +
        '</label>';
    }

    function subjectCard(item) {
      var s = item.subject;
      var enrolled = item.enrolled;
      var head = '<div class="es-head"><div><h3>' + App.esc(s.subjectCode) + ' — ' + App.esc(s.subjectName) + '</h3>' +
        '<div class="es-meta">' + s.units + ' unit' + (s.units === 1 ? '' : 's') + ' · ' + App.esc(s.status) +
        (item.prerequisites.length ? ' · Prerequisite: ' + App.esc(item.prerequisites.map(function (p) { return p.subject.subjectCode; }).join(', ')) : '') +
        '</div></div><div style="margin-left:auto">' +
        (enrolled ? '<span class="status">Enrolled</span>' : App.status(item.progress === 'Upcoming' ? 'Not taken' : item.progress)) +
        '</div></div>';

      if (enrolled) {
        return '<article class="enroll-subject disabled">' + head +
          '<p class="small muted" style="margin:8px 0 0">You are already enrolled. Manage this subject from My Subjects.</p></article>';
      }
      if (!item.canSelect) {
        return '<article class="enroll-subject disabled">' + head +
          '<p class="small muted" style="margin:8px 0 0">' + App.esc(item.disabledReason) + '</p></article>';
      }
      return '<article class="enroll-subject">' + head +
        '<div class="es-body">' + item.sections.filter(function (sec) { return sec.status !== 'Full'; }).map(function (sec) { return sectionRow(s, sec); }).join('') +
        (item.sections.every(function (sec) { return sec.status === 'Full'; }) ? '<p class="small muted">Every section is full.</p>' : '') +
        '</div></article>';
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'Student portal',
      title: 'Enrollment',
      sub: data.academicYear + ' ' + data.term + ' · ' + data.student.course.code + ' — ' + data.student.course.name + ' · Year ' + data.student.yearLevel,
      actions: '<a class="btn ghost" href="#/subjects">' + App.icon('book') + 'My subjects</a>'
    }) +
      (!isOpen
        ? '<div class="card" style="margin-bottom:16px;border-left:4px solid var(--warn)"><div style="display:flex;gap:10px;align-items:flex-start">' + App.icon('alert') +
        '<div><strong style="font-size:13px">Enrollment is closed</strong><p class="small muted" style="margin:3px 0 0">The window for this term runs ' + App.fmtDate(data.enrollmentStart) + ' to ' + App.fmtDate(data.enrollmentEnd) + '. You can still review your enrolled subjects.</p></div></div></div>'
        : '') +
      '<div class="grid-2">' +
      '<div><div class="card-head" style="padding:0 2px"><div><h2>Available subjects</h2><div class="card-sub">' + selectable.length + ' of ' + totalSubjects + ' subject' + (totalSubjects === 1 ? '' : 's') + ' can be selected this term</div></div></div>' +
      '<div id="enrollList">' + (data.subjects.length ? data.subjects.map(subjectCard).join('') : App.empty('Nothing to enroll in', 'No subjects from your prospectus belong to this year level and term.', 'book')) + '</div></div>' +
      '<div><section class="card" style="position:sticky;top:16px">' +
      '<div class="card-head"><div><h2>Enrollment summary</h2><div class="card-sub">Choose one section per subject</div></div></div>' +
      '<div id="selectionList">' + App.empty('No sections selected', 'Pick a section on the left to begin.', 'clipboard') + '</div>' +
      '<div class="divider"></div>' +
      '<div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:6px"><span class="muted">Subjects</span><strong id="selCount">0</strong></div>' +
      '<div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:12px"><span class="muted">Units</span><strong id="selUnits">0</strong></div>' +
      '<div class="form-error" id="enrollError" role="alert"></div>' +
      '<button class="btn coral" type="button" id="submitEnrollment" style="width:100%"' + (isOpen ? '' : ' disabled') + '>Enroll in selected sections</button>' +
      '<p class="small muted" style="margin:10px 0 0">The server re-checks capacity, prerequisites, duplicate subjects and time conflicts in one scheduling lock. Enrollment takes effect immediately.</p>' +
      '</section></div></div>';

    var submit = document.getElementById('submitEnrollment');
    var error = document.getElementById('enrollError');

    function refreshSelection() {
      var checked = Array.prototype.slice.call(document.querySelectorAll('#enrollList input[type="radio"]:checked'));
      selected = {};
      checked.forEach(function (input) {
        selected[input.getAttribute('data-subject')] = {
          sectionId: input.value,
          type: input.getAttribute('data-type'),
          block: input.getAttribute('data-block'),
          units: Number(input.getAttribute('data-units')),
          code: input.getAttribute('data-code'),
          label: input.closest('.section-row').querySelector('.sr-main').textContent
        };
      });
      document.querySelectorAll('#enrollList .section-row').forEach(function (row) {
        var input = row.querySelector('input');
        row.classList.toggle('selected', Boolean(input && input.checked));
      });
      var ids = Object.keys(selected);
      document.getElementById('selCount').textContent = ids.length;
      document.getElementById('selUnits').textContent = ids.reduce(function (sum, id) { return sum + selected[id].units; }, 0);
      document.getElementById('selectionList').innerHTML = ids.length
        ? ids.map(function (id) {
          return '<div class="list-row"><span class="badge-soft coral">' + App.esc(selected[id].code) + '</span><div><div class="cell-main">' + App.esc(selected[id].label) + '</div><div class="cell-sub">' + selected[id].units + ' units · ' + App.esc(selected[id].type) + '</div></div></div>';
        }).join('')
        : App.empty('No sections selected', 'Pick a section on the left to begin.', 'clipboard');
      error.textContent = '';
    }

    document.getElementById('enrollList').addEventListener('change', refreshSelection);

    submit.addEventListener('click', async function () {
      error.textContent = '';
      var ids = Object.keys(selected);
      if (!ids.length) { error.textContent = 'Select at least one section.'; return; }
      var types = ids.map(function (id) { return selected[id].type; });
      var blocks = ids.map(function (id) { return selected[id].block; });
      if (types.some(function (t) { return t !== types[0]; })) {
        error.textContent = 'Choose either Open Sections or a single Block Section, not both.';
        return;
      }
      if (types[0] === 'Block' && blocks.some(function (b) { return b !== blocks[0]; })) {
        error.textContent = 'A block enrollment must use the same block label for every subject.';
        return;
      }
      submit.disabled = true;
      submit.textContent = 'Enrolling…';
      try {
        var result = await App.api('/api/student-portal/enroll', {
          method: 'POST',
          body: {
            scheduleIds: ids.map(function (id) { return selected[id].sectionId; }),
            sectionType: types[0],
            blockLabel: types[0] === 'Block' ? blocks[0] : ''
          }
        });
        App.toast(result.message || 'Enrollment completed.');
        App.go('subjects');
      } catch (e) {
        error.textContent = e.message;
        submit.disabled = false;
        submit.textContent = 'Enroll in selected sections';
      }
    });
  }

  /* ============================== student subjects ============================== */

  async function studentSubjects(params, el) {
    var rows = await App.api('/api/student-portal/enrollments');
    var active = rows.filter(function (r) { return r.status === 'Active'; });
    var history = rows.filter(function (r) { return r.status !== 'Active'; });

    function table(list, droppable) {
      if (!list.length) return '<tr><td colspan="5">' + App.empty('Nothing here', droppable ? 'Enroll in a subject to see it here.' : 'Completed records appear here.', 'book') + '</td></tr>';
      return list.map(function (e) {
        return '<tr><td><div class="cell-main">' + App.esc(e.subject ? e.subject.subjectCode : '—') + '</div><div class="cell-sub">' + App.esc(e.subject ? e.subject.subjectName : '') + '</div></td>' +
          '<td><div class="cell-main">' + (e.schedule ? App.esc(App.daysInline(e.schedule.weekdays)) : '—') + '</div><div class="cell-sub">' + (e.schedule ? App.time12(e.schedule.startTime) + '–' + App.time12(e.schedule.endTime) : '') + '</div></td>' +
          '<td><div class="cell-main">' + App.esc(e.schedule ? e.schedule.room : '—') + '</div><div class="cell-sub">' + App.esc(e.schedule ? e.schedule.instructor : '') + '</div></td>' +
          '<td><div class="cell-main">' + App.esc(e.semester ? e.semester.academicYear + ' ' + e.semester.term : '—') + '</div><div class="cell-sub">' + App.esc(e.result || '') + '</div></td>' +
          '<td class="right">' + App.status(e.status) + (droppable && e.status === 'Active'
            ? ' <button class="btn sm danger" type="button" data-drop="' + e._id + '">Drop</button>' : '') + '</td></tr>';
      }).join('');
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'Student portal',
      title: 'My subjects',
      sub: 'Your current load and academic history. Dropping a subject keeps the record as Dropped.',
      actions: '<a class="btn coral" href="#/enrollment">' + App.icon('plus') + 'Enroll in subjects</a>'
    }) +
      '<section class="card"><div class="card-head"><div><h2>Current enrollment</h2><div class="card-sub">' + active.length + ' subject' + (active.length === 1 ? '' : 's') + ' · ' + active.reduce(function (s, e) { return s + (e.subject ? e.subject.units : 0); }, 0) + ' units</div></div></div>' +
      '<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Schedule</th><th>Room &amp; instructor</th><th>Term / result</th><th class="right">Status</th></tr></thead><tbody>' +
      table(active, true) + '</tbody></table></div></section>' +
      '<section class="card" style="margin-top:16px"><div class="card-head"><div><h2>Academic history</h2><div class="card-sub">Dropped, passed, failed and credited records</div></div></div>' +
      '<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Schedule</th><th>Room &amp; instructor</th><th>Term / result</th><th class="right">Status</th></tr></thead><tbody>' +
      table(history, false) + '</tbody></table></div></section>';

    el.addEventListener('click', async function (event) {
      var drop = event.target.closest('[data-drop]');
      if (!drop) return;
      var ok = await App.confirm({
        title: 'Drop this subject?',
        message: 'The seat is released immediately and the record is kept as Dropped. You can re-enroll while the window is open.',
        okLabel: 'Drop subject',
        danger: true
      });
      if (!ok) return;
      try {
        await App.api('/api/student-portal/drop', { method: 'POST', body: { enrollmentId: drop.getAttribute('data-drop') } });
        App.toast('Subject dropped.');
        App.render();
      } catch (e) { App.toast(e.message, 'error'); }
    });
  }

  /* ============================== student schedule ============================== */

  async function studentSchedule(params, el) {
    var schedules = await App.api('/api/portal/my-schedule');
    var dayOrder = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    schedules.sort(function (a, b) {
      var ad = (a.weekdays || []).map(function (d) { return dayOrder.indexOf(d); }).filter(function (n) { return n >= 0; });
      var bd = (b.weekdays || []).map(function (d) { return dayOrder.indexOf(d); }).filter(function (n) { return n >= 0; });
      var firstA = ad.length ? Math.min.apply(null, ad) : 99;
      var firstB = bd.length ? Math.min.apply(null, bd) : 99;
      return firstA - firstB || App.toMinutes(a.startTime) - App.toMinutes(b.startTime);
    });

    var meetings = schedules.reduce(function (n, s) { return n + (s.weekdays || []).length; }, 0);

    function sectionOf(s) {
      return (s.sectionType === 'Block'
        ? 'Block ' + (s.blockLabel || '—')
        : 'Open Section') + ' · Year ' + (s.yearLevel || '—');
    }

    function instructorOf(s) {
      return s.instructor ? App.personName(s.instructor) : 'TBA';
    }

    function openDetails(s) {
      var subject = s.subject || {};
      App.modal({
        title: (subject.subjectCode || 'Class') + ' — ' + (subject.subjectName || ''),
        sub: App.daysInline(s.weekdays || []) + ' · ' + App.time12(s.startTime) + '–' + App.time12(s.endTime),
        body: '<div class="info-grid">' +
          '<div class="info-item"><span>Room</span><strong>' + App.esc(s.room ? s.room.roomCode : '—') + '</strong></div>' +
          '<div class="info-item"><span>Instructor</span><strong>' + App.esc(instructorOf(s)) + '</strong></div>' +
          '<div class="info-item"><span>Course</span><strong>' + App.esc(s.course ? s.course.code + ' — ' + s.course.name : '—') + '</strong></div>' +
          '<div class="info-item"><span>Section</span><strong>' + App.esc(sectionOf(s)) + '</strong></div>' +
          '</div>'
      });
    }

    var rows = schedules.length ? schedules.map(function (s, index) {
      var subject = s.subject || {};
      var label = (subject.subjectCode || '') + ' — ' + (subject.subjectName || '');
      return '<tr class="row-link" data-schedule="' + index + '" tabindex="0" role="link" aria-label="Open ' + App.esc(label) + '">' +
        '<td><div class="cell-main">' + App.esc(subject.subjectCode || '—') + '</div><div class="cell-sub">' + App.esc(subject.subjectName || '') + '</div></td>' +
        '<td><div class="cell-main">' + App.esc(sectionOf(s)) + '</div><div class="cell-sub">' + App.esc(s.course ? s.course.code : '') + '</div></td>' +
        '<td>' + App.esc(App.daysInline(s.weekdays || [])) + '</td>' +
        '<td class="nowrap"><div class="cell-main">' + App.time12(s.startTime) + '–' + App.time12(s.endTime) + '</div></td>' +
        '<td><div class="cell-main">' + App.esc(s.room ? s.room.roomCode : '—') + '</div><div class="cell-sub">' + App.esc(s.room ? s.room.roomName : '') + '</div></td>' +
        '<td>' + App.esc(instructorOf(s)) + '</td>' +
        '<td class="right"><button class="btn-icon" type="button" data-details="' + index + '" title="View class details">' + App.icon('eye') + '</button></td></tr>';
    }).join('') : '<tr><td colspan="7">' + App.empty('No classes plotted', 'Your enrolled sections will appear here once the scheduling office plots them.', 'calendar') + '</td></tr>';

    el.innerHTML = App.pageHead({
      eyebrow: 'Student portal',
      title: 'My schedule',
      sub: (App.state.semester ? App.state.semester.label : 'Current term') + ' · ' + schedules.length + ' subject' + (schedules.length === 1 ? '' : 's') + ' · ' + meetings + ' session' + (meetings === 1 ? '' : 's') + ' per week',
      actions: '<button class="btn ghost" type="button" id="printStudentSchedule">' + App.icon('print') + 'Print</button>'
    }) +
      '<section class="card"><div class="card-head"><div><h2>Class schedule</h2><div class="card-sub">Your enrolled sections for the current term. Click a row for class details.</div></div></div>' +
      '<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Section</th><th>Day</th><th>Time</th><th>Room</th><th>Instructor</th><th class="right">Details</th></tr></thead><tbody>' + rows + '</tbody></table></div></section>';

    document.getElementById('printStudentSchedule').addEventListener('click', function () { window.print(); });

    function openFromRow(event) {
      var row = event.target.closest('[data-schedule]');
      if (!row) return;
      openDetails(schedules[Number(row.getAttribute('data-schedule'))]);
    }
    function handleKey(event) {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      if (event.target.closest('button, a')) return;
      var row = event.target.closest('[data-schedule]');
      if (!row) return;
      event.preventDefault();
      openDetails(schedules[Number(row.getAttribute('data-schedule'))]);
    }

    el.addEventListener('click', openFromRow);
    el.addEventListener('keydown', handleKey);
    App.onCleanup(function () {
      el.removeEventListener('click', openFromRow);
      el.removeEventListener('keydown', handleKey);
    });
  }

  /* ============================== student prospectus ============================== */

  async function studentProspectus(params, el) {
    var data = await App.api('/api/student-portal/prospectus');
    var groups = {};
    data.items.forEach(function (i) {
      var key = i.yearLevel + '|' + i.term;
      if (!groups[key]) groups[key] = { year: i.yearLevel, term: i.term, items: [] };
      groups[key].items.push(i);
    });
    var list = Object.keys(groups).map(function (k) { return groups[k]; }).sort(function (a, b) { return a.year - b.year || a.term.localeCompare(b.term); });

    var currentYear = data.student.yearLevel;
    var currentTerm = App.state.semester ? App.state.semester.term : '';

    el.innerHTML = App.pageHead({
      eyebrow: 'Student portal',
      title: 'Prospectus',
      sub: data.student.course.code + ' — ' + data.student.course.name + ' · ' + data.items.length + ' subject' + (data.items.length === 1 ? '' : 's') + ' across the program'
    }) +
      '<div class="card">' +
      (list.length ? list.map(function (g) {
        var units = g.items.reduce(function (s, i) { return s + (i.subject.units || 0); }, 0);
        var isNow = g.year === currentYear && g.term === currentTerm;
        return '<details class="accordion"' + (isNow || g.year === 1 && g.term === '1st Semester' ? ' open' : '') + '>' +
          '<summary>Year ' + g.year + ' · ' + App.esc(g.term) + (isNow ? ' <span class="status coral" style="margin-left:6px">This term</span>' : '') +
          '<span class="count">' + g.items.length + ' subject' + (g.items.length === 1 ? '' : 's') + ' · ' + units + ' units</span></summary>' +
          '<div class="accordion-body"><div class="table-wrap"><table><thead><tr><th>Code</th><th>Subject</th><th class="num">Units</th><th>Status</th></tr></thead><tbody>' +
          g.items.map(function (i) {
            return '<tr><td class="cell-main">' + App.esc(i.subject.subjectCode) + '</td><td>' + App.esc(i.subject.subjectName) + '</td>' +
              '<td class="num">' + i.subject.units + '</td><td>' + App.status(i.subject.status) + '</td></tr>';
          }).join('') + '</tbody></table></div></div></details>';
      }).join('') : App.empty('No prospectus yet', 'Ask the scheduling office to publish your curriculum.', 'list')) +
      '</div>';
  }

  /* ============================== instructor dashboard ============================== */

  async function instructorDashboard(params, el) {
    var results = await Promise.all([
      App.api('/api/portal/dashboard'),
      App.api('/api/instructor-portal/subjects')
    ]);
    var data = results[0];
    var teaching = results[1];
    var schedules = teaching.subjects.map(function (s) {
      s.weekdays = s.days || s.weekdays || [];
      return s;
    });
    var settings = settingsOf(data);
    var hours = weeklyHours(schedules);
    var today = todayClasses(schedules);
    var next = nextClass(schedules);
    var totalStudents = schedules.reduce(function (sum, s) { return sum + s.studentCount; }, 0);

    var cards = schedules.length ? schedules.map(function (s) {
      return '<a class="subject-card" href="#/subject/' + s._id + '" style="color:inherit;text-decoration:none">' +
        '<div class="subject-code">' + App.esc(s.subject ? s.subject.subjectCode : '') + '</div>' +
        '<h3>' + App.esc(s.subject ? s.subject.subjectName : '') + '</h3>' +
        '<div class="row"><span>Section</span><b>' + App.esc(s.section) + '</b></div>' +
        '<div class="row"><span>Schedule</span><b>' + App.esc(s.daysLabel) + '</b></div>' +
        '<div class="row"><span>Room</span><b>' + App.esc(s.room ? s.room.roomCode : '—') + '</b></div>' +
        '<div class="row"><span>Class size</span><b>' + s.studentCount + ' / ' + s.capacity + '</b></div>' +
        '<div class="progress-track" style="margin-top:6px"><i style="width:' + Math.min(100, Math.round((s.studentCount / Math.max(s.capacity, 1)) * 100)) + '%"></i></div>' +
        '</a>';
    }).join('') : App.empty('No teaching load', 'The scheduling office has not plotted a class for you this term.', 'calendar');

    el.innerHTML = App.pageHead({
      eyebrow: 'Instructor portal',
      title: greeting() + ', ' + (data.profile ? data.profile.firstName : 'instructor'),
      sub: (teaching.semester || 'Current term') + ' · ' + (data.profile ? data.profile.department : ''),
      actions: '<a class="btn ghost" href="#/schedule">' + App.icon('calendar') + 'My schedule</a><a class="btn coral" href="#/subjects">' + App.icon('book') + 'My subjects</a>'
    }) +
      '<div class="kpi-grid">' +
      '<div class="kpi"><div class="kpi-icon coral">' + App.icon('book') + '</div><div><div class="kpi-value">' + schedules.length + '</div><div class="kpi-label">Class sections</div></div></div>' +
      '<div class="kpi"><div class="kpi-icon">' + App.icon('users') + '</div><div><div class="kpi-value">' + totalStudents + '</div><div class="kpi-label">Students taught</div></div></div>' +
      '<div class="kpi"><div class="kpi-icon soft">' + App.icon('clock') + '</div><div><div class="kpi-value">' + hours + 'h</div><div class="kpi-label">Weekly contact hours</div></div></div>' +
      '<div class="kpi"><div class="kpi-icon">' + App.icon('calendar') + '</div><div><div class="kpi-value">' + today.length + '</div><div class="kpi-label">Classes today</div></div></div>' +
      '</div>' +
      '<div class="grid-2">' +
      '<section class="card"><div class="card-head"><div><h2>Weekly timetable</h2><div class="card-sub">Your active sections</div></div>' +
      '<a class="card-link" href="#/schedule">Open full ' + App.icon('arrow') + '</a></div>' +
      (schedules.length
        ? App.timetable(App.normalizeSessions(schedules), { start: settings.dayStart, end: settings.dayEnd })
        : App.empty('Nothing plotted', 'Your weekly classes appear here.', 'calendar')) +
      '</section>' +
      '<section class="card"><div class="card-head"><div><h2>Next class</h2><div class="card-sub">' + (today.length ? today.length + ' class' + (today.length === 1 ? '' : 'es') + ' today' : 'No classes today') + '</div></div></div>' +
      (next
        ? '<div class="next-class" style="margin-top:0"><div class="bar-accent"></div><div class="nc-text"><strong>' + App.esc(next.schedule.subject ? next.schedule.subject.subjectCode + ' — ' + next.schedule.subject.subjectName : 'Class') + '</strong>' +
        '<span>' + App.esc(next.schedule.daysLabel || App.daysInline(next.schedule.weekdays)) + ' · ' + App.esc(next.schedule.room ? next.schedule.room.roomCode : '') + ' · ' + App.esc(next.schedule.course ? next.schedule.course.code : '') + '</span></div>' +
        '<div class="nc-time">' + App.time12(next.schedule.startTime) + '</div></div>'
        : '<div class="empty">' + App.icon('sun') + '<strong>No upcoming class</strong><span>Your plotted timetable will appear here.</span></div>') +
      (today.length ? '<div class="divider"></div>' + today.map(function (s) {
        return '<div class="list-row"><span class="badge-soft">' + App.time12(s.startTime) + '</span><div><div class="cell-main">' + App.esc(s.subject ? s.subject.subjectCode : '') + '</div>' +
          '<div class="cell-sub">' + App.esc(s.room ? s.room.roomCode : '') + ' · ' + App.esc(s.course ? s.course.code : '') + '</div></div>' +
          '<a class="card-link" style="margin-left:auto" href="#/subject/' + s._id + '">Roster</a></div>';
      }).join('') : '') +
      '</section></div>' +
      '<section class="card"><div class="card-head"><div><h2>My subjects this term</h2><div class="card-sub">Open a subject to manage its roster and class records</div></div></div>' +
      '<div class="subject-grid">' + cards + '</div></section>';
  }

  /* ============================== instructor subjects ============================== */

  async function instructorSubjects(params, el) {
    var data = await App.api('/api/instructor-portal/subjects');
    var rows = data.subjects;

    el.innerHTML = App.pageHead({
      eyebrow: 'Instructor portal',
      title: 'My subjects',
      sub: data.semester || 'Current term',
      actions: '<a class="btn ghost" href="#/students">' + App.icon('users') + 'All students</a>'
    }) +
      '<section class="card">' +
      (rows.length ? '<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Section</th><th>Schedule</th><th>Room</th><th class="num">Class size</th><th class="right">Open</th></tr></thead><tbody>' +
        rows.map(function (s) {
          return '<tr><td><div class="cell-main">' + App.esc(s.subject ? s.subject.subjectCode : '') + '</div><div class="cell-sub">' + App.esc(s.subject ? s.subject.subjectName : '') + '</div></td>' +
            '<td><div class="cell-main">' + App.esc(s.section) + '</div><div class="cell-sub">' + App.esc(s.course ? s.course.code : '') + '</div></td>' +
            '<td><div class="cell-main">' + App.esc(s.daysLabel) + '</div><div class="cell-sub">' + App.time12(s.startTime) + '–' + App.time12(s.endTime) + '</div></td>' +
            '<td>' + App.esc(s.room ? s.room.roomCode : '—') + '<div class="cell-sub">' + App.esc(s.room ? s.room.roomType : '') + '</div></td>' +
            '<td class="num">' + s.studentCount + ' / ' + s.capacity + '</td>' +
            '<td class="right"><a class="btn ghost sm" href="#/subject/' + s._id + '">' + App.icon('eye') + 'Manage</a></td></tr>';
        }).join('') + '</tbody></table></div>'
        : App.empty('No subjects this term', 'The scheduling office has not assigned a class to you.', 'book')) +
      '</section>';
  }

  /* ============================== instructor class ============================== */

  async function instructorClass(params, el) {
    var data = await App.api('/api/instructor-portal/subjects/' + params[0]);
    var records = await App.api('/api/instructor-portal/subjects/' + params[0] + '/records');
    var schedule = data.schedule;
    var tab = 'roster';

    function rosterTable() {
      if (!records.students.length) return App.empty('No students enrolled', 'Officially enrolled students appear here once they enroll in this section.', 'users');
      return '<p class="small muted" style="margin:0 0 10px">' + records.students.length + ' of ' + data.capacity + ' class-list slots used. Only officially enrolled students are shown.</p>' +
        '<div class="table-wrap"><table><thead><tr><th>Student</th><th>Student ID</th><th>Course</th><th>Year</th><th class="right">Status</th></tr></thead><tbody>' +
        records.students.map(function (row) {
          var s = row.student || {};
          return '<tr><td><div class="cell-main">' + App.esc(App.personName(s)) + '</div></td>' +
            '<td>' + App.esc(s.studentId || '—') + '</td>' +
            '<td>' + App.esc(s.course ? s.course.code : '—') + '</td>' +
            '<td>Year ' + App.esc(s.yearLevel || '—') + '</td>' +
            '<td class="right">' + App.status(row.status || 'Enrolled') + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }

    function recordsTable() {
      if (!records.students.length) return App.empty('No students enrolled', 'Class records become available once students enroll.', 'clipboard');
      return '<p class="small muted" style="margin:0 0 10px">Class Record holds attendance, assignments and activities only. Save the sheet once after editing the class.</p>' +
        '<form id="recordsForm"><div class="table-wrap"><table><thead><tr><th>Student</th><th class="num">Attendance</th><th class="num">Assignments</th><th class="num">Activities</th><th>Updated</th></tr></thead><tbody>' +
        records.students.map(function (row) {
          var s = row.student || {};
          var rec = row.record || {};
          return '<tr data-enrollment="' + row.enrollment + '">' +
            '<td><div class="cell-main">' + App.esc(App.personName(s)) + '</div><div class="cell-sub">' + App.esc(s.studentId || '') + '</div></td>' +
            '<td class="num" style="min-width:130px"><div style="display:flex;align-items:center;gap:4px;justify-content:flex-end"><input class="input" style="width:64px;padding:6px 8px;text-align:right" type="number" min="0" max="' + (records.attendanceTotal || '') + '" name="attendance" value="' + (rec.attendancePresent == null ? '' : rec.attendancePresent) + '"><span class="cell-sub">/ ' + (records.attendanceTotal || '—') + '</span></div></td>' +
            '<td class="num"><input class="input" style="width:74px;padding:6px 8px;text-align:right" type="number" min="0" max="100" name="assignments" value="' + (rec.assignments == null ? '' : rec.assignments) + '"></td>' +
            '<td class="num"><input class="input" style="width:74px;padding:6px 8px;text-align:right" type="number" min="0" max="100" name="activities" value="' + (rec.activities == null ? '' : rec.activities) + '"></td>' +
            '<td class="cell-sub">' + (rec.updatedAt ? App.fmtDateTime(rec.updatedAt) : 'Not saved') + '</td></tr>';
        }).join('') + '</tbody></table></div>' +
        '<div class="form-error" role="alert" style="margin-top:10px"></div>' +
        '<div style="display:flex;align-items:center;gap:10px;margin-top:12px"><span class="cell-sub">Attendance is capped at the ' + (records.attendanceTotal || 0) + ' class sessions in this term.</span>' +
        '<button class="btn coral" type="submit" style="margin-left:auto">Save class records</button></div></form>';
    }

    function bindRecords() {
      var form = document.getElementById('recordsForm');
      if (!form) return;
      form.addEventListener('submit', async function (event) {
        event.preventDefault();
        var err = form.querySelector('.form-error');
        err.textContent = '';
        var rows = [];
        form.querySelectorAll('tbody tr[data-enrollment]').forEach(function (tr) {
          rows.push({
            enrollment: tr.getAttribute('data-enrollment'),
            attendancePresent: tr.querySelector('[name="attendance"]').value,
            assignments: tr.querySelector('[name="assignments"]').value,
            activities: tr.querySelector('[name="activities"]').value
          });
        });
        try {
          var result = await App.api('/api/instructor-portal/subjects/' + params[0] + '/records', { method: 'POST', body: { rows: rows } });
          App.toast(result.message || 'Class records saved.');
          App.render();
        } catch (e) { err.textContent = e.message; }
      });
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'Instructor portal',
      title: (data.subject ? data.subject.subjectCode + ' — ' + data.subject.subjectName : 'Class'),
      sub: schedule.section + ' · Year ' + schedule.yearLevel + ' · ' + (data.course ? data.course.code : '') + ' · ' + schedule.daysLabel + ' ' + App.time12(schedule.startTime) + '–' + App.time12(schedule.endTime) + ' · ' + (data.room ? data.room.roomCode : ''),
      actions: '<a class="btn ghost" href="#/schedule">Back to My Schedule</a>'
    }) +
      '<div class="kpi-grid">' +
      '<div class="kpi"><div class="kpi-icon coral">' + App.icon('users') + '</div><div><div class="kpi-value">' + data.studentCount + '</div><div class="kpi-label">Enrolled students</div></div></div>' +
      '<div class="kpi"><div class="kpi-icon">' + App.icon('chart') + '</div><div><div class="kpi-value">' + data.capacity + '</div><div class="kpi-label">Class-list maximum</div></div></div>' +
      '<div class="kpi"><div class="kpi-icon soft">' + App.icon('clock') + '</div><div><div class="kpi-value">' + data.attendanceTotal + '</div><div class="kpi-label">Class sessions</div></div></div>' +
      '<div class="kpi"><div class="kpi-icon">' + App.icon('book') + '</div><div><div class="kpi-value">' + (data.subject ? data.subject.units : 0) + '</div><div class="kpi-label">Units</div></div></div>' +
      '</div>' +
      '<section class="card"><div class="toolbar">' +
      '<div class="tabs" id="classTabs"><button class="tab active" type="button" data-ctab="roster">Class List</button><button class="tab" type="button" data-ctab="records">Class Record</button></div>' +
      '<span class="spacer"></span><span class="cell-sub">' + (data.semester || '') + '</span></div>' +
      '<div id="classPanel">' + rosterTable() + '</div></section>';

    document.getElementById('classTabs').addEventListener('click', function (event) {
      var btn = event.target.closest('[data-ctab]');
      if (!btn) return;
      tab = btn.getAttribute('data-ctab');
      document.querySelectorAll('#classTabs .tab').forEach(function (b) { b.classList.toggle('active', b === btn); });
      var panel = document.getElementById('classPanel');
      panel.innerHTML = tab === 'roster' ? rosterTable() : recordsTable();
      if (tab === 'records') bindRecords();
    });
  }

  /* ============================== instructor schedule ============================== */

  async function instructorSchedule(params, el) {
    var data = await App.api('/api/instructor-portal/subjects');
    var dayOrder = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    data.subjects.forEach(function (s) { s.weekdays = s.days || s.weekdays || []; });
    // Natural weekly order: earliest meeting day, then earliest start time.
    data.subjects.sort(function (a, b) {
      var ad = (a.weekdays || []).map(function (d) { return dayOrder.indexOf(d); }).filter(function (n) { return n >= 0; });
      var bd = (b.weekdays || []).map(function (d) { return dayOrder.indexOf(d); }).filter(function (n) { return n >= 0; });
      var firstA = ad.length ? Math.min.apply(null, ad) : 99;
      var firstB = bd.length ? Math.min.apply(null, bd) : 99;
      return firstA - firstB || App.toMinutes(a.startTime) - App.toMinutes(b.startTime);
    });

    function sectionOf(s) {
      var label = s.sectionType === 'Block'
        ? 'Block ' + (s.blockLabel || '—')
        : 'Open Section';
      return label + ' · Year ' + (s.yearLevel || '—');
    }

    var rows = data.subjects.length ? data.subjects.map(function (s) {
      var subject = s.subject || {};
      var section = sectionOf(s);
      var label = (subject.subjectCode || '') + ' — ' + (subject.subjectName || '');
      return '<tr class="row-link" data-open="' + s._id + '" tabindex="0" role="link" aria-label="Open ' + App.esc(label) + '">' +
        '<td><div class="cell-main">' + App.esc(subject.subjectCode || '—') + '</div><div class="cell-sub">' + App.esc(subject.subjectName || '') + '</div></td>' +
        '<td><div class="cell-main">' + App.esc(section) + '</div><div class="cell-sub">' + App.esc(s.course ? s.course.code : '') + '</div></td>' +
        '<td>' + App.esc(s.daysLabel || App.daysInline(s.weekdays)) + '</td>' +
        '<td class="nowrap"><div class="cell-main">' + App.time12(s.startTime) + '–' + App.time12(s.endTime) + '</div></td>' +
        '<td><div class="cell-main">' + App.esc(s.room ? s.room.roomCode : '—') + '</div><div class="cell-sub">' + App.esc(s.room ? s.room.roomName : '') + '</div></td>' +
        '<td class="num">' + s.studentCount + ' / ' + s.capacity + '</td>' +
        '<td class="right"><a class="btn-icon" href="#/subject/' + s._id + '" title="Open class list and class record">' + App.icon('eye') + '</a></td></tr>';
    }).join('') : '<tr><td colspan="7">' + App.empty('No classes plotted', 'The scheduling office has not assigned a class to you for this term.', 'calendar') + '</td></tr>';

    el.innerHTML = App.pageHead({
      eyebrow: 'Instructor portal',
      title: 'My schedule',
      sub: (data.semester || 'Current term') + ' · ' + data.subjects.length + ' assigned subject' + (data.subjects.length === 1 ? '' : 's') +
        ' · class lists are capped at 10 students'
    }) +
      '<section class="card" style="margin-bottom:16px"><div class="card-head"><div><h2>Assigned subjects</h2><div class="card-sub">Click a subject to open its official class list and class record</div></div></div>' +
      '<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Section</th><th>Day</th><th>Time</th><th>Room</th><th class="num">Class list</th><th class="right">Open</th></tr></thead><tbody>' + rows + '</tbody></table></div></section>';

    function openFromRow(event) {
      if (event.target.closest('a, button')) return;
      var row = event.target.closest('[data-open]');
      if (row) App.go('subject/' + row.getAttribute('data-open'));
    }
    function handleKey(event) {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      if (event.target.closest('a, button')) return;
      var row = event.target.closest('[data-open]');
      if (!row) return;
      event.preventDefault();
      App.go('subject/' + row.getAttribute('data-open'));
    }
    el.addEventListener('click', openFromRow);
    el.addEventListener('keydown', handleKey);
    App.onCleanup(function () {
      el.removeEventListener('click', openFromRow);
      el.removeEventListener('keydown', handleKey);
    });
  }

  /* ============================== instructor students ============================== */

  async function instructorStudents(params, el) {
    var data = await App.api('/api/instructor-portal/subjects');
    var groups = await Promise.all(data.subjects.map(function (s) {
      return App.api('/api/instructor-portal/subjects/' + s._id + '/students')
        .then(function (roster) { return { schedule: s, roster: roster }; })
        .catch(function () { return { schedule: s, roster: { students: [] } }; });
    }));

    var all = [];
    groups.forEach(function (g) {
      (g.roster.students || []).forEach(function (row) {
        all.push({ student: row.student, status: row.status, schedule: g.schedule });
      });
    });
    var state = { q: '' };

    function table() {
      var list = all.filter(function (r) {
        if (!state.q) return true;
        var s = r.student || {};
        return [s.studentId, s.firstName, s.lastName, s.course && s.course.code].join(' ').toLowerCase().indexOf(state.q.toLowerCase()) !== -1;
      });
      if (!list.length) return App.empty('No students found', 'Adjust the search or wait for enrollment.', 'users');
      return '<div class="table-wrap"><table><thead><tr><th>Student</th><th>Student ID</th><th>Course</th><th>Class</th><th class="right">Status</th></tr></thead><tbody>' +
        list.map(function (r) {
          var s = r.student || {};
          return '<tr><td><div class="cell-main">' + App.esc(App.personName(s)) + '</div><div class="cell-sub">Year ' + App.esc(s.yearLevel || '') + '</div></td>' +
            '<td>' + App.esc(s.studentId || '') + '</td>' +
            '<td>' + App.esc(s.course ? s.course.code : '') + '</td>' +
            '<td><div class="cell-main">' + App.esc(r.schedule.subject ? r.schedule.subject.subjectCode : '') + '</div><div class="cell-sub">' + App.esc(r.schedule.section) + ' · ' + App.esc(r.schedule.daysLabel) + '</div></td>' +
            '<td class="right"><a class="btn ghost sm" href="#/subject/' + r.schedule._id + '">' + App.status(r.status || 'Enrolled') + '</a></td></tr>';
        }).join('') + '</tbody></table></div>';
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'Instructor portal',
      title: 'My students',
      sub: all.length + (all.length === 1 ? ' student' : ' students') + ' across ' + data.subjects.length + ' class section' + (data.subjects.length === 1 ? '' : 's'),
      actions: '<a class="btn ghost" href="#/schedule">' + App.icon('calendar') + 'My schedule</a>'
    }) +
      '<section class="card"><div class="toolbar"><div class="search-box">' + App.icon('search') +
      '<input id="studentRosterSearch" type="search" placeholder="Search student, ID or course" aria-label="Search students"></div>' +
      '<span class="spacer"></span><span class="cell-sub">' + all.length + ' enrollments</span></div>' +
      '<div id="rosterTable">' + table() + '</div></section>';

    document.getElementById('studentRosterSearch').addEventListener('input', function (e) {
      state.q = e.target.value.trim();
      document.getElementById('rosterTable').innerHTML = table();
    });
  }

  /* ============================== routes ============================== */

  P.enrollment = function (params, el) {
    if (role() !== 'Student') return notAllowed(el, 'Enrollment is only available in the Student portal.');
    return enrollmentPage(params, el);
  };

  P.schedule = function (params, el) {
    if (role() === 'Student') return studentSchedule(params, el);
    if (role() === 'Instructor') return instructorSchedule(params, el);
    App.go('schedules');
  };

  P.prospectus = function (params, el) {
    if (role() === 'Admin') return adminProspectusPage(params, el);
    if (role() === 'Student') return studentProspectus(params, el);
    return notAllowed(el, 'Prospectus is available in the Student and Admin portals.');
  };

  P.subject = function (params, el) {
    if (role() === 'Instructor') return instructorClass(params, el);
    App.go('subjects');
  };

  P.students = function (params, el) {
    if (role() === 'Admin') return adminStudentsPage(params, el);
    if (role() === 'Instructor') return instructorStudents(params, el);
    return notAllowed(el, 'The student directory is not available in this portal.');
  };

  P.student = function (params, el) {
    if (role() === 'Admin') return adminStudentPage(params, el);
    App.go(role() === 'Instructor' ? 'students' : 'schedule');
  };

  function notAllowed(el, message) {
    el.innerHTML = App.pageHead({ eyebrow: 'Portal', title: 'Not available', sub: message }) +
      '<div class="card">' + App.empty('This page belongs to another portal', message, 'alert') + '</div>';
  }
})();
