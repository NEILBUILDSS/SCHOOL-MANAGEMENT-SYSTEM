/* ============================================================
   SELL SYSTEM — application bootstrap
   ============================================================ */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    if (window.App && typeof App.boot === 'function') {
      App.boot();
    }
  });
})();
