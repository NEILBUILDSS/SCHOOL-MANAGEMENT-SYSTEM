(function () {
  'use strict';

  var form = document.getElementById('registerForm');
  var errorBox = document.getElementById('formError');
  var okBox = document.getElementById('formOk');
  var submit = document.getElementById('submitBtn');
  var idNote = document.getElementById('idNote');
  var roleInputs = Array.prototype.slice.call(form.querySelectorAll('input[name="role"]'));

  function selectedRole() {
    var checked = roleInputs.filter(function (input) { return input.checked; })[0];
    return checked ? checked.value : 'Student';
  }

  function submitLabel() {
    return selectedRole() === 'Instructor' ? 'Create instructor account' : 'Create student account';
  }

  function syncRole() {
    var role = selectedRole();
    roleInputs.forEach(function (input) {
      input.closest('.role').classList.toggle('active', input.checked);
    });
    idNote.textContent = role === 'Instructor'
      ? 'Your Instructor ID is generated automatically after registration.'
      : 'Your Student ID is generated automatically after registration.';
    submit.textContent = submitLabel();
  }

  roleInputs.forEach(function (input) { input.addEventListener('change', syncRole); });
  syncRole();

  document.getElementById('togglePassword').addEventListener('click', function () {
    var input = form.elements.password;
    var showing = input.type === 'text';
    input.type = showing ? 'password' : 'text';
    input.focus();
  });

  fetch('/api/auth/csrf', { credentials: 'same-origin' })
    .then(function (res) { return res.json(); })
    .then(function (data) { form.dataset.csrf = data.csrfToken; })
    .catch(function () {});

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    errorBox.textContent = '';
    okBox.textContent = '';

    if (!form.reportValidity()) return;

    var data = {
      role: selectedRole(),
      username: form.elements.username.value.trim(),
      password: form.elements.password.value,
      confirmPassword: form.elements.confirmPassword.value
    };

    if (data.password !== data.confirmPassword) {
      errorBox.textContent = 'Password confirmation does not match.';
      return;
    }

    submit.disabled = true;
    submit.textContent = 'Creating account…';

    var csrf = form.dataset.csrf;
    var ready = csrf ? Promise.resolve(csrf) : fetch('/api/auth/csrf', { credentials: 'same-origin' })
      .then(function (res) { return res.json(); })
      .then(function (body) { return body.csrfToken; });

    ready.then(function (token) {
      return fetch('/api/register', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'x-csrf-token': token },
        body: JSON.stringify(data)
      });
    })
      .then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (body) {
          if (!res.ok) throw new Error(body.message || 'Registration failed.');
          okBox.textContent = body.message || 'Account created. Redirecting to sign in…';
          setTimeout(function () { window.location.replace('/'); }, 3500);
        });
      })
      .catch(function (err) {
        errorBox.textContent = err.message;
        submit.disabled = false;
        syncRole();
      });
  });
})();
