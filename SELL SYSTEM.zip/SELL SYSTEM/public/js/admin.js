/* ============================================================
   SELL SYSTEM — Admin portal pages (dashboard, people, activity,
   settings, enrollment register).
   ============================================================ */
(function () {
  'use strict';

  var P = App.pages = App.pages || {};

  function courseLabel(student) {
    return student && student.course ? student.course.code : '—';
  }

  function daysTimes(row) {
    return App.daysInline(row.weekdays) + ' · ' + App.time12(row.startTime) + '–' + App.time12(row.endTime);
  }

  function sectionLabel(schedule) {
    if (!schedule) return '—';
    return schedule.sectionType === 'Block'
      ? 'Block ' + (schedule.blockLabel || '—')
      : 'Open Section';
  }

  function scheduleInstructor(schedule) {
    return schedule && schedule.instructor ? App.personName(schedule.instructor) : 'TBA';
  }

  function uniqueValues(list) {
    return (list || []).filter(function (value, index, all) {
      return value && all.indexOf(value) === index;
    });
  }

  function weeklyHours(list) {
    var total = 0;
    (list || []).forEach(function (s) {
      total += ((App.toMinutes(s.endTime) - App.toMinutes(s.startTime)) / 60) * (s.weekdays || []).length;
    });
    return Math.round(total * 10) / 10;
  }

  function findScheduleConflicts(list) {
    var conflicts = [];
    (list || []).forEach(function (a, index) {
      (list || []).slice(index + 1).forEach(function (b) {
        var days = (a.weekdays || []).filter(function (day) {
          return (b.weekdays || []).indexOf(day) !== -1;
        });
        if (!days.length) return;
        if (App.toMinutes(a.startTime) < App.toMinutes(b.endTime) &&
            App.toMinutes(b.startTime) < App.toMinutes(a.endTime)) {
          conflicts.push({ a: a, b: b, days: days });
        }
      });
    });
    return conflicts;
  }

  function loadCourses() {
    return App.api('/api/courses');
  }

  function courseOptions(courses, selected) {
    return courses.map(function (c) {
      var value = c.code || c.courseCode;
      return '<option value="' + App.esc(value) + '"' + (value === selected ? ' selected' : '') + '>' +
        App.esc(value) + ' — ' + App.esc(c.name || c.courseName) + '</option>';
    }).join('');
  }

  function yearOptions(selected) {
    return [1, 2, 3, 4].map(function (y) {
      return '<option value="' + y + '"' + (Number(selected) === y ? ' selected' : '') + '>' + y + (y === 1 ? 'st' : y === 2 ? 'nd' : y === 3 ? 'rd' : 'th') + ' Year</option>';
    }).join('');
  }

  /* ============================== dashboard ============================== */

  P.dashboard = async function (params, el) {
    var d = await App.api('/api/admin/dashboard');
    var t = d.totals;
    var today = d.today;

    var kpis = [
      { label: 'Total Students', value: t.students, icon: 'users', route: 'students', tone: 'coral' },
      { label: 'Instructors', value: t.instructors, icon: 'teacher', route: 'instructors', tone: '' },
      { label: 'Active Sections', value: t.activeSchedules, icon: 'calendar', route: 'schedules', tone: 'soft' },
      { label: 'Rooms', value: t.rooms, icon: 'door', route: 'rooms', tone: '' }
    ];

    var kpiHtml = '<div class="kpi-grid">' + kpis.map(function (k) {
      return '<a class="kpi" href="#/' + k.route + '" style="color:inherit;text-decoration:none">' +
        '<div class="kpi-icon ' + k.tone + '">' + App.icon(k.icon) + '</div>' +
        '<div><div class="kpi-value">' + k.value + '</div><div class="kpi-label">' + k.label + '</div>' +
        '<div class="kpi-trend">Open directory</div></div></a>';
    }).join('') + '</div>';

    var performers = d.topInstructors.length
      ? d.topInstructors.map(function (i, index) {
        var tones = ['red', 'blue', 'pink'];
        return '<div class="performer ' + tones[index % 3] + '">' +
          '<div class="performer-avatar">' + App.esc(i.initials) + '</div>' +
          '<div class="performer-name">' + App.esc(i.name) + '</div>' +
          '<div class="performer-sub">' + i.classes + ' class' + (i.classes === 1 ? '' : 'es') + '</div>' +
          '<div class="performer-pct">' + i.percent + '%</div>' +
          '<div class="performer-badge">' + i.hours + ' hrs / week</div>' +
          '</div>';
      }).join('')
      : '<div class="empty" style="grid-column:1/-1">' + App.icon('teacher') +
      '<strong>No teaching load yet</strong><span>Plot a schedule and the busiest instructors appear here.</span></div>';

    var scheduleRows = d.scheduleUpdates.length
      ? d.scheduleUpdates.map(function (s) {
        return '<tr><td><div class="cell-main">' + App.esc(s.subjectCode || s.subject) + '</div><div class="cell-sub">' + App.esc(s.course) + ' · Year ' + App.esc(s.yearLevel) + '</div></td>' +
          '<td><div class="cell-main">' + App.esc(s.instructor) + '</div><div class="cell-sub">' + App.esc(s.room) + '</div></td>' +
          '<td class="nowrap"><div class="cell-main">' + App.esc(s.days || '—') + '</div><div class="cell-sub">' + App.esc(s.time) + '</div></td>' +
          '<td class="right">' + App.status(s.status) + '</td></tr>';
      }).join('')
      : '<tr><td colspan="4">' + App.empty('No schedules plotted', 'Open Schedules & Rooms to assign the first class.', 'calendar') + '</td></tr>';

    var activityRows = d.recentActivity.length
      ? d.recentActivity.map(function (a) {
        return '<div class="activity-row"><span class="activity-dot"></span><div>' +
          '<div class="cell-main">' + App.esc(a.action) + '</div>' +
          '<div class="cell-sub">' + App.esc(a.description || '') + '</div>' +
          '<div class="cell-sub" style="margin-top:2px">' + App.esc(a.performedByLabel || 'System') + ' · ' + App.fmtDateTime(a.createdAt) + '</div>' +
          '</div></div>';
      }).join('')
      : App.empty('No activity yet', 'Administrator changes will appear here.', 'activity');

    var registrations = d.recentRegistrations.length
      ? d.recentRegistrations.map(function (r) {
        return '<div class="list-row"><div class="avatar" style="width:32px;height:32px;font-size:10px">' + App.esc(App.initial({ firstName: r.name.split(' ')[0], lastName: r.name.split(' ').slice(-1)[0] })) + '</div>' +
          '<div style="min-width:0"><div class="cell-main">' + App.esc(r.name) + '</div><div class="cell-sub">' + App.esc(r.kind) + (r.detail ? ' · ' + App.esc(r.detail) : '') + '</div></div>' +
          '<span class="cell-sub" style="margin-left:auto;white-space:nowrap">' + App.fmtDate(r.createdAt, { utc: false }) + '</span></div>';
      }).join('')
      : App.empty('No new accounts', 'Student and instructor sign-ups appear here.', 'users');

    el.innerHTML =
      App.pageHead({
        eyebrow: 'Academic operations',
        title: 'Dashboard',
        sub: d.currentSemester
          ? 'A live view of ' + d.currentSemester.label + ' — classes, rooms and people.'
          : 'Set up a school year to start plotting classes.',
        actions: '<a class="btn ghost" href="#/schedules">' + App.icon('calendar') + 'Open timetable</a>' +
          '<a class="btn coral" href="#/enrollments">' + App.icon('clipboard') + 'Enrollments</a>'
      }) +
      kpiHtml +
      '<div class="grid-2">' +
      '<section class="card">' +
      '<div class="card-head"><div><h2>Today\'s status</h2><div class="card-sub">' + App.esc(today.day) + ' · live from the plotted timetable</div></div>' +
      '<span class="badge-soft">' + App.esc(d.currentSemester ? d.currentSemester.label : 'No term') + '</span></div>' +
      '<div class="mini-grid">' +
      '<div class="mini-stat"><strong>' + today.classes + '</strong><span>Classes today</span></div>' +
      '<div class="mini-stat"><strong>' + today.roomsInUse + '</strong><span>Rooms in use</span></div>' +
      '<div class="mini-stat"><strong>' + today.usedHours + 'h</strong><span>Room hours booked</span></div>' +
      '</div>' +
      (today.nextClass
        ? '<div class="next-class"><div class="bar-accent"></div><div class="nc-text"><strong>' + App.esc(today.nextClass.subject) + '</strong>' +
        '<span>' + App.esc(today.nextClass.room) + ' · ' + App.esc(today.nextClass.instructor) + ' · ' + App.esc(today.nextClass.course) + '</span></div>' +
        '<div class="nc-time">' + App.esc(today.nextClass.time) + '</div></div>'
        : '<div class="next-class"><div class="bar-accent"></div><div class="nc-text"><strong>No more classes today</strong><span>Check the weekly timetable for the next session.</span></div></div>') +
      '</section>' +
      '<section class="card">' +
      '<div class="card-head"><div><h2>Weekly class load</h2><div class="card-sub">Active sections per class day</div></div></div>' +
      App.barChart(d.weekLoad.map(function (w) { return { label: w.day, value: w.count }; }), { label: 'Classes per day' }) +
      '<div class="legend"><span><i style="background:#1c2a6b"></i>Mon / Thu</span><span><i style="background:#f26a5a"></i>Tue / Fri</span><span><i style="background:#f7a9a2"></i>Wed / Sat</span></div>' +
      '</section>' +
      '</div>' +
      '<div class="grid-2">' +
      '<section class="card">' +
      '<div class="card-head"><div><h2>Room usage</h2><div class="card-sub">' + t.rooms + ' rooms in the directory</div></div>' +
      '<a class="card-link" href="#/rooms">Directory ' + App.icon('arrow') + '</a></div>' +
      '<div class="donut-flex">' +
      App.donut([
        { label: 'In use today', value: d.roomMix.inUse, color: '#f26a5a' },
        { label: 'Available', value: Math.max(0, d.roomMix.total - d.roomMix.inUse - d.roomMix.inactive), color: '#1c2a6b' },
        { label: 'Inactive', value: d.roomMix.inactive, color: '#e6e9f2' }
      ], d.roomMix.total, 'Rooms') +
      '<div class="donut-legend">' +
      '<div><i style="background:#f26a5a"></i>In use today<b>' + d.roomMix.inUse + '</b></div>' +
      '<div><i style="background:#1c2a6b"></i>Available<b>' + Math.max(0, d.roomMix.total - d.roomMix.inUse - d.roomMix.inactive) + '</b></div>' +
      '<div><i style="background:#e6e9f2"></i>Inactive<b>' + d.roomMix.inactive + '</b></div>' +
      '<div><i style="background:#f7a9a2"></i>Laboratories<b>' + d.roomMix.laboratory + '</b></div>' +
      '</div></div></section>' +
      '<section class="card">' +
      '<div class="card-head"><div><h2>Top teaching load</h2><div class="card-sub">Weekly hours from active schedules</div></div>' +
      '<a class="card-link" href="#/instructors">All instructors ' + App.icon('arrow') + '</a></div>' +
      '<div class="performers">' + performers + '</div>' +
      '</section>' +
      '</div>' +
      '<div class="grid-2">' +
      '<section class="card">' +
      '<div class="card-head"><div><h2>Latest schedule updates</h2><div class="card-sub">Most recently plotted sections</div></div>' +
      '<a class="card-link" href="#/schedules">Timetable ' + App.icon('arrow') + '</a></div>' +
      '<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Class</th><th>Schedule</th><th class="right">Status</th></tr></thead><tbody>' +
      scheduleRows + '</tbody></table></div></section>' +
      '<div class="stack">' +
      '<section class="card"><div class="card-head"><div><h2>Recent activity</h2><div class="card-sub">Audit trail</div></div>' +
      '<a class="card-link" href="#/activity">View all ' + App.icon('arrow') + '</a></div>' + activityRows + '</section>' +
      '<section class="card"><div class="card-head"><div><h2>New accounts</h2><div class="card-sub">Latest registrations</div></div></div>' + registrations + '</section>' +
      '</div></div>';
  };

  /* ============================== students ============================== */

  P.students = async function (params, el) {
    var courses = await loadCourses();
    var rows = await App.api('/api/students');
    var state = { q: '', status: '', year: '', course: '' };

    function filtered() {
      return rows.filter(function (s) {
        if (state.status && s.status !== state.status) return false;
        if (state.year && Number(s.yearLevel) !== Number(state.year)) return false;
        if (state.course && courseLabel(s) !== state.course) return false;
        if (state.q) {
          var q = state.q.toLowerCase();
          var hay = [s.studentId, s.firstName, s.middleName, s.lastName, courseLabel(s)].join(' ').toLowerCase();
          if (hay.indexOf(q) === -1) return false;
        }
        return true;
      });
    }

    function table() {
      var list = filtered();
      if (!list.length) {
        return '<tr><td colspan="6">' + App.empty('No students found', 'Adjust the filters to see student records.', 'users') + '</td></tr>';
      }
      return list.map(function (s) {
        return '<tr class="row-link" data-open="' + s._id + '" tabindex="0" role="link" aria-label="Open student profile for ' + App.esc(App.personName(s)) + '">' +
          '<td><div class="cell-main">' + App.esc(s.studentId) + '</div><div class="cell-sub">' + App.esc(s.user && s.user.email || '') + '</div></td>' +
          '<td><div class="cell-main">' + App.esc(App.personName(s)) + '</div><div class="cell-sub">' + App.esc(s.contactNumber || '') + '</div></td>' +
          '<td><div class="cell-main">' + App.esc(courseLabel(s)) + '</div><div class="cell-sub">' + App.esc(s.course ? s.course.name : '') + '</div></td>' +
          '<td class="nowrap">Year ' + s.yearLevel + '</td>' +
          '<td>' + App.status(s.status) + '</td>' +
          '<td class="right nowrap"><a class="btn-icon" title="Open student" href="#/student/' + s._id + '">' + App.icon('eye') + '</a></td></tr>';
      }).join('');
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'People',
      title: 'Students',
      sub: rows.length + ' student record' + (rows.length === 1 ? '' : 's') + ' in the school directory.'
    }) +
      '<section class="card">' +
      '<div class="toolbar">' +
      '<div class="search-box">' + App.icon('search') + '<input id="studentSearch" type="search" placeholder="Search ID, name or course" aria-label="Search students"></div>' +
      '<select class="input" id="filterStatus" style="width:auto"><option value="">All status</option><option>Active</option><option>Inactive</option></select>' +
      '<select class="input" id="filterYear" style="width:auto"><option value="">All year levels</option>' + yearOptions('') + '</select>' +
      '<select class="input" id="filterCourse" style="width:auto"><option value="">All courses</option>' + courses.map(function (c) {
        return '<option value="' + App.esc(c.code || c.courseCode) + '">' + App.esc(c.code || c.courseCode) + '</option>';
      }).join('') + '</select>' +
      '<span class="spacer"></span><span class="cell-sub" id="studentCount"></span>' +
      '</div>' +
      '<div class="table-wrap"><table><thead><tr><th>Student</th><th>Contact</th><th>Course</th><th>Year</th><th>Status</th><th class="right">Actions</th></tr></thead>' +
      '<tbody id="studentBody">' + table() + '</tbody></table></div></section>';

    function refresh() {
      document.getElementById('studentBody').innerHTML = table();
      document.getElementById('studentCount').textContent = filtered().length + ' shown';
    }
    refresh();

    document.getElementById('studentSearch').addEventListener('input', function (e) { state.q = e.target.value.trim(); refresh(); });
    document.getElementById('filterStatus').addEventListener('change', function (e) { state.status = e.target.value; refresh(); });
    document.getElementById('filterYear').addEventListener('change', function (e) { state.year = e.target.value; refresh(); });
    document.getElementById('filterCourse').addEventListener('change', function (e) { state.course = e.target.value; refresh(); });

    document.getElementById('studentBody').addEventListener('click', function (event) {
      if (event.target.closest('a, button')) return;
      var row = event.target.closest('[data-open]');
      if (row) App.go('student/' + row.getAttribute('data-open'));
    });

    document.getElementById('studentBody').addEventListener('keydown', function (event) {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      if (event.target.closest('a, button')) return;
      var row = event.target.closest('[data-open]');
      if (!row) return;
      event.preventDefault();
      App.go('student/' + row.getAttribute('data-open'));
    });
  };

  function openStudentForm(student, courses) {
    var isEdit = Boolean(student);
    App.modal({
      title: isEdit ? 'Edit student' : 'Add student',
      sub: isEdit ? 'Update the school record. The student ID stays unique.' : 'Creates the login account and student record. The Student ID is generated automatically.',
      wide: true,
      body: '<form id="studentForm"><div class="form-grid">' +
        (isEdit
          ? '<label class="field"><span>Student ID</span><input name="studentId" maxlength="50" required value="' + App.esc(student.studentId) + '"></label>'
          : '<label class="field"><span>Student ID</span><input value="Generated automatically" disabled></label>') +
        '<label class="field"><span>Year level</span><select name="yearLevel">' + yearOptions(isEdit ? student.yearLevel : 1) + '</select></label>' +
        '<label class="field"><span>First name</span><input name="firstName" maxlength="80" required value="' + App.esc(isEdit ? student.firstName : '') + '"></label>' +
        '<label class="field"><span>Middle name</span><input name="middleName" maxlength="80" value="' + App.esc(isEdit ? student.middleName : '') + '"></label>' +
        '<label class="field"><span>Last name</span><input name="lastName" maxlength="80" required value="' + App.esc(isEdit ? student.lastName : '') + '"></label>' +
        '<label class="field"><span>Contact number</span><input name="contactNumber" maxlength="40" required value="' + App.esc(isEdit ? student.contactNumber : '') + '"></label>' +
        '<label class="field span-2"><span>Course</span><select name="course" required>' + courseOptions(courses, isEdit ? courseLabel(student) : '') + '</select></label>' +
        '<label class="field"><span>Email</span><input name="email" type="email" maxlength="254" required value="' + App.esc(isEdit && student.user ? student.user.email : '') + '"></label>' +
        (isEdit
          ? '<label class="field"><span>Status</span><select name="status"><option' + (student.status === 'Active' ? ' selected' : '') + '>Active</option><option' + (student.status === 'Inactive' ? ' selected' : '') + '>Inactive</option></select></label>'
          : '<label class="field"><span>Username</span><input name="username" maxlength="50" required></label>') +
        '<label class="field"><span>' + (isEdit ? 'New password (optional)' : 'Password') + '</span><input name="password" type="password" minlength="8" maxlength="128"' + (isEdit ? '' : ' required') + '></label>' +
        (isEdit ? '' : '<label class="field"><span>Confirm password</span><input name="confirmPassword" type="password" minlength="8" maxlength="128" required></label>') +
        '<div class="form-error span-2" role="alert"></div>' +
        '</div></form>',
      footer: '<button class="btn ghost" type="button" data-close>Cancel</button><button class="btn coral" type="submit" form="studentForm">' + (isEdit ? 'Save changes' : 'Create student') + '</button>',
      onMount: function (wrap) {
        wrap.querySelector('#studentForm').addEventListener('submit', async function (event) {
          event.preventDefault();
          var form = event.currentTarget;
          var data = App.formData(form);
          var err = form.querySelector('.form-error');
          err.textContent = '';
          if (data.password && data.confirmPassword !== undefined && data.password !== data.confirmPassword) {
            err.textContent = 'Password confirmation does not match.';
            return;
          }
          try {
            if (isEdit) {
              if (!data.password) delete data.password;
              delete data.confirmPassword;
              await App.api('/api/students/' + student._id, { method: 'PATCH', body: data });
              App.toast('Student updated.');
            } else {
              await App.api('/api/students', { method: 'POST', body: data });
              App.toast('Student created.');
            }
            App.closeModal();
            App.render();
          } catch (e) { err.textContent = e.message; }
        });
      }
    });
  }

  P.student = async function (params, el) {
    var data = await App.api('/api/students/' + params[0]);
    var s = data.student;
    var enrollments = data.enrollments || [];
    var active = enrollments.filter(function (e) { return e.status === 'Active'; });
    var activeSchedules = active.map(function (e) { return e.schedule; }).filter(function (schedule) {
      return schedule && schedule.status === 'Active';
    });
    var sections = uniqueValues(activeSchedules.map(sectionLabel));
    var accountStatus = s.user ? s.user.status : '—';
    var enrollmentStatus = active.length
      ? 'Enrolled · ' + active.length + ' subject' + (active.length === 1 ? '' : 's')
      : 'Not enrolled';

    function scheduleRows() {
      if (!activeSchedules.length) {
        return '<tr><td colspan="5">' + App.empty('No class schedule', 'This student has no active class for the term.', 'calendar') + '</td></tr>';
      }
      return activeSchedules.map(function (schedule) {
        return '<tr><td><div class="cell-main">' + App.esc(schedule.subject ? schedule.subject.subjectCode : '—') + '</div><div class="cell-sub">' + App.esc(schedule.subject ? schedule.subject.subjectName : '') + '</div></td>' +
          '<td><div class="cell-main">' + App.esc(sectionLabel(schedule)) + '</div><div class="cell-sub">Year ' + App.esc(schedule.yearLevel || s.yearLevel) + '</div></td>' +
          '<td class="nowrap">' + App.esc(daysTimes(schedule)) + '</td>' +
          '<td><div class="cell-main">' + App.esc(schedule.room ? schedule.room.roomCode : '—') + '</div><div class="cell-sub">' + App.esc(schedule.room ? schedule.room.roomName : '') + '</div></td>' +
          '<td>' + App.esc(scheduleInstructor(schedule)) + '</td></tr>';
      }).join('');
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'Student record',
      title: App.personName(s),
      sub: s.studentId + ' · ' + courseLabel(s) + ' · Year ' + s.yearLevel,
      actions: '<a class="btn ghost" href="#/students">Back</a>'
    }) +
      '<section class="card"><div class="card-head"><div><h2>Student information</h2><div class="card-sub">School identity, contact and status</div></div>' + App.status(s.status) + '</div>' +
      '<div class="profile-identity">' + App.avatar(s, 'profile') +
      '<div><strong>' + App.esc(App.personName(s)) + '</strong><span>' + App.esc(s.studentId) +
      (s.course ? ' · ' + App.esc(s.course.code) : '') + '</span></div></div>' +
      '<div class="info-grid">' +
      '<div class="info-item"><span>Student ID</span><strong>' + App.esc(s.studentId) + '</strong></div>' +
      '<div class="info-item"><span>Course</span><strong>' + App.esc(s.course ? s.course.code + ' — ' + s.course.name : '—') + '</strong></div>' +
      '<div class="info-item"><span>Year level</span><strong>Year ' + s.yearLevel + '</strong></div>' +
      '<div class="info-item"><span>Section</span><strong>' + App.esc(sections.length ? sections.join(', ') : '—') + '</strong></div>' +
      '<div class="info-item"><span>Contact</span><strong>' + App.esc([s.contactNumber, s.telephoneNumber].filter(Boolean).join(' · ') || '—') + '</strong></div>' +
      '<div class="info-item"><span>Email</span><strong>' + App.esc(s.user ? s.user.email : '—') + '</strong></div>' +
      '<div class="info-item"><span>Username</span><strong>' + App.esc(s.user ? s.user.username : '—') + '</strong></div>' +
      '<div class="info-item"><span>Account status</span><strong>' + App.esc(accountStatus) + '</strong></div>' +
      '<div class="info-item"><span>Enrollment status</span><strong>' + App.esc(enrollmentStatus) + '</strong></div>' +
      '</div></section>' +
      '<section class="card" style="margin-top:16px"><div class="card-head"><div><h2>Class schedule</h2><div class="card-sub">' +
      activeSchedules.length + ' active class' + (activeSchedules.length === 1 ? '' : 'es') + ' · meeting days, rooms and instructors</div></div></div>' +
      '<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Section</th><th>Schedule</th><th>Room</th><th>Instructor</th></tr></thead><tbody>' +
      scheduleRows() + '</tbody></table></div></section>';
  };

  /* ============================== instructors ============================== */

  P.instructors = async function (params, el) {
    var rows = await App.api('/api/instructors');
    var state = { q: '', status: '' };

    function table() {
      var list = rows.filter(function (i) {
        if (state.status && i.status !== state.status) return false;
        if (state.q) {
          var q = state.q.toLowerCase();
          var hay = [i.instructorId, i.firstName, i.middleName, i.lastName, i.department].join(' ').toLowerCase();
          if (hay.indexOf(q) === -1) return false;
        }
        return true;
      });
      if (!list.length) return '<tr><td colspan="5">' + App.empty('No instructors found', 'Adjust the filters to see instructor records.', 'teacher') + '</td></tr>';
      return list.map(function (i) {
        return '<tr class="row-link" data-open="' + i._id + '" tabindex="0" role="link" aria-label="Open instructor profile for ' + App.esc(App.personName(i)) + '">' +
          '<td><div class="cell-main">' + App.esc(i.instructorId) + '</div><div class="cell-sub">' + App.esc(i.user && i.user.email || '') + '</div></td>' +
          '<td><div class="cell-main">' + App.esc(App.personName(i)) + '</div><div class="cell-sub">' + App.esc(i.contactNumber || '') + '</div></td>' +
          '<td>' + App.esc(i.department || '—') + '</td>' +
          '<td>' + App.status(i.status) + '</td>' +
          '<td class="right nowrap"><a class="btn-icon" href="#/instructor/' + i._id + '" title="Open instructor">' + App.icon('eye') + '</a></td></tr>';
      }).join('');
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'People',
      title: 'Instructors',
      sub: rows.length + ' instructor record' + (rows.length === 1 ? '' : 's') + ' across the college.'
    }) +
      '<section class="card"><div class="toolbar">' +
      '<div class="search-box">' + App.icon('search') + '<input id="instructorSearch" type="search" placeholder="Search ID, name or department" aria-label="Search instructors"></div>' +
      '<select class="input" id="filterInstructorStatus" style="width:auto"><option value="">All status</option><option>Active</option><option>Inactive</option></select>' +
      '<span class="spacer"></span><span class="cell-sub" id="instructorCount"></span></div>' +
      '<div class="table-wrap"><table><thead><tr><th>Instructor</th><th>Contact</th><th>Department</th><th>Status</th><th class="right">Actions</th></tr></thead><tbody id="instructorBody">' +
      table() + '</tbody></table></div></section>';

    function refresh() {
      document.getElementById('instructorBody').innerHTML = table();
      document.getElementById('instructorCount').textContent = 'Live directory';
    }
    document.getElementById('instructorSearch').addEventListener('input', function (e) { state.q = e.target.value.trim(); refresh(); });
    document.getElementById('filterInstructorStatus').addEventListener('change', function (e) { state.status = e.target.value; refresh(); });
    document.getElementById('instructorBody').addEventListener('click', function (event) {
      if (event.target.closest('a, button')) return;
      var row = event.target.closest('[data-open]');
      if (row) App.go('instructor/' + row.getAttribute('data-open'));
    });

    document.getElementById('instructorBody').addEventListener('keydown', function (event) {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      if (event.target.closest('a, button')) return;
      var row = event.target.closest('[data-open]');
      if (!row) return;
      event.preventDefault();
      App.go('instructor/' + row.getAttribute('data-open'));
    });
  };

  function openInstructorForm(instructor) {
    var isEdit = Boolean(instructor);
    App.modal({
      title: isEdit ? 'Edit instructor' : 'Add instructor',
      sub: isEdit ? 'Update the teaching record. Active schedules must be moved before deactivation.' : 'Creates the login account and instructor record together.',
      wide: true,
      body: '<form id="instructorForm"><div class="form-grid">' +
        '<label class="field"><span>Instructor ID</span><input name="instructorId" maxlength="50" required value="' + App.esc(isEdit ? instructor.instructorId : '') + '"></label>' +
        '<label class="field"><span>Department</span><input name="department" maxlength="120" required value="' + App.esc(isEdit ? instructor.department : '') + '"></label>' +
        '<label class="field"><span>First name</span><input name="firstName" maxlength="80" required value="' + App.esc(isEdit ? instructor.firstName : '') + '"></label>' +
        '<label class="field"><span>Middle name</span><input name="middleName" maxlength="80" value="' + App.esc(isEdit ? instructor.middleName : '') + '"></label>' +
        '<label class="field"><span>Last name</span><input name="lastName" maxlength="80" required value="' + App.esc(isEdit ? instructor.lastName : '') + '"></label>' +
        '<label class="field"><span>Contact number</span><input name="contactNumber" maxlength="40" required value="' + App.esc(isEdit ? instructor.contactNumber : '') + '"></label>' +
        '<label class="field"><span>Email</span><input name="email" type="email" maxlength="254" required value="' + App.esc(isEdit && instructor.user ? instructor.user.email : '') + '"></label>' +
        (isEdit
          ? '<label class="field"><span>Status</span><select name="status"><option' + (instructor.status === 'Active' ? ' selected' : '') + '>Active</option><option' + (instructor.status === 'Inactive' ? ' selected' : '') + '>Inactive</option></select></label>'
          : '<label class="field"><span>Username</span><input name="username" maxlength="50" required></label>') +
        '<label class="field"><span>' + (isEdit ? 'New password (optional)' : 'Password') + '</span><input name="password" type="password" minlength="8" maxlength="128"' + (isEdit ? '' : ' required') + '></label>' +
        (isEdit ? '' : '<label class="field"><span>Confirm password</span><input name="confirmPassword" type="password" minlength="8" maxlength="128" required></label>') +
        '<div class="form-error span-2" role="alert"></div></div></form>',
      footer: '<button class="btn ghost" type="button" data-close>Cancel</button><button class="btn coral" type="submit" form="instructorForm">' + (isEdit ? 'Save changes' : 'Create instructor') + '</button>',
      onMount: function (wrap) {
        wrap.querySelector('#instructorForm').addEventListener('submit', async function (event) {
          event.preventDefault();
          var form = event.currentTarget;
          var data = App.formData(form);
          var err = form.querySelector('.form-error');
          err.textContent = '';
          if (data.password && data.confirmPassword !== undefined && data.password !== data.confirmPassword) {
            err.textContent = 'Password confirmation does not match.';
            return;
          }
          try {
            if (isEdit) {
              if (!data.password) delete data.password;
              delete data.confirmPassword;
              await App.api('/api/instructors/' + instructor._id, { method: 'PATCH', body: data });
              App.toast('Instructor updated.');
            } else {
              await App.api('/api/instructors', { method: 'POST', body: data });
              App.toast('Instructor created.');
            }
            App.closeModal();
            App.render();
          } catch (e) { err.textContent = e.message; }
        });
      }
    });
  }

  P.instructor = async function (params, el) {
    var data = await App.api('/api/instructors/' + params[0]);
    var i = data.instructor;
    var schedules = data.schedules || [];
    var active = schedules.filter(function (s) { return s.status === 'Active'; });
    var instructorName = App.personName(i);
    var hours = weeklyHours(active);
    var rooms = uniqueValues(active.map(function (s) { return s.room ? s.room.roomCode : ''; }));
    var subjects = uniqueValues(active.map(function (s) { return s.subject ? s.subject.subjectCode : ''; }));
    var sectionKeys = uniqueValues(active.map(function (s) {
      return [s.course ? s.course.code : '', s.yearLevel, s.sectionType, s.blockLabel].join('|');
    }));
    var conflicts = findScheduleConflicts(active);
    var accountStatus = i.user ? i.user.status : '—';

    var rows = schedules.length ? schedules.map(function (s) {
      return '<tr><td><div class="cell-main">' + App.esc(s.subject ? s.subject.subjectCode : '—') + '</div><div class="cell-sub">' + App.esc(s.subject ? s.subject.subjectName : '') + '</div></td>' +
        '<td><div class="cell-main">' + App.esc(s.course ? s.course.code : '—') + ' · ' + App.esc(sectionLabel(s)) + '</div><div class="cell-sub">Year ' + App.esc(s.yearLevel) + '</div></td>' +
        '<td><div class="cell-main">' + App.esc(s.room ? s.room.roomCode : '—') + '</div><div class="cell-sub">' + App.esc(s.room ? s.room.roomName : '') + '</div></td>' +
        '<td class="nowrap"><div class="cell-main">' + App.esc(App.daysInline(s.weekdays)) + '</div><div class="cell-sub">' + App.time12(s.startTime) + '–' + App.time12(s.endTime) + '</div></td>' +
        '<td class="right">' + App.status(s.status) + '</td></tr>';
    }).join('') : '<tr><td colspan="5">' + App.empty('No schedules yet', 'Assign this instructor while plotting a class.', 'calendar') + '</td></tr>';

    var conflictRows = conflicts.map(function (conflict) {
      var a = conflict.a;
      var b = conflict.b;
      return '<div class="list-row"><span class="badge-soft coral">Conflict</span><div><div class="cell-main">' +
        App.esc(a.subject ? a.subject.subjectCode : '—') + ' / ' + App.esc(b.subject ? b.subject.subjectCode : '—') + '</div><div class="cell-sub">' +
        App.esc(App.daysInline(conflict.days)) + ' · ' + App.time12(a.startTime) + '–' + App.time12(a.endTime) +
        ' vs ' + App.time12(b.startTime) + '–' + App.time12(b.endTime) +
        ' · ' + App.esc(a.room ? a.room.roomCode : '—') + ' / ' + App.esc(b.room ? b.room.roomCode : '—') +
        '</div></div></div>';
    }).join('');

    el.innerHTML = App.pageHead({
      eyebrow: 'Instructor record',
      title: instructorName,
      sub: i.instructorId + ' · ' + (i.department || 'No department'),
      actions: '<a class="btn ghost" href="#/instructors">Back</a>'
    }) +
      '<div class="grid-2">' +
      '<section class="card"><div class="card-head"><div><h2>Profile</h2><div class="card-sub">Teaching identity and account</div></div>' + App.status(i.status) + '</div>' +
      '<div class="profile-identity">' + App.avatar(i, 'profile') +
      '<div><strong>' + App.esc(instructorName) + '</strong><span>' + App.esc(i.instructorId) +
      (i.department ? ' · ' + App.esc(i.department) : '') + '</span></div></div>' +
      '<div class="info-grid">' +
      '<div class="info-item"><span>Instructor ID</span><strong>' + App.esc(i.instructorId) + '</strong></div>' +
      '<div class="info-item"><span>Department</span><strong>' + App.esc(i.department || '—') + '</strong></div>' +
      '<div class="info-item"><span>Email</span><strong>' + App.esc(i.user ? i.user.email : '—') + '</strong></div>' +
      '<div class="info-item"><span>Contact</span><strong>' + App.esc(i.contactNumber || '—') + '</strong></div>' +
      '<div class="info-item"><span>Username</span><strong>' + App.esc(i.user ? i.user.username : '—') + '</strong></div>' +
      '<div class="info-item"><span>Account status</span><strong>' + App.esc(accountStatus) + '</strong></div>' +
      '</div></section>' +
      '<section class="card"><div class="card-head"><div><h2>Teaching load</h2><div class="card-sub">Active schedule summary</div></div></div>' +
      '<div class="mini-grid">' +
      '<div class="mini-stat"><strong>' + hours + '</strong><span>Weekly hours</span></div>' +
      '<div class="mini-stat"><strong>' + active.length + '</strong><span>Active classes</span></div>' +
      '<div class="mini-stat"><strong>' + subjects.length + '</strong><span>Subjects</span></div>' +
      '<div class="mini-stat"><strong>' + sectionKeys.length + '</strong><span>Sections</span></div>' +
      '<div class="mini-stat"><strong>' + rooms.length + '</strong><span>Rooms</span></div>' +
      '<div class="mini-stat"><strong style="' + (conflicts.length ? 'color:var(--danger)' : '') + '">' + conflicts.length + '</strong><span>Conflicts</span></div>' +
      '</div>' +
      '<p class="small muted" style="margin:14px 0 0"><strong style="color:var(--ink)">Assigned rooms:</strong> ' +
      App.esc(rooms.length ? rooms.join(', ') : 'No rooms assigned') + '</p>' +
      (conflicts.length ? '' : '<p class="small muted" style="margin:6px 0 0">No schedule conflicts detected.</p>') +
      '</section></div>' +
      (conflicts.length
        ? '<section class="card" style="margin-top:16px"><div class="card-head"><div><h2>Schedule conflicts</h2><div class="card-sub">Overlapping active classes for this instructor</div></div>' +
          App.status('Conflict') + '</div>' + conflictRows + '</section>'
        : '') +
      '<section class="card" style="margin-top:16px"><div class="card-head"><div><h2>Assigned subjects &amp; sections</h2><div class="card-sub">Every class section assigned to this instructor</div></div>' +
      '<a class="card-link" href="#/schedules">Open timetable ' + App.icon('arrow') + '</a></div>' +
      '<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Section</th><th>Room</th><th>Schedule</th><th class="right">Status</th></tr></thead><tbody>' +
      rows + '</tbody></table></div></section>';
  };

  /* ============================== enrollments ============================== */

  P.enrollments = async function (params, el) {
    var rows = await App.api('/api/enrollments');
    var state = { q: '', status: '', year: '' };

    function table() {
      var list = rows.filter(function (r) {
        if (state.status && r.status !== state.status) return false;
        if (state.year && Number(r.student.yearLevel) !== Number(state.year)) return false;
        if (state.q) {
          var q = state.q.toLowerCase();
          var hay = [r.student.studentId, r.student.name, r.student.course, r.subject && r.subject.subjectCode].join(' ').toLowerCase();
          if (hay.indexOf(q) === -1) return false;
        }
        return true;
      });
      if (!list.length) return '<tr><td colspan="6">' + App.empty('No enrollments found', 'Enroll a student to get started.', 'clipboard') + '</td></tr>';
      return list.map(function (r) {
        return '<tr><td><div class="cell-main">' + App.esc(r.student.studentId) + '</div><div class="cell-sub">' + App.esc(r.student.name) + '</div></td>' +
          '<td><div class="cell-main">' + App.esc(r.subject ? r.subject.subjectCode : '—') + '</div><div class="cell-sub">' + App.esc(r.subject ? r.subject.subjectName : '') + '</div></td>' +
          '<td><div class="cell-main">' + App.esc(r.schedule ? r.schedule.room : '—') + '</div><div class="cell-sub">' + (r.schedule ? App.daysInline(r.schedule.weekdays) + ' · ' + App.time12(r.schedule.startTime) + '–' + App.time12(r.schedule.endTime) : '') + '</div></td>' +
          '<td class="nowrap">' + App.esc(r.semester) + '</td>' +
          '<td>' + App.status(r.status) + '<div class="cell-sub">' + App.esc(r.result || '') + '</div></td>' +
          '<td class="right nowrap">' +
          (r.status === 'Active'
            ? '<button class="btn sm danger" type="button" data-toggle="' + r._id + '" data-next="Inactive">Drop</button>'
            : '<button class="btn sm ghost" type="button" data-toggle="' + r._id + '" data-next="Active">Re-enroll</button>') +
          '</td></tr>';
      }).join('');
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'Scheduling',
      title: 'Enrollments',
      sub: 'Direct, server-validated enrollment. There is no approval queue — every save checks capacity, prerequisites and conflicts.',
      actions: '<button class="btn coral" type="button" id="newEnrollment">' + App.icon('plus') + 'Enroll Student</button>'
    }) +
      '<section class="card"><div class="toolbar">' +
      '<div class="search-box">' + App.icon('search') + '<input id="enrollSearch" type="search" placeholder="Search student, ID or subject" aria-label="Search enrollments"></div>' +
      '<select class="input" id="enrollStatus" style="width:auto"><option value="">All status</option><option>Active</option><option>Inactive</option></select>' +
      '<select class="input" id="enrollYear" style="width:auto"><option value="">All year levels</option>' + yearOptions('') + '</select>' +
      '<span class="spacer"></span><span class="cell-sub" id="enrollCount"></span></div>' +
      '<div class="table-wrap"><table><thead><tr><th>Student</th><th>Subject</th><th>Section</th><th>Term</th><th>Status</th><th class="right">Action</th></tr></thead><tbody id="enrollBody">' +
      table() + '</tbody></table></div></section>';

    function refresh() {
      document.getElementById('enrollBody').innerHTML = table();
      document.getElementById('enrollCount').textContent = rows.filter(function (r) { return r.status === 'Active'; }).length + ' active';
    }
    refresh();
    document.getElementById('enrollSearch').addEventListener('input', function (e) { state.q = e.target.value.trim(); refresh(); });
    document.getElementById('enrollStatus').addEventListener('change', function (e) { state.status = e.target.value; refresh(); });
    document.getElementById('enrollYear').addEventListener('change', function (e) { state.year = e.target.value; refresh(); });

    document.getElementById('enrollBody').addEventListener('click', async function (event) {
      var btn = event.target.closest('[data-toggle]');
      if (!btn) return;
      var next = btn.getAttribute('data-next');
      var ok = await App.confirm({
        title: next === 'Inactive' ? 'Drop this enrollment?' : 'Re-enroll this student?',
        message: next === 'Inactive'
          ? 'The record stays in history as Dropped. The student loses the seat immediately.'
          : 'The server will re-check capacity and the weekly conflict rules before restoring the seat.',
        okLabel: next === 'Inactive' ? 'Drop enrollment' : 'Re-enroll',
        danger: next === 'Inactive'
      });
      if (!ok) return;
      try {
        await App.api('/api/enrollments/' + btn.getAttribute('data-toggle'), { method: 'PATCH', body: { status: next } });
        App.toast(next === 'Inactive' ? 'Enrollment dropped.' : 'Enrollment restored.');
        App.render();
      } catch (e) { App.toast(e.message, 'error'); }
    });

    document.getElementById('newEnrollment').addEventListener('click', function () { App.enrollStudent(); });
  };

  App.enrollStudent = async function (studentId) {
    var students = await App.api('/api/students');
    if (!students.length) {
      App.toast('Add a student record first.', 'warn');
      return;
    }
    App.modal({
      title: 'Enroll a student',
      sub: 'Schedules are limited to the student’s course and year level for the current term.',
      body: '<form id="enrollForm"><div class="form-grid">' +
        '<label class="field span-2"><span>Student</span><select name="studentId" required>' +
        '<option value="">Select a student</option>' + students.map(function (s) {
          return '<option value="' + s._id + '"' + (s._id === studentId ? ' selected' : '') + '>' + App.esc(s.studentId + ' — ' + App.personName(s) + ' · ' + courseLabel(s) + ' Year ' + s.yearLevel) + '</option>';
        }).join('') + '</select></label>' +
        '<label class="field span-2"><span>Class section</span><select name="scheduleId" id="enrollSchedule" required disabled><option value="">Select a student first</option></select></label>' +
        '<div class="form-error span-2" role="alert"></div></div></form>',
      footer: '<button class="btn ghost" type="button" data-close>Cancel</button><button class="btn coral" type="submit" form="enrollForm" id="enrollSubmit">Enroll student</button>',
      onMount: function (wrap) {
        var form = wrap.querySelector('#enrollForm');
        var select = wrap.querySelector('#enrollSchedule');

        async function loadOptions() {
          select.disabled = true;
          select.innerHTML = '<option value="">Loading sections…</option>';
          if (!form.elements.studentId.value) return;
          try {
            var schedules = await App.api('/api/enrollments/options/' + form.elements.studentId.value);
            select.innerHTML = schedules.length
              ? '<option value="">Select a class section</option>' + schedules.map(function (s) {
                return '<option value="' + s._id + '">' + App.esc((s.subject ? s.subject.subjectCode + ' — ' + s.subject.subjectName : 'Class') + ' · ' + (s.room ? s.room.roomCode : '') + ' · ' + App.daysInline(s.weekdays) + ' ' + App.time12(s.startTime) + '–' + App.time12(s.endTime)) + '</option>';
              }).join('')
              : '<option value="">No plotted sections for this student</option>';
            select.disabled = !schedules.length;
          } catch (e) {
            select.innerHTML = '<option value="">' + App.esc(e.message) + '</option>';
          }
        }

        form.elements.studentId.addEventListener('change', loadOptions);
        if (studentId) loadOptions();

        form.addEventListener('submit', async function (event) {
          event.preventDefault();
          var err = form.querySelector('.form-error');
          err.textContent = '';
          var data = App.formData(form);
          if (!data.studentId || !data.scheduleId) { err.textContent = 'Choose a student and a section.'; return; }
          try {
            await App.api('/api/enrollments', { method: 'POST', body: data });
            App.toast('Student enrolled.');
            App.closeModal();
            App.render();
          } catch (e) { err.textContent = e.message; }
        });
      }
    });
  };

  /* ============================== activity ============================== */

  P.activity = async function (params, el) {
    var rows = await App.api('/api/activity-logs?limit=300');
    var categories = [];
    rows.forEach(function (r) { if (r.category && categories.indexOf(r.category) === -1) categories.push(r.category); });
    var state = { q: '', category: '' };

    function table() {
      var list = rows.filter(function (r) {
        if (state.category && r.category !== state.category) return false;
        if (state.q) {
          var hay = [r.action, r.description, r.performedByLabel].join(' ').toLowerCase();
          if (hay.indexOf(state.q.toLowerCase()) === -1) return false;
        }
        return true;
      });
      if (!list.length) return '<tr><td colspan="5">' + App.empty('No activity matches', 'Try clearing the filters.', 'activity') + '</td></tr>';
      return list.map(function (r) {
        return '<tr><td class="nowrap"><div class="cell-main">' + App.fmtDate(r.createdAt, { utc: false }) + '</div><div class="cell-sub">' + App.fmtDateTime(r.createdAt).split(', ')[1] + '</div></td>' +
          '<td><span class="badge-soft">' + App.esc(r.category || 'General') + '</span></td>' +
          '<td><div class="cell-main">' + App.esc(r.action) + '</div><div class="cell-sub">' + App.esc(r.description || '') + '</div></td>' +
          '<td>' + App.esc(r.performedByLabel || 'System') + '</td></tr>';
      }).join('');
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'System',
      title: 'Activity log',
      sub: 'Every scheduling, enrollment and account change is recorded with who did it and when.',
      actions: '<button class="btn ghost" type="button" id="printActivity">' + App.icon('print') + 'Print</button>'
    }) +
      '<section class="card"><div class="toolbar">' +
      '<div class="search-box">' + App.icon('search') + '<input id="activitySearch" type="search" placeholder="Search activity" aria-label="Search activity"></div>' +
      '<select class="input" id="activityCategory" style="width:auto"><option value="">All categories</option>' +
      categories.map(function (c) { return '<option>' + App.esc(c) + '</option>'; }).join('') + '</select>' +
      '<span class="spacer"></span><span class="cell-sub">' + rows.length + ' entries</span></div>' +
      '<div class="table-wrap"><table><thead><tr><th>When</th><th>Category</th><th>Action</th><th>By</th></tr></thead><tbody id="activityBody">' +
      table() + '</tbody></table></div></section>';

    function refresh() { document.getElementById('activityBody').innerHTML = table(); }
    document.getElementById('activitySearch').addEventListener('input', function (e) { state.q = e.target.value.trim(); refresh(); });
    document.getElementById('activityCategory').addEventListener('change', function (e) { state.category = e.target.value; refresh(); });
    document.getElementById('printActivity').addEventListener('click', function () { window.print(); });
  };

  /* ============================== settings ============================== */

  P.settings = async function (params, el) {
    var data = await App.api('/api/settings');
    var s = data.settings;

    function breakRow(b, index) {
      return '<div class="list-row" data-break-row style="padding:8px 0">' +
        '<input class="input" name="breakLabel" placeholder="Label" value="' + App.esc(b.label || '') + '" style="max-width:160px">' +
        '<input class="input" type="time" name="breakStart" value="' + App.esc(b.startTime || '') + '" style="max-width:130px">' +
        '<span class="muted small">to</span>' +
        '<input class="input" type="time" name="breakEnd" value="' + App.esc(b.endTime || '') + '" style="max-width:130px">' +
        '<button class="btn-icon" type="button" data-remove-break aria-label="Remove break">' + App.icon('close') + '</button>' +
        '</div>';
    }

    var rules = ['MWF', 'TTH', 'F', 'SATURDAY', 'SUNDAY'].map(function (pattern) {
      var rule = (s.sessionRules || []).find(function (r) { return r.pattern === pattern; });
      return '<label class="field"><span>' + pattern + ' session minutes</span><input type="number" min="30" max="360" step="30" name="rule_' + pattern + '" value="' + (rule ? rule.minutes : '') + '"></label>';
    }).join('');

    el.innerHTML = App.pageHead({
      eyebrow: 'System',
      title: 'Scheduling settings',
      sub: 'These rules are enforced by the server on every plot, edit and enrollment.',
      actions: ''
    }) +
      '<form id="settingsForm"><div class="grid-2">' +
      '<section class="card"><div class="card-head"><div><h2>School day</h2><div class="card-sub">Window used by the timetable and availability checks</div></div></div>' +
      '<div class="form-grid">' +
      '<label class="field"><span>Day start</span><input type="time" name="dayStart" value="' + App.esc(s.dayStart) + '" required></label>' +
      '<label class="field"><span>Day end</span><input type="time" name="dayEnd" value="' + App.esc(s.dayEnd) + '" required></label>' +
      '<label class="field"><span>Daily target hours per room</span><input type="number" min="1" max="24" name="dailyTargetHours" value="' + s.dailyTargetHours + '" required></label>' +
      '<label class="field"><span>Section capacity (max 10)</span><input type="number" min="1" max="10" name="sectionCapacity" value="' + s.sectionCapacity + '" required></label>' +
      '<label class="field"><span>Active room limit</span><input type="number" min="0" max="500" name="activeRoomLimit" value="' + s.activeRoomLimit + '"></label>' +
      '<label class="field"><span>Pattern durations</span><select name="enforcePatternDuration"><option value="true"' + (s.enforcePatternDuration !== false ? ' selected' : '') + '>Use session rules below</option><option value="false"' + (s.enforcePatternDuration === false ? ' selected' : '') + '>Use units × 60 minutes</option></select></label>' +
      '</div>' +
      '<div class="divider"></div>' +
      '<label class="field"><span>Session length by day pattern (minutes)</span></label>' +
      '<div class="form-grid" style="margin-top:8px">' + rules + '</div>' +
      '<p class="small muted" style="margin:12px 0 0">Seats per section = the smaller of the room capacity and section capacity. A class list can never exceed 10 enrolled students.</p>' +
      '</section>' +
      '<section class="card"><div class="card-head"><div><h2>Breaks</h2><div class="card-sub">Optional — classes never cross an enabled break</div></div></div>' +
      '<label class="field"><span>Break handling</span><select name="breaksEnabled"><option value="false"' + (!s.breaksEnabled ? ' selected' : '') + '>Disabled</option><option value="true"' + (s.breaksEnabled ? ' selected' : '') + '>Enabled</option></select></label>' +
      '<div id="breakList" style="margin-top:12px">' + (s.breaks || []).map(breakRow).join('') + '</div>' +
      '<button class="btn ghost sm" type="button" id="addBreak" style="margin-top:10px">' + App.icon('plus') + 'Add break</button>' +
      '<div class="divider"></div>' +
      '<div class="form-error" role="alert"></div>' +
      '<button class="btn coral" type="submit" style="width:100%;margin-top:6px">Save scheduling settings</button>' +
      '</section></div></form>';

    var form = document.getElementById('settingsForm');
    var list = document.getElementById('breakList');

    document.getElementById('addBreak').addEventListener('click', function () {
      var tmp = document.createElement('div');
      tmp.innerHTML = breakRow({ label: '', startTime: '', endTime: '' });
      list.appendChild(tmp.firstChild);
    });

    list.addEventListener('click', function (event) {
      if (event.target.closest('[data-remove-break]')) event.target.closest('[data-break-row]').remove();
    });

    form.addEventListener('submit', async function (event) {
      event.preventDefault();
      var err = form.querySelector('.form-error');
      err.textContent = '';
      var payload = {
        dayStart: form.elements.dayStart.value,
        dayEnd: form.elements.dayEnd.value,
        dailyTargetHours: Number(form.elements.dailyTargetHours.value),
        sectionCapacity: Number(form.elements.sectionCapacity.value),
        activeRoomLimit: Number(form.elements.activeRoomLimit.value),
        enforcePatternDuration: form.elements.enforcePatternDuration.value === 'true',
        breaksEnabled: form.elements.breaksEnabled.value === 'true',
        sessionRules: [],
        breaks: []
      };
      ['MWF', 'TTH', 'F', 'SATURDAY', 'SUNDAY'].forEach(function (pattern) {
        var value = form.elements['rule_' + pattern].value;
        if (value !== '') payload.sessionRules.push({ pattern: pattern, minutes: Number(value) });
      });
      list.querySelectorAll('[data-break-row]').forEach(function (row) {
        var start = row.querySelector('[name="breakStart"]').value;
        var end = row.querySelector('[name="breakEnd"]').value;
        if (start && end) payload.breaks.push({ label: row.querySelector('[name="breakLabel"]').value, startTime: start, endTime: end });
      });
      try {
        await App.api('/api/settings', { method: 'PATCH', body: payload });
        App.toast('Scheduling settings saved.');
      } catch (e) { err.textContent = e.message; }
    });
  };

  /* ============================== shared profile ============================== */

  P.profile = async function (params, el) {
    var data = await App.api('/api/profile');
    var user = data.user;
    var profile = data.profile || {};
    var isPerson = user.role !== 'Admin';
    var name = isPerson ? App.personName(profile) : user.username;

    el.innerHTML = App.pageHead({
      eyebrow: 'Account',
      title: 'My profile',
      sub: 'Your sign-in details and personal information.'
    }) +
      '<div class="grid-2">' +
      '<section class="card"><div class="card-head"><div><h2>Account</h2><div class="card-sub">' + App.esc(user.role) + ' portal</div></div>' + App.status(user.status) + '</div>' +
      '<div class="info-grid">' +
      '<div class="info-item"><span>Name</span><strong>' + App.esc(name) + '</strong></div>' +
      '<div class="info-item"><span>Username</span><strong>' + App.esc(user.username) + '</strong></div>' +
      '<div class="info-item"><span>Email</span><strong>' + App.esc(user.email) + '</strong></div>' +
      '<div class="info-item"><span>Role</span><strong>' + App.esc(user.role) + '</strong></div>' +
      (isPerson ? '<div class="info-item"><span>School ID</span><strong>' + App.esc(profile.studentId || profile.instructorId || '—') + '</strong></div>' : '') +
      (profile.course ? '<div class="info-item"><span>Course</span><strong>' + App.esc(profile.course.code + ' — ' + profile.course.name) + '</strong></div>' : '') +
      (profile.department ? '<div class="info-item"><span>Department</span><strong>' + App.esc(profile.department) + '</strong></div>' : '') +
      (profile.yearLevel ? '<div class="info-item"><span>Year level</span><strong>Year ' + profile.yearLevel + '</strong></div>' : '') +
      (profile.contactNumber ? '<div class="info-item"><span>Contact</span><strong>' + App.esc(profile.contactNumber) + '</strong></div>' : '') +
      '</div></section>' +
      '<section class="card"><div class="card-head"><div><h2>Update contact details</h2><div class="card-sub">Changes are applied to this account only</div></div></div>' +
      '<form id="profileForm"><div class="form-grid">' +
      '<label class="field span-2"><span>Email</span><input type="email" name="email" maxlength="254" value="' + App.esc(user.email) + '" required></label>' +
      (user.role === 'Admin' ? '<label class="field span-2"><span>Username</span><input name="username" maxlength="50" value="' + App.esc(user.username) + '" required></label>' : '') +
      (isPerson ? '<label class="field span-2"><span>Contact number</span><input name="contactNumber" maxlength="40" value="' + App.esc(profile.contactNumber || '') + '" required></label>' : '') +
      '<div class="form-error span-2" role="alert"></div></div>' +
      '<button class="btn coral" type="submit" style="margin-top:14px">Save contact details</button></form></section>' +
      '</div>' +
      '<section class="card"><div class="card-head"><div><h2>Change password</h2><div class="card-sub">Use at least 8 characters</div></div></div>' +
      '<form id="passwordForm"><div class="form-grid">' +
      '<label class="field"><span>Current password</span><input type="password" name="currentPassword" autocomplete="current-password" required></label>' +
      '<label class="field"><span>New password</span><input type="password" name="newPassword" minlength="8" maxlength="128" autocomplete="new-password" required></label>' +
      '<label class="field"><span>Confirm new password</span><input type="password" name="confirmPassword" minlength="8" maxlength="128" autocomplete="new-password" required></label>' +
      '<div class="form-error span-2" role="alert"></div></div>' +
      '<button class="btn" type="submit" style="margin-top:14px">Update password</button></form></section>';

    document.getElementById('profileForm').addEventListener('submit', async function (event) {
      event.preventDefault();
      var form = event.currentTarget;
      var err = form.querySelector('.form-error');
      err.textContent = '';
      try {
        var payload = App.formData(form);
        await App.api('/api/profile', { method: 'PATCH', body: payload });
        App.toast('Profile updated.');
        App.render();
      } catch (e) { err.textContent = e.message; }
    });

    document.getElementById('passwordForm').addEventListener('submit', async function (event) {
      event.preventDefault();
      var form = event.currentTarget;
      var err = form.querySelector('.form-error');
      err.textContent = '';
      var data = App.formData(form);
      if (data.newPassword !== data.confirmPassword) {
        err.textContent = 'New password confirmation does not match.';
        return;
      }
      try {
        await App.api('/api/profile', { method: 'PATCH', body: data });
        form.reset();
        App.toast('Password updated.');
      } catch (e) { err.textContent = e.message; }
    });
  };
})();
