/* ============================================================
   SELL SYSTEM — Admin academics pages
   Subjects, rooms, courses, prospectus, school years.
   ============================================================ */
(function () {
  'use strict';

  var P = App.pages = App.pages || {};

  function courseLabel(course) {
    return course ? (course.code || course.courseCode) : '';
  }

  function courseName(course) {
    return course ? (course.name || course.courseName) : '';
  }

  function courseOptions(courses, selected) {
    return courses.map(function (c) {
      var value = courseLabel(c);
      return '<option value="' + App.esc(value) + '"' + (value === selected ? ' selected' : '') + '>' +
        App.esc(value) + ' — ' + App.esc(courseName(c)) + '</option>';
    }).join('');
  }

  function yearOptions(selected) {
    return [1, 2, 3, 4].map(function (y) {
      return '<option value="' + y + '"' + (Number(selected) === y ? ' selected' : '') + '>Year ' + y + '</option>';
    }).join('');
  }

  function termOptions(selected) {
    return ['1st Semester', '2nd Semester', 'Summer'].map(function (t) {
      return '<option' + (t === selected ? ' selected' : '') + '>' + t + '</option>';
    }).join('');
  }

  function schoolYearOptions(semesters, selected) {
    var years = [];
    (semesters || []).forEach(function (s) {
      if (years.indexOf(s.academicYear) === -1) years.push(s.academicYear);
    });
    return years.sort().reverse().map(function (year) {
      return '<option value="' + App.esc(year) + '"' + (year === selected ? ' selected' : '') + '>' + App.esc(year) + '</option>';
    }).join('');
  }

  function normalizeTerm(value) {
    return value === 'Summer' ? 'Summer' : value;
  }

  /* ============================== subjects ============================== */

  P.subjects = async function (params, el) {
    var meta = await Promise.all([App.api('/api/semesters'), App.api('/api/courses')]);
    var semesters = meta[0];
    var courses = meta[1];
    var currentTerm = semesters.find(function (s) { return s.isCurrent; }) || semesters[0] || null;
    var state = {
      q: '',
      course: '',
      year: '',
      term: '',
      lab: '',
      schoolYear: currentTerm ? currentTerm.academicYear : '',
      availability: 'all'
    };
    var subjects = [];
    var loadSequence = 0;

    function subjectsUrl() {
      var query = [];
      if (state.schoolYear) query.push('schoolYearId=' + encodeURIComponent(state.schoolYear));
      if (state.term) query.push('semester=' + encodeURIComponent(state.term));
      query.push('availability=' + encodeURIComponent(state.availability));
      return '/api/subjects?' + query.join('&');
    }

    function filtered() {
      return subjects.filter(function (s) {
        if (state.course && courseLabel(s.course) !== state.course) return false;
        if (state.year && String(s.yearLevel || '') !== state.year) return false;
        if (state.term && s.term !== state.term) return false;
        if (state.lab === 'lab' && !s.laboratoryRequired) return false;
        if (state.lab === 'lecture' && s.laboratoryRequired) return false;
        if (state.q) {
          var hay = [s.subjectCode, s.subjectName, courseLabel(s.course)].join(' ').toLowerCase();
          if (hay.indexOf(state.q.toLowerCase()) === -1) return false;
        }
        return true;
      });
    }

    function cards() {
      var list = filtered();
      if (!list.length) return App.empty('No subjects found', 'Adjust the filters or add a subject.', 'book');
      return '<div class="subject-grid">' + list.map(function (s) {
        var isOpen = Number(s.plottedSections || 0) > 0;
        return '<article class="subject-card">' +
          '<div style="display:flex;align-items:flex-start;gap:10px">' +
          '<div><div class="subject-code">' + App.esc(s.subjectCode) + '</div><h3>' + App.esc(s.subjectName) + '</h3></div>' +
          '<span style="margin-left:auto;display:flex;flex-direction:column;align-items:flex-end;gap:5px">' +
          App.status(s.status) + App.status(isOpen ? 'Open' : 'Not offered this term', isOpen ? '' : 'inactive') +
          '</span></div>' +
          '<div class="row"><span>Course</span><b>' + App.esc(courseLabel(s.course) || '—') + '</b></div>' +
          '<div class="row"><span>Units</span><b>' + (s.units || 0) + ' unit' + (s.units === 1 ? '' : 's') + '</b></div>' +
          '<div class="row"><span>Room type</span><b>' + (s.laboratoryRequired ? 'Laboratory' : 'Lecture') + '</b></div>' +
          '<div class="row"><span>Plotted sections</span><b>' + (s.plottedSections || 0) + '</b></div>' +
          (s.yearLevel ? '<div class="row"><span>Prospectus</span><b>Year ' + s.yearLevel + ' · ' + App.esc(s.term) + '</b></div>' : '') +
          '<div style="display:flex;gap:6px;margin-top:6px">' +
          '<button class="btn ghost sm" type="button" data-open="' + s._id + '">' + App.icon('eye') + 'Details</button>' +
          '<button class="btn sm" type="button" data-edit="' + s._id + '">' + App.icon('edit') + 'Edit</button>' +
          '</div></article>';
      }).join('') + '</div>';
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'Academics',
      title: 'Subjects',
      sub: 'Every subject in the catalog. Open badges reflect the selected school year and semester.',
      actions: '<button class="btn coral" type="button" id="addSubject">' + App.icon('plus') + 'Add Subject</button>'
    }) +
      '<section class="card"><div class="toolbar">' +
      '<div class="search-box">' + App.icon('search') + '<input id="subjectSearch" type="search" placeholder="Search code or title" aria-label="Search subjects"></div>' +
      '<select class="input" id="subjectSchoolYear" style="width:auto" aria-label="School year">' + schoolYearOptions(semesters, state.schoolYear) + '</select>' +
      '<select class="input" id="subjectTerm" style="width:auto" aria-label="Semester"><option value="">All semesters</option>' + termOptions(state.term) + '</select>' +
      '<select class="input" id="subjectAvailability" style="width:auto" aria-label="Availability">' +
      '<option value="all">All availability</option><option value="open">Open</option><option value="not_open">Not open</option></select>' +
      '<select class="input" id="subjectCourse" style="width:auto" aria-label="Course"><option value="">All courses</option>' +
      courses.map(function (c) { return '<option value="' + App.esc(courseLabel(c)) + '">' + App.esc(courseLabel(c)) + '</option>'; }).join('') + '</select>' +
      '<select class="input" id="subjectYear" style="width:auto" aria-label="Year level"><option value="">All year levels</option>' + yearOptions() + '</select>' +
      '<select class="input" id="subjectLab" style="width:auto" aria-label="Room type"><option value="">All room types</option><option value="lab">Laboratory</option><option value="lecture">Lecture</option></select>' +
      '<button class="btn ghost sm" type="button" id="subjectReset">' + App.icon('x') + 'Reset filters</button>' +
      '<span class="spacer"></span><span class="cell-sub" id="subjectCount"></span></div>' +
      '<div id="subjectList">' + App.loading() + '</div></section>';

    function refresh() {
      document.getElementById('subjectList').innerHTML = cards();
      document.getElementById('subjectCount').textContent = filtered().length + ' subjects';
    }

    async function loadSubjects() {
      var sequence = ++loadSequence;
      try {
        var rows = await App.api(subjectsUrl());
        if (sequence !== loadSequence) return;
        subjects = rows;
        refresh();
      } catch (err) {
        if (sequence !== loadSequence) return;
        document.getElementById('subjectList').innerHTML = App.empty('Could not load subjects', err.message, 'book');
        document.getElementById('subjectCount').textContent = '';
        App.toast(err.message, 'error');
      }
    }

    document.getElementById('subjectSearch').addEventListener('input', function (e) { state.q = e.target.value.trim(); refresh(); });
    document.getElementById('subjectCourse').addEventListener('change', function (e) { state.course = e.target.value; refresh(); });
    document.getElementById('subjectYear').addEventListener('change', function (e) { state.year = e.target.value; refresh(); });
    document.getElementById('subjectTerm').addEventListener('change', function (e) { state.term = e.target.value; loadSubjects(); });
    document.getElementById('subjectSchoolYear').addEventListener('change', function (e) { state.schoolYear = e.target.value; loadSubjects(); });
    document.getElementById('subjectAvailability').addEventListener('change', function (e) { state.availability = e.target.value; loadSubjects(); });
    document.getElementById('subjectLab').addEventListener('change', function (e) { state.lab = e.target.value; refresh(); });
    document.getElementById('subjectReset').addEventListener('click', function () {
      state.q = '';
      state.course = '';
      state.year = '';
      state.term = '';
      state.lab = '';
      state.schoolYear = currentTerm ? currentTerm.academicYear : '';
      state.availability = 'all';
      document.getElementById('subjectSearch').value = '';
      document.getElementById('subjectCourse').value = '';
      document.getElementById('subjectYear').value = '';
      document.getElementById('subjectTerm').value = state.term;
      document.getElementById('subjectSchoolYear').value = state.schoolYear;
      document.getElementById('subjectAvailability').value = 'all';
      document.getElementById('subjectLab').value = '';
      loadSubjects();
    });

    document.getElementById('subjectList').addEventListener('click', async function (event) {
      var open = event.target.closest('[data-open]');
      var edit = event.target.closest('[data-edit]');
      if (open) openSubject(subjects.find(function (s) { return s._id === open.getAttribute('data-open'); }));
      if (edit) openSubjectForm(subjects.find(function (s) { return s._id === edit.getAttribute('data-edit'); }), courses, subjects);
    });

    document.getElementById('addSubject').addEventListener('click', function () {
      openSubjectForm(null, courses, subjects);
    });

    await loadSubjects();
  };

  async function openSubject(subject) {
    if (!subject) return;
    var data = await App.api('/api/subjects/' + subject._id);
    var schedules = data.schedules || [];
    var rows = schedules.length ? schedules.map(function (s) {
      return '<tr><td><div class="cell-main">' + App.esc(App.daysInline(s.weekdays)) + '</div><div class="cell-sub">' + App.time12(s.startTime) + '–' + App.time12(s.endTime) + '</div></td>' +
        '<td>' + App.esc(s.room ? s.room.roomCode : '—') + '</td>' +
        '<td>' + App.esc(s.instructor ? App.personName(s.instructor) : 'TBA') + '</td>' +
        '<td>' + App.esc(s.course ? s.course.code : '—') + ' · Year ' + App.esc(s.yearLevel) + '</td>' +
        '<td class="right">' + App.status(s.status) + '</td></tr>';
    }).join('') : '<tr><td colspan="5">' + App.empty('No sections plotted', 'Use Schedules & Rooms to assign a room and time.', 'calendar') + '</td></tr>';

    App.modal({
      title: subject.subjectCode + ' — ' + subject.subjectName,
      sub: courseLabel(subject.course) + ' · ' + subject.units + ' unit' + (subject.units === 1 ? '' : 's') + ' · ' + (subject.laboratoryRequired ? 'Laboratory subject' : 'Lecture subject'),
      wide: true,
      body: '<div class="info-grid" style="margin-bottom:14px">' +
        '<div class="info-item"><span>Status</span><strong>' + App.esc(subject.status) + '</strong></div>' +
        '<div class="info-item"><span>Course</span><strong>' + App.esc(courseName(subject.course) || '—') + '</strong></div>' +
        '<div class="info-item"><span>Prerequisites</span><strong>' + App.esc((subject.prerequisites || []).map(function (p) { return p.subjectCode; }).join(', ') || 'None') + '</strong></div>' +
        '<div class="info-item"><span>Co-requisites</span><strong>' + App.esc((subject.coRequisites || []).map(function (p) { return p.subjectCode; }).join(', ') || 'None') + '</strong></div>' +
        '</div>' +
        (subject.description ? '<p class="small muted" style="margin:0 0 14px">' + App.esc(subject.description) + '</p>' : '') +
        '<div class="divider"></div><h3 style="font-size:13px;margin:0 0 10px">Class sections</h3>' +
        '<div class="table-wrap"><table><thead><tr><th>Days &amp; time</th><th>Room</th><th>Instructor</th><th>Section</th><th class="right">Status</th></tr></thead><tbody>' +
        rows + '</tbody></table></div>',
      footer: '<a class="btn ghost" href="#/schedules">Open timetable</a><button class="btn" type="button" data-close>Done</button>'
    });
  }

  function openSubjectForm(subject, courses, allSubjects) {
    var isEdit = Boolean(subject);
    var prerequisiteOptions = allSubjects.filter(function (s) { return !isEdit || s._id !== subject._id; }).map(function (s) {
      var selected = isEdit && (subject.prerequisites || []).some(function (p) { return p._id === s._id; });
      return '<option value="' + s._id + '"' + (selected ? ' selected' : '') + '>' + App.esc(s.subjectCode + ' — ' + s.subjectName) + '</option>';
    }).join('');
    var coOptions = allSubjects.filter(function (s) { return !isEdit || s._id !== subject._id; }).map(function (s) {
      var selected = isEdit && (subject.coRequisites || []).some(function (p) { return p._id === s._id; });
      return '<option value="' + s._id + '"' + (selected ? ' selected' : '') + '>' + App.esc(s.subjectCode + ' — ' + s.subjectName) + '</option>';
    }).join('');

    App.modal({
      title: isEdit ? 'Edit subject' : 'Add subject',
      sub: isEdit ? 'Catalog details and prerequisites. Placement stays in the prospectus page.' : 'The subject is created and can be placed in a prospectus at the same time.',
      wide: true,
      body: '<form id="subjectForm"><div class="form-grid">' +
        '<label class="field"><span>Subject code</span><input name="subjectCode" maxlength="30" required value="' + App.esc(isEdit ? subject.subjectCode : '') + '"></label>' +
        '<label class="field"><span>Units</span><select name="units">' + [1, 2, 3, 4, 5, 6].map(function (u) { return '<option' + (Number(isEdit ? subject.units : 3) === u ? ' selected' : '') + '>' + u + '</option>'; }).join('') + '</select></label>' +
        '<label class="field span-2"><span>Subject title</span><input name="subjectName" maxlength="150" required value="' + App.esc(isEdit ? subject.subjectName : '') + '"></label>' +
        '<label class="field span-2"><span>Course</span><select name="course" required' + (isEdit ? ' disabled' : '') + '>' + courseOptions(courses, isEdit ? courseLabel(subject.course) : '') + '</select>' +
        (isEdit ? '<input type="hidden" name="course" value="' + App.esc(courseLabel(subject.course)) + '">' : '') + '</label>' +
        '<label class="field"><span>Room type</span><select name="laboratoryRequired"><option value="false"' + (isEdit && subject.laboratoryRequired ? '' : ' selected') + '>Lecture room</option><option value="true"' + (isEdit && subject.laboratoryRequired ? ' selected' : '') + '>Laboratory room</option></select></label>' +
        '<label class="field"><span>Status</span><select name="status"><option' + (!isEdit || subject.status === 'Active' ? ' selected' : '') + '>Active</option><option' + (isEdit && subject.status === 'Inactive' ? ' selected' : '') + '>Inactive</option></select></label>' +
        (isEdit ? '' :
          '<label class="field"><span>Prospectus year</span><select name="yearLevel">' + yearOptions(1) + '</select></label>' +
          '<label class="field"><span>Prospectus semester</span><select name="term">' + termOptions('1st Semester') + '</select></label>') +
        '<label class="field span-2"><span>Description (optional)</span><textarea name="description" maxlength="1000">' + App.esc(isEdit ? subject.description : '') + '</textarea></label>' +
        '<label class="field"><span>Prerequisites (hold Ctrl / Cmd)</span><select name="prerequisiteIds" multiple size="4">' + prerequisiteOptions + '</select></label>' +
        '<label class="field"><span>Co-requisites (hold Ctrl / Cmd)</span><select name="coRequisiteIds" multiple size="4">' + coOptions + '</select></label>' +
        '<div class="form-error span-2" role="alert"></div></div></form>',
      footer: '<button class="btn ghost" type="button" data-close>Cancel</button><button class="btn coral" type="submit" form="subjectForm">' + (isEdit ? 'Save changes' : 'Create subject') + '</button>',
      onMount: function (wrap) {
        wrap.querySelector('#subjectForm').addEventListener('submit', async function (event) {
          event.preventDefault();
          var form = event.currentTarget;
          var err = form.querySelector('.form-error');
          err.textContent = '';
          var data = App.formData(form);
          if (data.course && isEdit) data.course = courseLabel(subject.course);
          try {
            if (isEdit) {
              delete data.yearLevel;
              delete data.term;
              await App.api('/api/subjects/' + subject._id, { method: 'PATCH', body: data });
              App.toast('Subject updated.');
            } else {
              await App.api('/api/subjects', { method: 'POST', body: data });
              App.toast('Subject created.');
            }
            App.closeModal();
            App.render();
          } catch (e) { err.textContent = e.message; }
        });
      }
    });
  }

  /* ============================== rooms ============================== */

  App.renderRoomDirectory = async function (params, el) {
    var rooms = await App.api('/api/rooms');
    var state = { q: '', type: '', status: '' };

    function filtered() {
      return rooms.filter(function (r) {
        if (state.type && r.roomType !== state.type) return false;
        if (state.status) {
          if (state.status === 'Inactive' && r.status !== 'Inactive') return false;
          if (state.status === 'Available' && r.availability !== 'Available') return false;
          if (state.status === 'Occupied' && r.availability !== 'Occupied') return false;
        }
        if (state.q) {
          var hay = [r.roomCode, r.roomName, r.building].join(' ').toLowerCase();
          if (hay.indexOf(state.q.toLowerCase()) === -1) return false;
        }
        return true;
      });
    }

    function cards() {
      var list = filtered();
      if (!list.length) return App.empty('No rooms found', 'Adjust the filters or add a room.', 'door');
      return '<div class="room-grid">' + list.map(function (r) {
        return '<article class="room-card">' +
          '<a class="room-photo" href="#/room/' + r._id + '" style="text-decoration:none">' +
          (r.photoPath
            ? '<img src="' + App.esc(r.photoPath) + '" alt="' + App.esc(r.roomName) + '">'
            : App.icon('building')) +
          '</a>' +
          '<div class="room-body"><div style="display:flex;gap:8px;align-items:center">' +
          '<div class="subject-code">' + App.esc(r.roomCode) + '</div>' +
          '<span style="margin-left:auto">' + App.status(r.availability === 'Unavailable' || r.status === 'Inactive' ? 'Inactive' : r.availability, r.availability === 'Occupied' ? 'warn' : '') + '</span></div>' +
          '<h3><a href="#/room/' + r._id + '" style="color:inherit">' + App.esc(r.roomName) + '</a></h3>' +
          '<div class="room-meta">' + App.esc(r.building || 'Main Building') + ' · ' + App.esc(r.roomType) + '</div>' +
          '<div class="room-meta">Capacity ' + r.capacity + ' · ' + r.activeScheduleCount + ' active section' + (r.activeScheduleCount === 1 ? '' : 's') + '</div>' +
          '<div class="room-foot"><a class="btn ghost sm" href="#/room/' + r._id + '">' + App.icon('eye') + 'Open</a>' +
          '<button class="btn sm" type="button" data-edit="' + r._id + '">' + App.icon('edit') + 'Edit</button></div>' +
          '</div></article>';
      }).join('') + '</div>';
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'Scheduling',
      title: 'Room directory',
      sub: rooms.length + ' rooms available for plotting, with derived availability and capacity.',
      actions: '<button class="btn coral" type="button" id="addRoom">' + App.icon('plus') + 'Add Room</button>'
    }) +
      '<section class="card"><div class="toolbar">' +
      '<div class="search-box">' + App.icon('search') + '<input id="roomSearch" type="search" placeholder="Search room, code or building" aria-label="Search rooms"></div>' +
      '<select class="input" id="roomType" style="width:auto"><option value="">All room types</option><option>Laboratory</option><option>Non-Laboratory</option></select>' +
      '<select class="input" id="roomStatus" style="width:auto"><option value="">All availability</option><option>Available</option><option>Occupied</option><option>Inactive</option></select>' +
      '<span class="spacer"></span><span class="cell-sub" id="roomCount"></span></div>' +
      '<div id="roomList">' + cards() + '</div></section>';

    function refresh() {
      document.getElementById('roomList').innerHTML = cards();
      document.getElementById('roomCount').textContent = filtered().length + ' rooms';
    }
    refresh();
    document.getElementById('roomSearch').addEventListener('input', function (e) { state.q = e.target.value.trim(); refresh(); });
    document.getElementById('roomType').addEventListener('change', function (e) { state.type = e.target.value; refresh(); });
    document.getElementById('roomStatus').addEventListener('change', function (e) { state.status = e.target.value; refresh(); });

    document.getElementById('roomList').addEventListener('click', function (event) {
      var edit = event.target.closest('[data-edit]');
      if (!edit) return;
      openRoomForm(rooms.find(function (r) { return r._id === edit.getAttribute('data-edit'); }));
    });
    document.getElementById('addRoom').addEventListener('click', function () { openRoomForm(null); });
  };

  function openRoomForm(room) {
    var isEdit = Boolean(room);
    App.modal({
      title: isEdit ? 'Edit room' : 'Add room',
      sub: isEdit ? 'Update room details or replace its photo. Changes are validated against active schedules and enrollments.' : 'New rooms become selectable in the plotting screen immediately.',
      wide: true,
      body: '<form id="roomForm"><div class="form-grid">' +
        '<label class="field"><span>Room code</span><input name="roomCode" maxlength="40" required value="' + App.esc(isEdit ? room.roomCode : '') + '"' + (isEdit ? ' disabled' : '') + '>' +
        (isEdit ? '<input type="hidden" name="roomCode" value="' + App.esc(room.roomCode) + '">' : '') + '</label>' +
        '<label class="field"><span>Capacity</span><input type="number" name="capacity" min="1" max="500" required value="' + (isEdit ? room.capacity : 40) + '"></label>' +
        '<label class="field span-2"><span>Room name</span><input name="roomName" maxlength="120" required value="' + App.esc(isEdit ? room.roomName : '') + '"></label>' +
        '<label class="field"><span>Building</span><input name="building" maxlength="120" value="' + App.esc(isEdit ? room.building : 'Main Building') + '"></label>' +
        '<label class="field"><span>Room type</span><select name="roomType"><option value="Non-Laboratory"' + (isEdit && room.roomType === 'Laboratory' ? '' : ' selected') + '>Lecture room</option><option value="Laboratory"' + (isEdit && room.roomType === 'Laboratory' ? ' selected' : '') + '>Laboratory</option></select></label>' +
        '<label class="field"><span>Status</span><select name="status"><option value="Active"' + (!isEdit || room.status === 'Active' ? ' selected' : '') + '>Open</option><option value="Inactive"' + (isEdit && room.status === 'Inactive' ? ' selected' : '') + '>Unavailable</option></select></label>' +
        '<label class="field"><span>Equipment (comma separated)</span><input name="equipment" maxlength="300" value="' + App.esc(isEdit ? (room.equipment || []).join(', ') : '') + '"></label>' +
        (isEdit ? '<div class="field span-2 room-photo-field"><span>Room photo</span>' +
          (room.photoPath ? '<img class="room-photo-preview" src="' + App.esc(room.photoPath) + '" alt="' + App.esc(room.roomName) + '">' : '') +
          '<input id="roomPhotoInput" type="file" accept="image/jpeg,image/png,image/webp">' +
          '<span class="hint">JPG, PNG or WebP up to 5 MB. Choose a file to replace the current photo.</span></div>' : '') +
        '<div class="form-error span-2" role="alert"></div></div></form>',
      footer: '<button class="btn ghost" type="button" data-close>Cancel</button><button class="btn coral" type="submit" form="roomForm">' + (isEdit ? 'Save changes' : 'Create room') + '</button>',
      onMount: function (wrap) {
        wrap.querySelector('#roomForm').addEventListener('submit', async function (event) {
          event.preventDefault();
          var form = event.currentTarget;
          var err = form.querySelector('.form-error');
          err.textContent = '';
          var data = App.formData(form);
          data.equipment = data.equipment ? data.equipment.split(',').map(function (x) { return x.trim(); }).filter(Boolean) : [];
          var fileInput = wrap.querySelector('#roomPhotoInput');
          var file = fileInput && fileInput.files[0] ? fileInput.files[0] : null;
          if (file && file.size > 5 * 1024 * 1024) {
            err.textContent = 'The photo must be 5 MB or smaller.';
            return;
          }
          try {
            if (isEdit) {
              delete data.roomCode;
              await App.api('/api/rooms/' + room._id, { method: 'PATCH', body: data });
              if (file) {
                var photoBody = new FormData();
                photoBody.append('photo', file);
                await App.api('/api/rooms/' + room._id + '/photo', { method: 'POST', body: photoBody });
              }
              App.toast(file ? 'Room and photo updated.' : 'Room updated.');
            } else {
              await App.api('/api/rooms', { method: 'POST', body: data });
              App.toast('Room created. Open Edit room to add a photo.');
            }
            App.closeModal();
            App.render();
          } catch (e) { err.textContent = e.message; }
        });
      }
    });
  }

  P.room = async function (params, el) {
    var data = await App.api('/api/rooms/' + params[0]);
    var room = data.room;
    var schedules = data.schedules || [];
    var active = schedules.filter(function (s) { return s.status === 'Active'; });
    var options = await App.api('/api/schedules/options');
    active.forEach(function (s) { s.room = room.roomCode; });
    var sessions = App.normalizeSessions(active);

    var rows = schedules.length ? schedules.map(function (s) {
      return '<tr><td><div class="cell-main">' + App.esc(s.subject ? s.subject.subjectCode : '—') + '</div><div class="cell-sub">' + App.esc(s.subject ? s.subject.subjectName : '') + '</div></td>' +
        '<td>' + App.esc(s.course ? s.course.code : '—') + ' · Year ' + App.esc(s.yearLevel) + '</td>' +
        '<td>' + App.esc(s.instructor ? App.personName(s.instructor) : 'TBA') + '</td>' +
        '<td class="nowrap"><div class="cell-main">' + App.esc(App.daysInline(s.weekdays)) + '</div><div class="cell-sub">' + App.time12(s.startTime) + '–' + App.time12(s.endTime) + '</div></td>' +
        '<td class="right">' + App.status(s.status) + '</td></tr>';
    }).join('') : '<tr><td colspan="5">' + App.empty('No classes in this room', 'Plot a class to see it on the room schedule.', 'calendar') + '</td></tr>';

    el.innerHTML = App.pageHead({
      eyebrow: 'Room record',
      title: room.roomCode + ' — ' + room.roomName,
      sub: [room.building, room.roomType, room.capacity + ' seats'].filter(Boolean).join(' · '),
      actions: '<a class="btn ghost" href="#/rooms">Back</a><button class="btn ghost" type="button" id="viewTimetable">' + App.icon('calendar') + 'Timetable</button><button class="btn coral" type="button" id="editRoom">' + App.icon('edit') + 'Edit room</button>'
    }) +
      '<div class="grid-2">' +
      '<section class="card"><div class="card-head"><div><h2>Room details</h2><div class="card-sub">' + App.esc(data.availabilityMeaning || '') + '</div></div>' +
      App.status(room.status === 'Inactive' ? 'Inactive' : data.availability, data.availability === 'Occupied' ? 'warn' : '') + '</div>' +
      '<div class="info-grid">' +
      '<div class="info-item"><span>Room code</span><strong>' + App.esc(room.roomCode) + '</strong></div>' +
      '<div class="info-item"><span>Building</span><strong>' + App.esc(room.building || '—') + '</strong></div>' +
      '<div class="info-item"><span>Capacity</span><strong>' + room.capacity + ' students</strong></div>' +
      '<div class="info-item"><span>Room type</span><strong>' + App.esc(room.roomType) + '</strong></div>' +
      '<div class="info-item"><span>Active sections</span><strong>' + data.activeScheduleCount + '</strong></div>' +
      '<div class="info-item"><span>Equipment</span><strong>' + App.esc((room.equipment || []).join(', ') || '—') + '</strong></div>' +
      '</div></section>' +
      '<section class="card"><div class="card-head"><div><h2>Room photo</h2><div class="card-sub">' + (room.photoPath ? 'Current room photo' : 'No photo uploaded yet') + '</div></div></div>' +
      (room.photoPath
        ? '<img class="room-detail-photo" src="' + App.esc(room.photoPath) + '" alt="' + App.esc(room.roomName) + '">'
        : '<div class="room-photo-placeholder">' + App.icon('building') + '<span>Add a photo from Edit room.</span></div>') +
      '</section>' +
      '</div>' +
      '<section class="card" style="margin-top:16px"><div class="card-head"><div><h2>Room schedule</h2><div class="card-sub">Active and inactive schedule records for this room</div></div></div>' +
      '<div class="table-wrap"><table><thead><tr><th>Subject</th><th>Section</th><th>Instructor</th><th>Schedule</th><th class="right">Status</th></tr></thead><tbody>' +
      rows + '</tbody></table></div></section>';

    document.getElementById('editRoom').addEventListener('click', function () { openRoomForm(room); });
    document.getElementById('viewTimetable').addEventListener('click', function () {
      var dialog = App.modal({
        title: 'Weekly timetable',
        sub: room.roomCode + ' — ' + room.roomName + ' · ' + active.length + ' active class' + (active.length === 1 ? '' : 'es'),
        wide: true,
        body: active.length ? App.timetable(sessions, { start: options.settings.dayStart, end: options.settings.dayEnd }) : App.empty('No active classes', 'This room is free for the whole week.', 'calendar')
      });
      var card = dialog.querySelector('.modal-card');
      if (card) card.classList.add('timetable-modal');
    });
  };

  /* ============================== courses ============================== */

  P.courses = async function (params, el) {
    var courses = await App.api('/api/courses');

    var rows = courses.length ? courses.map(function (c) {
      return '<tr class="row-link" data-open="' + c._id + '" tabindex="0" role="link" aria-label="Open course profile for ' + App.esc(courseLabel(c) + ' ' + courseName(c)) + '">' +
        '<td><div class="cell-main">' + App.esc(courseLabel(c)) + '</div><div class="cell-sub">' + App.esc(courseName(c)) + '</div></td>' +
        '<td>' + App.esc(c.department || '—') + '</td>' +
        '<td>' + App.esc(c.degreeLevel || '—') + '</td>' +
        '<td class="num">' + (c.years || '—') + '</td>' +
        '<td class="num">' + c.studentCount + '</td>' +
        '<td class="num">' + c.subjectCount + '</td>' +
        '<td>' + App.status(c.status) + '</td>' +
        '<td class="right nowrap"><a class="btn-icon" href="#/course/' + c._id + '" title="Open course">' + App.icon('eye') + '</a>' +
        '<button class="btn-icon" type="button" data-edit="' + c._id + '" title="Edit course">' + App.icon('edit') + '</button></td></tr>';
    }).join('') : '<tr><td colspan="8">' + App.empty('No courses yet', 'Add the first degree program.', 'cap') + '</td></tr>';

    el.innerHTML = App.pageHead({
      eyebrow: 'Academics',
      title: 'Courses',
      sub: 'Degree programs used by students, subjects and prospectuses.',
      actions: '<button class="btn coral" type="button" id="addCourse">' + App.icon('plus') + 'Add Course</button>'
    }) +
      '<section class="card"><div class="table-wrap"><table><thead><tr><th>Course</th><th>Department</th><th>Degree</th><th class="num">Years</th><th class="num">Students</th><th class="num">Subjects</th><th>Status</th><th class="right">Actions</th></tr></thead><tbody>' +
      rows + '</tbody></table></div></section>';

    document.getElementById('addCourse').addEventListener('click', function () { openCourseForm(null); });

    function openFromRow(event) {
      if (event.target.closest('a, button')) return;
      var row = event.target.closest('[data-open]');
      if (row) App.go('course/' + row.getAttribute('data-open'));
    }

    function handleClick(event) {
      var edit = event.target.closest('[data-edit]');
      if (edit) {
        openCourseForm(courses.find(function (c) { return c._id === edit.getAttribute('data-edit'); }));
        return;
      }
      openFromRow(event);
    }

    function handleKey(event) {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      if (event.target.closest('a, button')) return;
      var row = event.target.closest('[data-open]');
      if (!row) return;
      event.preventDefault();
      App.go('course/' + row.getAttribute('data-open'));
    }

    el.addEventListener('click', handleClick);
    el.addEventListener('keydown', handleKey);
    App.onCleanup(function () {
      el.removeEventListener('click', handleClick);
      el.removeEventListener('keydown', handleKey);
    });
  };

  P.course = async function (params, el) {
    var data = await App.api('/api/courses/' + params[0]);
    var c = data.course;
    var subjectCount = Number(data.subjectCount) || 0;
    var studentCount = Number(data.studentCount) || 0;
    var instructorCount = Number(data.instructorCount) || 0;
    var curriculumUnits = Number(data.curriculumUnits) || 0;
    var totalUnits = Number(c.totalUnits) > 0 ? Number(c.totalUnits) : curriculumUnits;
    var duration = c.duration || (c.years ? c.years + ' year' + (Number(c.years) === 1 ? '' : 's') : '—');
    var description = c.description || 'No description provided yet.';

    el.innerHTML = App.pageHead({
      eyebrow: 'Course profile',
      title: courseLabel(c) + ' — ' + courseName(c),
      sub: [c.department, c.degreeLevel].filter(Boolean).join(' · ') || 'Degree program',
      actions: '<a class="btn ghost" href="#/courses">Back</a>'
    }) +
      '<div class="grid-2">' +
      '<section class="card"><div class="card-head"><div><h2>Course information</h2><div class="card-sub">Program details and curriculum totals</div></div>' + App.status(c.status) + '</div>' +
      '<div class="course-description"><span>Description</span><p>' + App.esc(description) + '</p></div>' +
      '<div class="info-grid">' +
      '<div class="info-item"><span>Course code</span><strong>' + App.esc(courseLabel(c)) + '</strong></div>' +
      '<div class="info-item"><span>Course name</span><strong>' + App.esc(courseName(c)) + '</strong></div>' +
      '<div class="info-item"><span>Department</span><strong>' + App.esc(c.department || '—') + '</strong></div>' +
      '<div class="info-item"><span>Degree level</span><strong>' + App.esc(c.degreeLevel || '—') + '</strong></div>' +
      '<div class="info-item"><span>Program duration</span><strong>' + App.esc(duration) + '</strong></div>' +
      '<div class="info-item"><span>Total units</span><strong>' + (totalUnits > 0 ? totalUnits + ' units' : '—') + '</strong></div>' +
      '<div class="info-item"><span>Status</span><strong>' + App.esc(c.status || '—') + '</strong></div>' +
      '</div></section>' +
      '<section class="card"><div class="card-head"><div><h2>Summary</h2><div class="card-sub">Current program totals</div></div></div>' +
      '<div class="mini-grid">' +
      '<div class="mini-stat"><strong>' + subjectCount + '</strong><span>Subjects</span></div>' +
      '<div class="mini-stat"><strong>' + studentCount + '</strong><span>Enrolled students</span></div>' +
      '<div class="mini-stat"><strong>' + instructorCount + '</strong><span>Assigned instructors</span></div>' +
      '</div></section></div>';
  };

  function openCourseForm(course) {
    var isEdit = Boolean(course);
    var departments = ['College of Information Technology', 'College of Education', 'College of Business Administration'];
    var degrees = ["Bachelor's Degree", 'Associate Degree', "Master's Degree", 'Doctorate'];
    App.modal({
      title: isEdit ? 'Edit course' : 'Add course',
      sub: isEdit ? 'The course code is permanent while records reference it. Name, description and status can change.' : 'Creates a degree program that students and subjects can reference.',
      wide: true,
      body: '<form id="courseForm"><div class="form-grid">' +
        '<label class="field"><span>Course code</span><input name="courseCode" maxlength="10" required value="' + App.esc(isEdit ? course.code : '') + '"' + (isEdit ? ' disabled' : '') + '>' +
        (isEdit ? '<input type="hidden" name="courseCode" value="' + App.esc(course.code) + '">' : '') + '</label>' +
        '<label class="field"><span>Status</span><select name="status"><option' + (!isEdit || course.status === 'Active' ? ' selected' : '') + '>Active</option><option' + (isEdit && course.status === 'Inactive' ? ' selected' : '') + '>Inactive</option></select></label>' +
        '<label class="field span-2"><span>Course name</span><input name="name" maxlength="160" required value="' + App.esc(isEdit ? course.name : '') + '"></label>' +
        '<label class="field span-2"><span>Description</span><textarea name="description" maxlength="1000" rows="3" placeholder="Brief description of the degree program">' + App.esc(isEdit ? course.description || '' : '') + '</textarea></label>' +
        '<label class="field span-2"><span>Department / college</span><select name="department" required' + (isEdit ? ' disabled' : '') + '>' +
        departments.map(function (d) { return '<option' + (isEdit && course.department === d ? ' selected' : '') + '>' + d + '</option>'; }).join('') + '</select></label>' +
        '<label class="field"><span>Degree level</span><select name="degreeLevel" required' + (isEdit ? ' disabled' : '') + '>' +
        degrees.map(function (d) { return '<option' + (isEdit && course.degreeLevel === d ? ' selected' : '') + '>' + d + '</option>'; }).join('') + '</select></label>' +
        '<label class="field"><span>Program duration</span><input name="duration" maxlength="40" value="' + App.esc(isEdit ? course.duration : '4 years') + '" required' + (isEdit ? ' disabled' : '') + '></label>' +
        '<label class="field"><span>Number of years</span><input type="number" name="years" min="1" max="10" value="' + (isEdit ? course.years : 4) + '" required' + (isEdit ? ' disabled' : '') + '></label>' +
        '<label class="field"><span>Total units (optional)</span><input type="number" name="totalUnits" min="1" max="1000" value="' + (isEdit && course.totalUnits ? course.totalUnits : '') + '"' + (isEdit ? ' disabled' : '') + '></label>' +
        '<div class="form-error span-2" role="alert"></div></div></form>',
      footer: '<button class="btn ghost" type="button" data-close>Cancel</button><button class="btn coral" type="submit" form="courseForm">' + (isEdit ? 'Save changes' : 'Create course') + '</button>',
      onMount: function (wrap) {
        wrap.querySelector('#courseForm').addEventListener('submit', async function (event) {
          event.preventDefault();
          var form = event.currentTarget;
          var err = form.querySelector('.form-error');
          err.textContent = '';
          var data = App.formData(form);
          try {
            if (isEdit) {
              await App.api('/api/courses/' + course._id, { method: 'PATCH', body: { name: data.name, description: data.description, status: data.status } });
              App.toast('Course updated.');
            } else {
              await App.api('/api/courses', { method: 'POST', body: data });
              App.toast('Course created.');
            }
            App.closeModal();
            App.render();
          } catch (e) { err.textContent = e.message; }
        });
      }
    });
  }

  /* ============================== prospectus ============================== */

  P.prospectus = async function (params, el) {
    var courses = await App.api('/api/courses');
    if (!courses.length) {
      el.innerHTML = App.pageHead({ eyebrow: 'Academics', title: 'Prospectus', sub: 'Add a course before building a prospectus.' }) +
        '<div class="card">' + App.empty('No courses yet', 'Create a course first.', 'cap') + '</div>';
      return;
    }
    var selected = params[0] || courseLabel(courses[0]);
    var data = await App.api('/api/prospectus?course=' + encodeURIComponent(courseIdOf(selected, courses)));

    function courseIdOf(code, list) {
      var course = list.find(function (c) { return courseLabel(c) === code; }) || list[0];
      return course._id;
    }

    function grouped() {
      var groups = [];
      [1, 2, 3, 4].forEach(function (year) {
        ['1st Semester', '2nd Semester', 'Summer'].forEach(function (term) {
          var items = data.items.filter(function (i) { return i.yearLevel === year && i.term === term; });
          if (items.length) groups.push({ year: year, term: term, items: items });
        });
      });
      if (!groups.length) return App.empty('Prospectus is empty', 'Add subjects to build the curriculum.', 'list');
      return groups.map(function (g) {
        var units = g.items.reduce(function (sum, i) { return sum + (i.subject.units || 0); }, 0);
        return '<details class="accordion"><summary>Year ' + g.year + ' · ' + App.esc(g.term) +
          '<span class="count">' + g.items.length + ' subjects · ' + units + ' units</span></summary>' +
          '<div class="accordion-body"><div class="table-wrap"><table><thead><tr><th>Code</th><th>Subject</th><th class="num">Units</th><th class="right">Remove</th></tr></thead><tbody>' +
          g.items.map(function (i) {
            return '<tr><td class="cell-main">' + App.esc(i.subject.subjectCode) + '</td><td>' + App.esc(i.subject.subjectName) + '</td>' +
              '<td class="num">' + i.subject.units + '</td>' +
              '<td class="right"><button class="btn-icon" type="button" title="Remove from prospectus" data-remove="' + i.subject._id + '">' + App.icon('close') + '</button></td></tr>';
          }).join('') + '</tbody></table></div></div></details>';
      }).join('');
    }

    el.innerHTML = App.pageHead({
      eyebrow: 'Academics',
      title: 'Prospectus',
      sub: 'Place subjects into the year and semester a student takes them.',
      actions: '<button class="btn coral" type="button" id="addProspectusItem">' + App.icon('plus') + 'Add subject</button>'
    }) +
      '<section class="card"><div class="toolbar"><label class="field" style="min-width:260px"><span>Course</span><select id="prospectusCourse">' +
      courses.map(function (c) { return '<option value="' + App.esc(courseLabel(c)) + '"' + (courseLabel(c) === selected ? ' selected' : '') + '>' + App.esc(courseLabel(c) + ' — ' + c.name) + '</option>'; }).join('') +
      '</select></label><span class="spacer"></span><span class="cell-sub">' + data.items.length + ' subjects placed</span></div>' +
      '<div id="prospectusBody">' + grouped() + '</div></section>';

    document.getElementById('prospectusCourse').addEventListener('change', function (event) {
      App.go('prospectus/' + event.target.value);
    });

    document.getElementById('addProspectusItem').addEventListener('click', function () {
      if (!data.available.length) { App.toast('Every active subject is already in this prospectus.', 'warn'); return; }
      App.modal({
        title: 'Add subject to prospectus',
        sub: 'Choose where this subject belongs in the curriculum.',
        body: '<form id="prospectusForm"><div class="form-grid">' +
          '<label class="field span-2"><span>Subject</span><select name="subjectId" required>' +
          data.available.map(function (s) { return '<option value="' + s._id + '">' + App.esc(s.subjectCode + ' — ' + s.subjectName + ' (' + s.units + ' units)') + '</option>'; }).join('') + '</select></label>' +
          '<label class="field"><span>Year level</span><select name="yearLevel">' + yearOptions(1) + '</select></label>' +
          '<label class="field"><span>Semester</span><select name="term">' + termOptions('1st Semester') + '</select></label>' +
          '<div class="form-error span-2" role="alert"></div></div></form>',
        footer: '<button class="btn ghost" type="button" data-close>Cancel</button><button class="btn coral" type="submit" form="prospectusForm">Add subject</button>',
        onMount: function (wrap) {
          wrap.querySelector('#prospectusForm').addEventListener('submit', async function (event) {
            event.preventDefault();
            var form = event.currentTarget;
            var err = form.querySelector('.form-error');
            err.textContent = '';
            try {
              await App.api('/api/prospectus/' + data.course._id + '/items', { method: 'POST', body: App.formData(form) });
              App.toast('Subject added to the prospectus.');
              App.closeModal();
              App.render();
            } catch (e) { err.textContent = e.message; }
          });
        }
      });
    });

    document.getElementById('prospectusBody').addEventListener('click', async function (event) {
      var btn = event.target.closest('[data-remove]');
      if (!btn) return;
      var ok = await App.confirm({
        title: 'Remove subject?',
        message: 'The subject is removed from this prospectus. Existing schedules and enrollments are not deleted.',
        okLabel: 'Remove',
        danger: true
      });
      if (!ok) return;
      try {
        await App.api('/api/prospectus/' + data.course._id + '/items/' + btn.getAttribute('data-remove'), { method: 'DELETE' });
        App.toast('Subject removed from the prospectus.');
        App.render();
      } catch (e) { App.toast(e.message, 'error'); }
    });
  };

  /* ============================== school years ============================== */

  P.semesters = async function (params, el) {
    var rows = await App.api('/api/semesters');

    var tableRows = rows.length ? rows.map(function (s) {
      return '<tr><td><div class="cell-main">' + App.esc(s.academicYear) + '</div><div class="cell-sub">' + App.esc(s.label) + '</div></td>' +
        '<td>' + App.esc(s.term) + '</td>' +
        '<td class="nowrap">' + App.fmtDate(s.startDate) + '</td>' +
        '<td class="nowrap">' + App.fmtDate(s.endDate) + '</td>' +
        '<td>' + (s.isCurrent ? '<span class="status coral">Current term</span>' : '<span class="status inactive">Scheduled</span>') + '</td>' +
        '<td class="right"><button class="btn ghost sm" type="button" data-edit="' + s._id + '">' + App.icon('edit') + 'Edit dates</button></td></tr>';
    }).join('') : '<tr><td colspan="6">' + App.empty('No school years yet', 'Add the first term to open scheduling.', 'clock') + '</td></tr>';

    el.innerHTML = App.pageHead({
      eyebrow: 'Academics',
      title: 'School years',
      sub: 'The current term follows the calendar: the term whose start date passed most recently becomes current.',
      actions: '<button class="btn coral" type="button" id="addSemester">' + App.icon('plus') + 'Add school year</button>'
    }) +
      '<section class="card"><div class="table-wrap"><table><thead><tr><th>Academic year</th><th>Term</th><th>Starts</th><th>Ends</th><th>State</th><th class="right">Dates</th></tr></thead><tbody>' +
      tableRows + '</tbody></table></div>' +
      '<p class="small muted" style="margin:14px 0 0">A term is current from its start date to its end date. Changing a start date to today is how the scheduling office advances the term.</p>' +
      '</section>';

    document.getElementById('addSemester').addEventListener('click', function () { openSemesterForm(null); });
    el.addEventListener('click', function (event) {
      var edit = event.target.closest('[data-edit]');
      if (!edit) return;
      openSemesterForm(rows.find(function (s) { return s._id === edit.getAttribute('data-edit'); }));
    });
  };

  function dateInput(value) {
    if (!value) return '';
    return String(value).slice(0, 10);
  }

  function openSemesterForm(semester) {
    var isEdit = Boolean(semester);
    App.modal({
      title: isEdit ? 'Edit term dates' : 'Add school year',
      sub: isEdit ? 'Year and term stay fixed because schedules and enrollments reference them.' : 'Use a consecutive academic year such as 2026-2027.',
      body: '<form id="semesterForm"><div class="form-grid">' +
        '<label class="field"><span>Academic year</span><input name="academicYear" placeholder="2026-2027" maxlength="9" required value="' + App.esc(isEdit ? semester.academicYear : '2026-2027') + '"' + (isEdit ? ' disabled' : '') + '>' +
        (isEdit ? '<input type="hidden" name="academicYear" value="' + App.esc(semester.academicYear) + '">' : '') + '</label>' +
        '<label class="field"><span>Term</span><select name="term"' + (isEdit ? ' disabled' : '') + '>' + termOptions(isEdit ? semester.term : '1st Semester') + '</select>' +
        (isEdit ? '<input type="hidden" name="term" value="' + App.esc(semester.term) + '">' : '') + '</label>' +
        '<label class="field"><span>Start date</span><input type="date" name="startDate" required value="' + dateInput(isEdit ? semester.startDate : '') + '"></label>' +
        '<label class="field"><span>End date</span><input type="date" name="endDate" required value="' + dateInput(isEdit ? semester.endDate : '') + '"></label>' +
        '<div class="form-error span-2" role="alert"></div></div></form>',
      footer: '<button class="btn ghost" type="button" data-close>Cancel</button><button class="btn coral" type="submit" form="semesterForm">' + (isEdit ? 'Save dates' : 'Create term') + '</button>',
      onMount: function (wrap) {
        wrap.querySelector('#semesterForm').addEventListener('submit', async function (event) {
          event.preventDefault();
          var form = event.currentTarget;
          var err = form.querySelector('.form-error');
          err.textContent = '';
          var data = App.formData(form);
          try {
            if (isEdit) {
              await App.api('/api/semesters/' + semester._id, { method: 'PATCH', body: { startDate: data.startDate, endDate: data.endDate } });
              App.toast('Term dates saved.');
            } else {
              await App.api('/api/semesters', { method: 'POST', body: data });
              App.toast('School year created.');
            }
            App.closeModal();
            App.render();
          } catch (e) { err.textContent = e.message; }
        });
      }
    });
  }
})();
