/* ============================================================
   SELL SYSTEM — shared browser core
   API access, helpers, icons, shell, modals, charts, timetable.
   ============================================================ */
(function () {
  'use strict';

  var App = window.App = window.App || {};

  App.state = {
    me: null,
    csrf: null,
    route: '',
    semester: null,
    cleanup: []
  };

  /* ------------------------------ icons ------------------------------ */

  var ICONS = {
    dashboard: '<rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    teacher: '<path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="m17 11 2 2 4-4"/>',
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/>',
    door: '<path d="M3 21h18"/><path d="M6 21V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v17"/><circle cx="14.5" cy="12" r=".8"/>',
    calendar: '<rect x="3" y="4.5" width="18" height="17" rx="2.5"/><path d="M16 2.5v4"/><path d="M8 2.5v4"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/>',
    cap: '<path d="M22 9 12 4 2 9l10 5 10-5Z"/><path d="M6 11.5V16c0 1.5 2.7 3 6 3s6-1.5 6-3v-4.5"/>',
    list: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3.5 6h.01"/><path d="M3.5 12h.01"/><path d="M3.5 18h.01"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.2 2"/>',
    activity: '<path d="M3 12h4l2.5-7 4 14 2.5-7h5"/>',
    settings: '<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/><circle cx="9" cy="6" r="2.2" fill="currentColor" stroke="none"/><circle cx="15" cy="12" r="2.2" fill="currentColor" stroke="none"/><circle cx="8" cy="18" r="2.2" fill="currentColor" stroke="none"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6.5 8-6.5S20 17 20 21"/>',
    clipboard: '<rect x="5" y="4" width="14" height="17" rx="2.5"/><path d="M9 4.5V3h6v1.5"/><path d="M9 10h6"/><path d="M9 14h6"/><path d="M9 18h4"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    bell: '<path d="M18 9a6 6 0 1 0-12 0c0 5-2 6-2 6h16s-2-1-2-6"/><path d="M10.5 20a2 2 0 0 0 3 0"/>',
    menu: '<path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/>',
    close: '<path d="m6 6 12 12"/><path d="m18 6-12 12"/>',
    plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    eye: '<path d="M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12Z"/><circle cx="12" cy="12" r="2.6"/>',
    arrow: '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
    print: '<path d="M6 9V3h12v6"/><rect x="4" y="9" width="16" height="8" rx="2"/><path d="M8 17h8v4H8z"/>',
    upload: '<path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
    check: '<path d="m5 12 5 5L20 7"/>',
    x: '<path d="m6 6 12 12"/><path d="m18 6-12 12"/>',
    alert: '<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v5"/><path d="M12 17h.01"/>',
    chart: '<path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
    chevron: '<path d="m6 9 6 6 6-6"/>',
    dots: '<circle cx="5" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.2" fill="currentColor" stroke="none"/>',
    filter: '<path d="M3 5h18"/><path d="M6.5 12h11"/><path d="M10 19h4"/>',
    download: '<path d="M12 4v12"/><path d="m7 11 5 5 5-5"/><path d="M4 20h16"/>',
    building: '<path d="M4 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16"/><path d="M16 9h2a2 2 0 0 1 2 2v10"/><path d="M2 21h20"/><path d="M8 7h4"/><path d="M8 11h4"/><path d="M8 15h4"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.9 4.9 1.4 1.4"/><path d="m17.7 17.7 1.4 1.4"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m4.9 19.1 1.4-1.4"/><path d="m17.7 6.3 1.4-1.4"/>'
  };

  App.icon = function (name, cls) {
    var path = ICONS[name] || ICONS.dashboard;
    return '<svg class="' + (cls || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + path + '</svg>';
  };

  /* ------------------------------ API ------------------------------ */

  function csrf() {
    if (App.state.csrf) return Promise.resolve(App.state.csrf);
    return fetch('/api/auth/csrf', { credentials: 'same-origin' })
      .then(function (res) { return res.json(); })
      .then(function (data) { App.state.csrf = data.csrfToken; return data.csrfToken; });
  }
  App.csrf = csrf;

  App.api = function (url, options) {
    options = options || {};
    var method = (options.method || 'GET').toUpperCase();
    var headers = Object.assign({ 'Accept': 'application/json' }, options.headers || {});
    var body = options.body;

    if (body && !(body instanceof FormData) && typeof body !== 'string') {
      body = JSON.stringify(body);
      headers['Content-Type'] = 'application/json';
    }

    var withToken = method === 'GET' || method === 'HEAD'
      ? Promise.resolve(null)
      : csrf();

    return withToken.then(function (token) {
      if (token) headers['x-csrf-token'] = token;
      return fetch(url, {
        method: method,
        credentials: 'same-origin',
        headers: headers,
        body: body
      });
    }).then(function (res) {
      return res.text().then(function (text) {
        var data = {};
        if (text) {
          try { data = JSON.parse(text); } catch (e) { data = { message: text }; }
        }
        if (!res.ok) {
          if (res.status === 401 && !/\/api\/auth\//.test(url)) {
            window.location.replace('/');
          }
          var error = new Error(data.message || 'Request failed (' + res.status + ').');
          error.status = res.status;
          error.data = data;
          throw error;
        }
        return data;
      });
    });
  };

  /* ------------------------------ helpers ------------------------------ */

  App.esc = function (value) {
    return String(value === undefined || value === null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  App.initial = function (person) {
    if (!person) return '?';
    var first = person.firstName || person.name || '';
    var last = person.lastName || '';
    return ((String(first).charAt(0) || '') + (String(last).charAt(0) || '')).toUpperCase() || '?';
  };

  App.personName = function (person) {
    if (!person) return '—';
    if (person.firstName !== undefined || person.lastName !== undefined) {
      return (person.firstName + ' ' + (person.middleName ? person.middleName.charAt(0) + '. ' : '') + (person.lastName || '')).replace(/\s+/g, ' ').trim() || '—';
    }
    return person.name || '—';
  };

  App.time12 = function (value) {
    if (!value) return '—';
    var parts = String(value).split(':');
    var h = Number(parts[0]);
    var m = Number(parts[1] || 0);
    if (!Number.isFinite(h)) return String(value);
    return ((h % 12) || 12) + ':' + String(m).padStart(2, '0') + ' ' + (h >= 12 ? 'PM' : 'AM');
  };

  App.toMinutes = function (value) {
    var parts = String(value || '0:0').split(':');
    return Number(parts[0]) * 60 + Number(parts[1] || 0);
  };

  App.fmtTime = App.time12;

  App.fmtDate = function (value, opts) {
    if (!value) return '—';
    var date = value instanceof Date ? value : new Date(value);
    if (isNaN(date.getTime())) return '—';
    opts = opts || {};
    var utc = opts.utc !== false && typeof value === 'string' && /T00:00:00(\.000)?Z$/.test(value);
    var options = { month: 'short', day: 'numeric', year: 'numeric', timeZone: utc ? 'UTC' : undefined };
    return new Intl.DateTimeFormat('en-US', options).format(date);
  };

  App.fmtDateTime = function (value) {
    if (!value) return '—';
    var date = new Date(value);
    if (isNaN(date.getTime())) return '—';
    return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date);
  };

  App.dayNames = { Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday' };
  App.daysShort = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  App.daysInline = function (days) {
    return (days || []).map(function (d) { return App.dayNames[d] ? App.dayNames[d].slice(0, 3) : d; }).join(', ') || '—';
  };

  App.status = function (value, tone) {
    var v = String(value || '');
    var t = tone;
    if (!t) {
      if (/^(active|open|enrolled|offered|passed|credited|paid|present)$/i.test(v)) t = '';
      else if (/^(inactive|closed|dropped|unpaid|absent)$/i.test(v)) t = 'inactive';
      else if (/^(full|pending|late|incomplete|upcoming)$/i.test(v)) t = 'warn';
      else if (/^(failed|conflict|overloaded)$/i.test(v)) t = 'danger';
      else t = 'info';
    }
    return '<span class="status ' + t + '">' + App.esc(v) + '</span>';
  };

  App.avatar = function (person, extraClass) {
    return '<div class="avatar ' + (extraClass || '') + '">' + App.esc(App.initial(person)) + '</div>';
  };

  App.empty = function (title, detail, iconName) {
    return '<div class="empty">' + App.icon(iconName || 'book') +
      '<strong>' + App.esc(title || 'Nothing here yet') + '</strong>' +
      '<span>' + App.esc(detail || '') + '</span></div>';
  };

  App.loading = function () {
    return '<div class="loading">Loading…</div>';
  };

  App.pageHead = function (config) {
    var actions = config.actions || '';
    return '<div class="page-head">' +
      '<div class="head-text">' +
      (config.eyebrow ? '<div class="eyebrow">' + App.esc(config.eyebrow) + '</div>' : '') +
      '<h1>' + App.esc(config.title) + '</h1>' +
      (config.sub ? '<p class="sub">' + App.esc(config.sub) + '</p>' : '') +
      '</div>' +
      (actions ? '<div class="head-actions">' + actions + '</div>' : '') +
      '</div>';
  };

  App.button = function (label, opts) {
    opts = opts || {};
    var cls = 'btn ' + (opts.variant || '') + (opts.sm ? ' sm' : '');
    return '<button class="' + cls.trim() + '" ' + (opts.id ? 'id="' + opts.id + '"' : '') +
      (opts.type ? ' type="' + opts.type + '"' : ' type="button"') +
      (opts.disabled ? ' disabled' : '') +
      (opts.attrs || '') + '>' + (opts.icon ? App.icon(opts.icon) : '') + App.esc(label) + '</button>';
  };

  App.linkButton = function (label, href, opts) {
    opts = opts || {};
    return '<a class="btn ' + (opts.variant || '') + (opts.sm ? ' sm' : '') + '" href="' + href + '">' +
      (opts.icon ? App.icon(opts.icon) : '') + App.esc(label) + '</a>';
  };

  App.go = function (route) {
    if ((location.hash || '').replace(/^#\/?/, '') === route) {
      App.render();
    } else {
      location.hash = '#/' + route;
    }
  };

  /* ------------------------------ toasts ------------------------------ */

  App.toast = function (message, tone) {
    var host = document.querySelector('.toasts');
    if (!host) {
      host = document.createElement('div');
      host.className = 'toasts';
      document.body.appendChild(host);
    }
    var el = document.createElement('div');
    el.className = 'toast ' + (tone || '');
    el.textContent = message;
    host.appendChild(el);
    setTimeout(function () {
      el.style.opacity = '0';
      el.style.transform = 'translateX(12px)';
      el.style.transition = 'all .2s ease';
      setTimeout(function () { el.remove(); }, 220);
    }, 3600);
  };

  /* ------------------------------ modal ------------------------------ */

  var modalEl = null;

  App.closeModal = function () {
    if (!modalEl) return;
    modalEl.remove();
    modalEl = null;
    document.body.style.overflow = '';
  };

  App.modal = function (config) {
    App.closeModal();
    var wrap = document.createElement('div');
    wrap.className = 'modal open';
    wrap.innerHTML = '<div class="modal-card ' + (config.wide ? 'wide' : '') + '" role="dialog" aria-modal="true">' +
      '<div class="modal-head"><div><h2>' + App.esc(config.title || '') + '</h2>' +
      (config.sub ? '<p>' + App.esc(config.sub) + '</p>' : '') + '</div>' +
      '<button class="modal-close" type="button" data-close aria-label="Close">' + App.icon('close') + '</button></div>' +
      '<div class="modal-body">' + (config.body || '') + '</div>' +
      (config.footer === null ? '' : '<div class="modal-actions">' + (config.footer || '<button class="btn ghost" type="button" data-close>Close</button>') + '</div>') +
      '</div>';
    document.body.appendChild(wrap);
    document.body.style.overflow = 'hidden';
    modalEl = wrap;

    wrap.addEventListener('click', function (event) {
      if (event.target === wrap || event.target.closest('[data-close]')) App.closeModal();
    });
    document.addEventListener('keydown', function escListener(event) {
      if (event.key === 'Escape') {
        App.closeModal();
        document.removeEventListener('keydown', escListener);
      }
    });

    if (typeof config.onMount === 'function') config.onMount(wrap);
    return wrap;
  };

  App.confirm = function (config) {
    return new Promise(function (resolve) {
      var wrap = App.modal({
        title: config.title || 'Please confirm',
        sub: config.sub || '',
        body: '<p class="small" style="margin:0;color:var(--ink-soft)">' + App.esc(config.message || '') + '</p>',
        footer: '<button class="btn ghost" type="button" data-cancel>Cancel</button>' +
          '<button class="btn ' + (config.danger ? 'coral' : '') + '" type="button" data-ok>' + App.esc(config.okLabel || 'Confirm') + '</button>'
      });
      var done = false;
      wrap.addEventListener('click', function (event) {
        if (event.target.closest('[data-ok]')) { done = true; App.closeModal(); resolve(true); }
        else if (event.target.closest('[data-cancel]') || event.target === wrap || event.target.closest('[data-close]')) {
          if (!done) { done = true; resolve(false); }
        }
      });
    });
  };

  /* ------------------------------ form helpers ------------------------------ */

  App.formData = function (form) {
    var data = {};
    Array.prototype.forEach.call(form.elements, function (field) {
      if (!field.name || field.disabled) return;
      if (field.multiple) {
        data[field.name] = Array.prototype.filter.call(field.options, function (o) { return o.selected; }).map(function (o) { return o.value; });
      } else if (field.type === 'checkbox') data[field.name] = field.checked;
      else if (field.type === 'radio') { if (field.checked) data[field.name] = field.value; }
      else data[field.name] = field.value;
    });
    return data;
  };

  App.setError = function (container, message) {
    var el = container.querySelector('.form-error');
    if (el) el.textContent = message || '';
  };

  /* ------------------------------ charts ------------------------------ */

  App.barChart = function (rows, opts) {
    opts = opts || {};
    var width = 640, height = 200;
    var padL = 30, padR = 8, padT = 16, padB = 28;
    var innerW = width - padL - padR;
    var innerH = height - padT - padB;
    var max = Math.max.apply(null, rows.map(function (r) { return r.value; }).concat([1]));
    var step = innerW / Math.max(rows.length, 1);
    var barW = Math.min(34, step * 0.44);
    var gridLines = 4;
    var svg = '<svg class="chart-svg" viewBox="0 0 ' + width + ' ' + height + '" preserveAspectRatio="none" role="img" aria-label="' + App.esc(opts.label || 'Bar chart') + '">';
    for (var g = 0; g <= gridLines; g++) {
      var y = padT + (innerH / gridLines) * g;
      svg += '<line x1="' + padL + '" y1="' + y + '" x2="' + (width - padR) + '" y2="' + y + '" stroke="#eef0f6" stroke-width="1"/>';
      svg += '<text x="' + (padL - 8) + '" y="' + (y + 4) + '" text-anchor="end" font-size="9" fill="#9aa1b4">' + Math.round(max - (max / gridLines) * g) + '</text>';
    }
    rows.forEach(function (row, index) {
      var h = Math.max(3, (row.value / max) * innerH);
      var x = padL + step * index + (step - barW) / 2;
      var y = padT + innerH - h;
      var fill = row.color || (index % 3 === 0 ? '#1c2a6b' : index % 3 === 1 ? '#f26a5a' : '#f7a9a2');
      svg += '<rect x="' + x + '" y="' + y + '" width="' + barW + '" height="' + h + '" rx="' + Math.min(8, barW / 2) + '" fill="' + fill + '"/>';
      if (row.value > 0) svg += '<text x="' + (x + barW / 2) + '" y="' + (y - 6) + '" text-anchor="middle" font-size="9" font-weight="600" fill="#3f4763">' + row.value + '</text>';
      svg += '<text x="' + (x + barW / 2) + '" y="' + (height - 8) + '" text-anchor="middle" font-size="9.5" fill="#7c8499">' + App.esc(row.label) + '</text>';
    });
    svg += '</svg>';
    return '<div class="chart-wrap">' + svg + '</div>';
  };

  App.donut = function (segments, centerValue, centerLabel) {
    var total = segments.reduce(function (sum, s) { return sum + Number(s.value || 0); }, 0);
    var radius = 58;
    var circumference = 2 * Math.PI * radius;
    var offset = 0;
    var arcs = segments.map(function (segment) {
      var fraction = total ? Number(segment.value || 0) / total : 0;
      var length = fraction * circumference;
      var dash = '<circle cx="75" cy="75" r="' + radius + '" fill="none" stroke="' + segment.color + '" stroke-width="15" stroke-dasharray="' + Math.max(0, length - 3) + ' ' + (circumference - Math.max(0, length - 3)) + '" stroke-dashoffset="' + (-offset) + '" stroke-linecap="round" transform="rotate(-90 75 75)"/>';
      offset += length;
      return dash;
    }).join('');
    return '<div class="donut-wrap"><svg viewBox="0 0 150 150" width="150" height="150" role="img" aria-label="Donut chart">' +
      '<circle cx="75" cy="75" r="' + radius + '" fill="none" stroke="#f2f4f9" stroke-width="15"/>' + arcs +
      '</svg><div class="donut-center"><div><strong>' + App.esc(centerValue) + '</strong><span>' + App.esc(centerLabel) + '</span></div></div></div>';
  };

  /* ------------------------------ timetable ------------------------------ */

  App.timetable = function (sessions, opts) {
    opts = opts || {};
    var days = opts.days || ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    var start = App.toMinutes(opts.start || '07:30');
    var end = App.toMinutes(opts.end || '17:00');
    if (end <= start) end = start + 600;
    var rows = Math.max(8, Math.round((end - start) / 30));
    var span = end - start;
    var colors = ['c1', 'c2', 'c3', 'c4', 'c5'];

    var header = '<div class="tt-corner"></div>' + days.map(function (day) {
      var count = sessions.filter(function (s) { return (s.weekdays || []).indexOf(day) !== -1; }).length;
      return '<div class="tt-dayhead"><strong>' + App.esc(App.dayNames[day].slice(0, 3)) + '</strong><span>' + (count ? count + ' class' + (count > 1 ? 'es' : '') : '—') + '</span></div>';
    }).join('');

    var timeLabels = '';
    for (var t = start; t <= end; t += 30) {
      var top = ((t - start) / span) * 100;
      timeLabels += '<span class="tt-time-label" style="top:' + top + '%">' + App.time12(Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0')) + '</span>';
    }

    var columns = days.map(function (day) {
      var blocks = sessions.filter(function (s) { return (s.weekdays || []).indexOf(day) !== -1; }).map(function (s, index) {
        var sMin = App.toMinutes(s.startTime);
        var eMin = App.toMinutes(s.endTime);
        var topPct = ((sMin - start) / span) * 100;
        var heightPct = ((eMin - sMin) / span) * 100;
        var colorIndex = typeof s.color === 'number' ? s.color : Math.abs(hash(String(s._id || s.subjectCode || index))) % colors.length;
        var subject = s.subject || {};
        var tooltip = (subject.subjectCode || s.subjectCode || '') + ' · ' + (s.room || '') + ' · ' + App.time12(s.startTime) + '–' + App.time12(s.endTime);
        return '<button type="button" class="tt-block ' + colors[colorIndex] + '" ' +
          'data-session="' + App.esc(s._id || '') + '" title="' + App.esc(tooltip) + '" ' +
          'style="top:' + topPct + '%;height:' + Math.max(2.5, heightPct) + '%">' +
          '<b>' + App.esc(subject.subjectCode || s.subjectCode || s.title || '') + '</b>' +
          '<small>' + App.esc(s.room || s.roomCode || '') + (s.instructor ? ' · ' + App.esc(typeof s.instructor === 'string' ? s.instructor : App.personName(s.instructor)) : '') + '</small>' +
          '</button>';
      }).join('');
      return '<div class="tt-col" style="--rows:' + rows + '">' + blocks + '</div>';
    }).join('');

    return '<div class="table-wrap"><div class="timetable" style="grid-template-columns:64px repeat(' + days.length + ', minmax(118px,1fr))">' +
      header + '<div class="tt-times" style="min-height:' + (rows * 38) + 'px">' + timeLabels + '</div>' +
      columns.replace(/min-height:460px;?/g, '') +
      '</div></div>';
  };

  App.bindTimetable = function (container, sessions, onSelect) {
    if (!onSelect) return;
    container.querySelectorAll('[data-session]').forEach(function (block) {
      block.addEventListener('click', function () {
        var id = block.getAttribute('data-session');
        var session = sessions.find(function (s) { return String(s._id) === String(id); });
        if (session) onSelect(session);
      });
    });
  };

  App.normalizeSessions = function (rows) {
    return (rows || []).map(function (s) {
      var subject = s.subject || {};
      var room = s.room;
      var instructor = s.instructor;
      return {
        _id: s._id,
        weekdays: s.weekdays || [],
        startTime: s.startTime,
        endTime: s.endTime,
        subjectCode: subject.subjectCode || s.subjectCode || '',
        subjectName: subject.subjectName || s.subjectName || '',
        subject: subject,
        room: typeof room === 'string' ? room : (room && room.roomCode) || s.roomCode || '',
        roomName: typeof room === 'object' && room ? room.roomName || '' : '',
        instructor: instructor ? (typeof instructor === 'string' ? instructor : App.personName(instructor)) : '',
        course: s.course && s.course.code ? s.course.code : (typeof s.course === 'string' ? s.course : ''),
        yearLevel: s.yearLevel,
        sectionType: s.sectionType || 'Open',
        blockLabel: s.blockLabel || '',
        status: s.status,
        raw: s
      };
    });
  };

  function hash(str) {
    var h = 0;
    for (var i = 0; i < str.length; i++) h = ((h << 5) - h + str.charCodeAt(i)) | 0;
    return h;
  }

  /* ------------------------------ navigation ------------------------------ */

  var NAV = {
    Admin: [
      { group: 'Overview', items: [
        { route: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
        { route: 'activity', label: 'Activity Log', icon: 'activity' }
      ] },
      { group: 'People', items: [
        { route: 'students', label: 'Students', icon: 'users' },
        { route: 'instructors', label: 'Instructors', icon: 'teacher' }
      ] },
      { group: 'Academics', items: [
        { route: 'subjects', label: 'Subjects', icon: 'book' },
        { route: 'courses', label: 'Courses', icon: 'cap' },
        { route: 'prospectus', label: 'Prospectus', icon: 'list' },
        { route: 'semesters', label: 'School Years', icon: 'clock' }
      ] },
      { group: 'Scheduling', items: [
        { route: 'rooms', label: 'Room and Schedule', icon: 'door' },
        { route: 'enrollments', label: 'Enrollments', icon: 'clipboard' }
      ] },
      { group: 'System', items: [
        { route: 'settings', label: 'Settings', icon: 'settings' },
        { route: 'profile', label: 'My Profile', icon: 'user' }
      ] }
    ],
    Instructor: [
      { group: 'Overview', items: [
        { route: 'schedule', label: 'My Schedule', icon: 'calendar' }
      ] },
      { group: 'Teaching', items: [
        { route: 'students', label: 'My Students', icon: 'users' }
      ] },
      { group: 'Account', items: [
        { route: 'profile', label: 'My Profile', icon: 'user' }
      ] }
    ],
    Student: [
      { group: 'Main Menu', items: [
        { route: 'enrollment', label: 'Enrollment', icon: 'clipboard' },
        { route: 'prospectus', label: 'Prospectus', icon: 'list' },
        { route: 'subjects', label: 'My Subjects', icon: 'book' },
        { route: 'schedule', label: 'My Schedule', icon: 'calendar' },
        { route: 'profile', label: 'Profile', icon: 'user' }
      ] }
    ]
  };

  App.renderNav = function () {
    var nav = document.getElementById('nav');
    var isStudent = App.state.me.role === 'Student';
    var items = NAV[App.state.me.role] || [];
    nav.innerHTML = items.map(function (group) {
      return '<div class="nav-label">' + App.esc(group.group) + '</div>' +
        group.items.map(function (item) {
          return '<a class="nav-link" href="#/' + item.route + '" data-route="' + item.route + '">' +
            '<span class="nav-icon">' + App.icon(item.icon) + '</span>' +
            '<span>' + App.esc(item.label) + '</span>' +
            '</a>';
        }).join('');
    }).join('');

    if (isStudent) {
      nav.insertAdjacentHTML('beforeend',
        '<button type="button" class="nav-link nav-logout" data-logout-nav>' +
          '<span class="nav-icon">' + App.icon('logout') + '</span>' +
          '<span>Logout</span>' +
        '</button>');
      nav.querySelector('[data-logout-nav]').addEventListener('click', App.logout);
    }

    var footer = document.getElementById('sidebarFoot');
    if (footer) {
      if (isStudent) {
        footer.innerHTML = '<div class="student-sidebar-brand">' +
          '<div class="student-sidebar-mark">' + App.icon('cap') + '</div>' +
          '<div><strong>Southern Canillo College</strong><span>Learning, organized.</span></div>' +
          '</div>';
      } else {
        footer.innerHTML = '<div class="nav-card">' +
          '<div class="nav-card-tile">' + App.icon('sun') + '</div>' +
          '<strong>' + (App.state.semester ? App.esc(App.state.semester.label) : 'Current term') + '</strong>' +
          '<span>' + (App.state.semester ? 'Enrollment window open' : 'Set up a school year') + '</span>' +
          '<button type="button" data-logout>Sign out</button>' +
          '</div>';
        footer.querySelector('[data-logout]').addEventListener('click', App.logout);
      }
    }
  };

  App.markNav = function (route) {
    var base = route.split('/')[0];
    var mapped = base === 'student' ? 'students' : base === 'instructor' ? 'instructors' : base === 'room' ? 'rooms' : base === 'subject' ? 'subjects' : base === 'schedules' ? 'rooms' : base;
    // The instructor's class detail is reached from My Schedule, so that is the
    // navigation item that should stay highlighted while the class is open.
    if (base === 'subject' && App.state.me && App.state.me.role === 'Instructor') mapped = 'schedule';
    document.querySelectorAll('.nav-link').forEach(function (link) {
      link.classList.toggle('active', link.getAttribute('data-route') === mapped);
    });
  };

  App.logout = function () {
    App.api('/api/auth/logout', { method: 'POST' })
      .catch(function () {})
      .then(function () { window.location.replace('/'); });
  };

  /* ------------------------------ topbar ------------------------------ */

  var SEARCHABLE_ROUTES = {
    students: true,
    student: true,
    instructors: true,
    instructor: true,
    subjects: true,
    subject: true,
    rooms: true,
    room: true,
    schedules: true
  };

  App.updateSearchVisibility = function (route) {
    var role = App.state.me && App.state.me.role;
    var base = String(route || '').split('/')[0];
    var show = role === 'Admin' && SEARCHABLE_ROUTES[base] === true;
    var search = document.getElementById('searchPill');
    var results = document.getElementById('searchResults');
    var input = document.getElementById('globalSearch');
    var topbar = document.querySelector('.topbar');

    if (search) search.style.display = show ? '' : 'none';
    if (topbar) topbar.classList.toggle('search-hidden', !show);

    if (!show) {
      if (results) results.classList.remove('open');
      if (input) input.value = '';
    }
  };

  App.renderTopbar = function () {
    var role = App.state.me.role;
    var name = role === 'Admin' ? (App.state.me.username || 'Administrator') : App.personName(App.state.me);
    document.getElementById('welcomeName').textContent = 'Welcome, ' + name;
    document.getElementById('welcomeMeta').textContent = App.state.semester ? App.state.semester.label : (role + ' portal');
    document.getElementById('topAvatar').textContent = (name || '?').charAt(0).toUpperCase();
    document.getElementById('topUserName').textContent = name;
    document.getElementById('topUserRole').textContent = role;

    var search = document.getElementById('searchPill');
    if (search) search.style.display = 'none';

    var bell = document.getElementById('bellBtn');
    if (bell) bell.style.display = role === 'Admin' ? '' : 'none';
  };

  App.initSearch = function () {
    var input = document.getElementById('globalSearch');
    var results = document.getElementById('searchResults');
    if (!input || !results) return;
    var timer = null;

    input.addEventListener('input', function () {
      clearTimeout(timer);
      var q = input.value.trim();
      if (q.length < 2) { results.classList.remove('open'); results.innerHTML = ''; return; }
      timer = setTimeout(function () {
        App.api('/api/admin/search?q=' + encodeURIComponent(q)).then(function (data) {
          if (!data.results.length) {
            results.innerHTML = '<div class="empty" style="padding:14px">No matches found.</div>';
          } else {
            results.innerHTML = data.results.map(function (r) {
              return '<button type="button" data-route="' + App.esc(r.route) + '">' +
                '<span>' + App.esc(r.label) + '</span><span class="sr-type">' + App.esc(r.type) + '</span></button>';
            }).join('');
          }
          results.classList.add('open');
        }).catch(function () {});
      }, 220);
    });

    results.addEventListener('click', function (event) {
      var button = event.target.closest('[data-route]');
      if (!button) return;
      results.classList.remove('open');
      input.value = '';
      App.go(button.getAttribute('data-route'));
    });

    document.addEventListener('click', function (event) {
      if (!event.target.closest('#searchPill')) results.classList.remove('open');
    });
  };

  /* ------------------------------ cleanup ------------------------------ */

  App.onCleanup = function (fn) { App.state.cleanup.push(fn); };
  App.runCleanup = function () {
    App.state.cleanup.forEach(function (fn) { try { fn(); } catch (e) {} });
    App.state.cleanup = [];
  };

  /* ------------------------------ boot ------------------------------ */

  App.boot = function () {
    var content = document.getElementById('content');
    content.innerHTML = App.loading();

    Promise.all([
      App.api('/api/auth/me'),
      App.api('/api/semesters/current').catch(function () { return { semester: null }; }),
      csrf().catch(function () { return null; })
    ]).then(function (results) {
      var me = results[0];
      if (!me || !me.user) { window.location.replace('/'); return; }
      App.state.me = Object.assign({}, me.user, me.profile || {});
      App.state.profile = me.profile || null;
      App.state.csrf = me.csrfToken || results[2];
      App.state.semester = results[1].semester || null;
      document.body.setAttribute('data-role', App.state.me.role || '');
      App.renderNav();
      App.renderTopbar();
      App.initSearch();

      var hamburger = document.getElementById('hamburger');
      var sidebar = document.querySelector('.sidebar');
      var backdrop = document.getElementById('backdrop');
      if (hamburger) hamburger.addEventListener('click', function () {
        sidebar.classList.toggle('open');
        backdrop.classList.toggle('open');
      });
      if (backdrop) backdrop.addEventListener('click', function () {
        sidebar.classList.remove('open');
        backdrop.classList.remove('open');
      });

      document.getElementById('quickAdd').addEventListener('click', App.quickAdd);
      document.getElementById('bellBtn').addEventListener('click', function () {
        App.go('activity');
      });

      window.addEventListener('hashchange', App.render);
      App.render();
    }).catch(function (err) {
      content.innerHTML = '<div class="empty">' + App.icon('alert') + '<strong>Could not load the workspace</strong><span>' + App.esc(err.message) + '</span></div>';
    });
  };

  App.quickAdd = function () {
    var role = App.state.me.role;
    if (role === 'Admin') App.go('schedules');
    else if (role === 'Student') App.go('enrollment');
    else App.go('schedule');
  };

  App.render = function () {
    var raw = (location.hash || '').replace(/^#\/?/, '');
    var route = raw || 'dashboard';
    var parts = route.split('/');
    var page = parts[0];
    var params = parts.slice(1);
    App.state.route = route;
    App.markNav(route);
    App.updateSearchVisibility(route);
    App.runCleanup();
    App.closeModal();

    var sidebar = document.querySelector('.sidebar');
    var backdrop = document.getElementById('backdrop');
    if (sidebar) sidebar.classList.remove('open');
    if (backdrop) backdrop.classList.remove('open');

    var pages = App.pages || {};
    var render = pages[page];
    if (!render) {
      document.getElementById('content').innerHTML = App.pageHead({ eyebrow: 'Not found', title: 'This page does not exist', sub: 'Use the navigation to continue.' });
      return;
    }
    var content = document.getElementById('content');
    content.innerHTML = App.loading();
    scrollTo({ top: 0, behavior: 'instant' in document.documentElement.style ? 'instant' : 'auto' });
    Promise.resolve(render(params, content)).catch(function (err) {
      content.innerHTML = App.pageHead({ eyebrow: 'Error', title: 'Could not load this page', sub: err.message }) +
        '<div class="card">' + App.empty('Try again', err.message || 'Unexpected error.', 'alert') + '</div>';
    });
  };
})();
